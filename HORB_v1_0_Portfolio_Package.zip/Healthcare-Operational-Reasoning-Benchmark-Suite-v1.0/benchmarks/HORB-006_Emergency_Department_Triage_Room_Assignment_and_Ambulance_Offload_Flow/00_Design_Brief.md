# HORB-006: Emergency Department Triage / Room Assignment & Ambulance Offload Flow

**Suite:** Healthcare Operational Reasoning Benchmark Suite  
**Version:** 1.0  
**Author:** Meredith Reese, RN  
**Original File Mapping:** Submission 024

> Evaluating operational reasoning under uncertainty in emergency department operations.

## Clinical Domain

Emergency Department Operations

## Operational Setting

Emergency Department triage, rooming, and EMS offload window

## Operational Window

6:12 PM to 6:25 PM before the ED triage and rooming huddle.

## Primary Capability Evaluated

Emergency Department operational prioritization and room-assignment reasoning.

## Purpose

Evaluates whether an AI system can coordinate ED triage and room assignment while balancing patient acuity, room suitability, ambulance offload, nurse/tech coverage, safety risks, isolation, monitoring needs, and evolving waiting-room information.

## Primary Evaluation Question

> **Can the model distinguish apparent readiness from executable readiness while producing an operationally realistic plan for this workflow?**

## Capability Profile

| Capability | Evaluated |
|---|:---:|
| Multi-document reasoning | ✓ |
| Operational prioritization | ✓ |
| Temporal reasoning | ✓ |
| Workflow coordination | ✓ |
| Resource allocation | ✓ |
| Ownership boundaries | ✓ |
| Source provenance | ✓ |
| Uncertainty management | ✓ |


## Operational Actors

- Triage nurse
- Charge nurse
- ED physicians / APPs
- Primary nurses
- Techs
- EMS
- Registration
- Security or sitter coverage as needed
- Bed control / transport


## Reasoning Challenges

- Competing ED acuity
- Room suitability and monitoring needs
- Ambulance offload pressure
- Staffing and sitter limitations
- Isolation/safety requirements
- Waiting-room status changes
- Patient deterioration signals
- Multiple plausible rooming choices


## Typical Failure Modes

- Rooming a patient based only on green status
- Ignoring monitoring or safety needs
- Treating open room as usable without staffing
- Premature EMS offload assignment
- Unrealistic simultaneous room moves
- Under-prioritizing new high-risk symptoms


## Expected High-Quality Response

A strong response should:

- Integrate information across multiple documents.
- Distinguish confirmed information from apparent readiness.
- Respect ownership boundaries and role authority.
- Recognize unresolved dependencies.
- Prioritize realistically under time and resource constraints.
- Recommend only operationally executable actions.
- Carry unresolved issues forward to the appropriate huddle or owner.

## Included Materials

- `UseCase_System_Prompt.md`
- `Strict_Grading_Guidelines.md`
- `source_docs/` (28 fictional operational documents)
- `SourceDocs.zip`
- `original_batches/`

## Estimated Difficulty

**Expert**

## Estimated Human Evaluation Time

Approximately **30–45 minutes**.

## Design Notes

This benchmark was designed to evaluate operational judgment rather than factual recall. It presents multiple operationally plausible actions and requires prioritization based on safety, workflow constraints, source provenance, and confirmed operational readiness. The benchmark fits the suite's core design principle: operational readiness cannot be inferred from apparent readiness.

## Keywords

Emergency Department • triage • room assignment • ambulance offload • patient flow • AI evaluation • benchmark design • healthcare operations
