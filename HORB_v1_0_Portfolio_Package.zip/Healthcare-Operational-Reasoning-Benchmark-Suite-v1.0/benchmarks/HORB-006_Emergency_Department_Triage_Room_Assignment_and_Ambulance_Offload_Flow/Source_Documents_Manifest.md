# Source Documents Manifest

This benchmark includes 28 fictional operational source documents.

| # | File |
|---|---|
| 1 | `01_ED_Tracking_Board.md` |
| 2 | `02_ED_Room_Status.md` |
| 3 | `03_Triage_Status_Summary.md` |
| 4 | `04_ED_Staffing_View.md` |
| 5 | `05_EMS_Incoming_Radio.md` |
| 6 | `06_Vital_Sign_Recheck_Log.md` |
| 7 | `07_EKG_Lab_Status.md` |
| 8 | `08_Security_Sitter_Status.md` |
| 9 | `09_FastTrack_Status.md` |
| 10 | `10_Peds_Respiratory_Status.md` |
| 11 | `11_Provider_Lead_Notes.md` |
| 12 | `12_Nursing_Secure_Messages.md` |
| 13 | `13_Command_Center_Log.md` |
| 14 | `14_Transport_Tech_Status.md` |
| 15 | `15_Ambulance_Wall_Status.md` |
| 16 | `16_Discharge_And_BedTurn_Status.md` |
| 17 | `17_Infection_Isolation_Status.md` |
| 18 | `18_Stroke_ChestPain_Sepsis_Pathways.md` |
| 19 | `19_Family_WaitingRoom_Notes.md` |
| 20 | `20_Psych_BH_Process.md` |
| 21 | `21_Huddle_Agenda.md` |
| 22 | `22_Charge_RN_Worklist.md` |
| 23 | `23_Recent_Updates_Digest.md` |
| 24 | `24_Risk_Watchlist.md` |
| 25 | `25_Family_Communication_Notes.md` |
| 26 | `26_ED_Rooming_Policy.md` |
| 27 | `27_Signout_Snapshot.md` |
| 28 | `28_General_Operational_Notices.md` |
