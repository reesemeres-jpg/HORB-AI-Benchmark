# Peds Respiratory Status

Pediatric / Respiratory Readiness  
Updated: 6:08 PM

| Patient / resource | Status |
|---|---|
| Olivia Young | 5F cough/fever; barking cough; O2 93% while crying; peds reassessment requested |
| Peds Room 6 | Clean but respiratory cart not restocked |
| Peds nebulizer setup | One kit missing mask size |
| RT | Can support one respiratory patient before 6:30 |
| DeAndre Miles | Incoming adult CPAP patient; likely needs RT first |
| Resus 1 | Respiratory setup checked |
| Peds provider | Covering urgent care callback until 6:20 |

Peds note: Pediatric respiratory rooming requires equipment and staff readiness, not just a clean room.
