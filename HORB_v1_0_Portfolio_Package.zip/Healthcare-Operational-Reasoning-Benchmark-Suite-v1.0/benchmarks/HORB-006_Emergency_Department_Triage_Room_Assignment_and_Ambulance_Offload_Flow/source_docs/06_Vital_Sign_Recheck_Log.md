# Vital Sign Recheck Log

Triage / Waiting Room Vital Sign Recheck Log  
Updated: 6:09 PM

| Patient | Recent vital sign update |
|---|---|
| Angela Wells | BP 154/88, HR 104, O2 97%; chest pressure returned briefly while walking to restroom |
| Mateo Ruiz | BP 88/54, HR 118, temp 102.3, O2 95%; appears more confused per daughter |
| Brianna Cole | HR 96, BP 132/78; calm, tearful |
| Olivia Young | HR 148 while crying, temp 101.9, O2 93%; barking cough heard in triage |
| Ethan Shaw | Vitals stable, pain 2/10 |
| Gloria Finch | BP 168/74, pain 8/10 with movement; on anticoagulant |
| Nolan Grant | Stable vitals |
| EMS Wall Unit 12 | EMS reports earlier BP 90s systolic; ED vitals not repeated yet |

Vital sign note: Repeat vitals may change rooming priority before the tracking board updates.
