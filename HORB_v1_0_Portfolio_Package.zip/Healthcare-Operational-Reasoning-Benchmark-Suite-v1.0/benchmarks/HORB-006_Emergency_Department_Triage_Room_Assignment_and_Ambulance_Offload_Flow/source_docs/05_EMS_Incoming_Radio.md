# EMS Incoming Radio

EMS Incoming Radio Log  
Updated: 6:09 PM

**EMS Unit 8 — DeAndre Miles**  
ETA 6:18. Adult male with severe shortness of breath. CPAP in place. Respiratory rate high. EMS asks for resus or respiratory-ready monitored room.

**EMS Unit 3 — Fatima Noor**  
ETA 6:20. Adult female with sudden speech difficulty reported by family. EMS unsure last-known-well; symptoms improved during transport but not fully resolved. Stroke alert not activated yet; ED provider wants immediate screen on arrival.

**Police transport — unknown adult**  
ETA about 6:25. Agitated, possible intoxication. Police ask whether safe room will be ready.

**Clinic transfer — Rosa King**  
ETA 6:30. Clinic reports potassium 6.1 on outpatient lab and weakness. No ED EKG yet.

Radio note: Incoming calls may require holding specific spaces even when current board rows look ready to move.
