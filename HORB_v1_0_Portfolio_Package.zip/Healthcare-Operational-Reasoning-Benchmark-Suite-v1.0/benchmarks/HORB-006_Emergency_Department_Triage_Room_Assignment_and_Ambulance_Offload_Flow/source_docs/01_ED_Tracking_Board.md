# ED Tracking Board

Emergency Department Tracking Board  
Generated: 6:07 PM  
Display source: ED electronic tracking board

| Location / queue | Patient | Complaint | Visible next step | Board color |
|---|---|---|---|---|
| Waiting Room | Angela Wells | Chest pain, now improved | Fast Track 3 | Green |
| Waiting Room | Mateo Ruiz | Fever / weakness | Hallway 2 | Green |
| Triage 4 | Brianna Cole | Behavioral health evaluation | Psych Safe Room 1 | Green |
| Waiting Room | Olivia Young | Pediatric cough / fever | Peds Room 6 | Yellow |
| Room 9 | Ethan Shaw | Abdominal pain | Discharge pending | Yellow |
| Hallway 1 | Gloria Finch | Fall, hip pain | X-ray pending | Yellow |
| Fast Track 1 | Nolan Grant | Finger laceration | Repair pending | Green |
| EMS Wall | Unit 12 | Offload pending | Needs monitored bed | Red |

Incoming:
| Source | Patient | Note | ETA |
|---|---|---|---|
| EMS Unit 8 | DeAndre Miles | Shortness of breath / CPAP | 6:18 |
| EMS Unit 3 | Fatima Noor | Possible stroke symptoms | 6:20 |
| Police | Unknown adult | Agitated / possible intoxication | 6:25 |
| Clinic transfer | Rosa King | Hyperkalemia reported | 6:30 |

Board note: Green reflects visible tracking-board status only. It may not reflect updated vital signs, EKG changes, lab issues, infection precautions, sitter/security status, room cleanliness, or current acuity review.
