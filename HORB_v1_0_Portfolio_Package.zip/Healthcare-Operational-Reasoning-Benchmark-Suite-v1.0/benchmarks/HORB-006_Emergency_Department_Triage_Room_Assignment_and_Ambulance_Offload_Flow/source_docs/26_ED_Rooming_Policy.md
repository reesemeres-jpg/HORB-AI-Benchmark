# ED Rooming Policy

ED Rooming and Surge Workflow

1. Tracking-board color is a starting point, not final rooming release.
2. Fast track is for stable low-risk patients who do not need cardiac monitoring, urgent redraws, or provider review for high-risk changes.
3. Hallway placement should not be used for patients needing sepsis evaluation, rapid IV access, frequent reassessment, or close monitoring.
4. Behavioral health safe-room placement requires room sweep, belongings/body-check process, sitter or BH tech assignment, and security awareness when needed.
5. Incoming EMS radio reports should be considered before consuming the only resus or monitored respiratory-ready space.
6. Pediatric respiratory rooming requires appropriate equipment and staff readiness.
7. Charge RN should prepare a practical rooming/offload plan and unresolved-gate brief rather than launching several tentative moves.

Operational reminder: Placing the wrong patient in a quick space can block safer care and create a second emergency.
