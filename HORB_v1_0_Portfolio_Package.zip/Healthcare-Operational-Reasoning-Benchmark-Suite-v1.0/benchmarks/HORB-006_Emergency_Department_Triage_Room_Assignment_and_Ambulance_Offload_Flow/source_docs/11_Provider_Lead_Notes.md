# Provider Lead Notes

ED Provider Lead Notes  
Updated: 6:10 PM

**Angela Wells**  
Provider reviewed repeat EKG and asked that she not be sent to fast track. Needs monitored bed or immediate provider reassessment, repeat troponin draw, and cardiac monitor.

**Mateo Ruiz**  
Provider notified of lactate and hypotension. Needs sepsis evaluation, IV access, cultures/fluids/antibiotics per team decision, and not hallway placement.

**Brianna Cole**  
Behavioral health evaluation appropriate after medical screening and safe-room process. Do not place in safe room until sweep/sitter/security status confirmed.

**Ethan Shaw**  
Could discharge if provider reassessment complete and instructions printed, but provider has not reassessed since CT result.

**DeAndre Miles**  
Incoming CPAP should use resus or respiratory-ready monitored room.

Provider note: Room pressure is real, but high-risk updates should override earlier board assignments.
