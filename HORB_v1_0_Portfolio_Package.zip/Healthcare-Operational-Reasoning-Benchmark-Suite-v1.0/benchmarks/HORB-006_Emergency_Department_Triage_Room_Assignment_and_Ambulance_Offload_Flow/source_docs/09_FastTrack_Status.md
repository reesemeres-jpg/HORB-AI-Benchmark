# FastTrack Status

Fast Track and Minor Care Status  
Updated: 6:08 PM

| Patient / space | Status |
|---|---|
| Fast Track 1 / Nolan Grant | Finger laceration, stable, appropriate for repair |
| Fast Track 3 | Clean; no monitor; can take low-risk quick-care patient |
| Angela Wells | Board links to Fast Track 3, but repeat EKG and troponin issue under review |
| Olivia Young | Not appropriate for adult fast track due pediatric respiratory symptoms |
| Ethan Shaw | Not fast track; in Room 9 awaiting discharge reassessment |
| ED tech | Can assist with laceration setup or EKG redraw, not both simultaneously |

Fast-track note: Fast-track room availability should not override chest-pain monitoring, pediatric respiratory, or repeat-lab needs.
