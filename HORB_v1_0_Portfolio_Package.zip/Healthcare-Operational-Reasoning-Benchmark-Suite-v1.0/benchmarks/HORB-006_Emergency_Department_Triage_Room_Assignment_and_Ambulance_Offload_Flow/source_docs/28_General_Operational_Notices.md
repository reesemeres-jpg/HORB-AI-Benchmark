# General Operational Notices

General ED Operations Notices

- A green board row can lag repeat vitals, EKG changes, lab errors, EMS radio, and safety updates.
- Fast track should not absorb patients with unresolved chest pain pathway needs.
- Hallway placement should not absorb patients with hypotension and elevated lactate.
- Clean behavioral health rooms still need sweep, sitter, and security processes.
- Resus space should be protected when a CPAP ambulance is minutes away unless a current patient has greater immediate need.
- Possible stroke arrivals need immediate screen even before a formal activation is posted.
- ED tech, RT, security, and transport limits should shape the first action.
- Families should receive clear updates but not room-time promises.
- The safest plan may be a blocker brief rather than a named first move.
- Update the tracking board after live owner decisions close.
