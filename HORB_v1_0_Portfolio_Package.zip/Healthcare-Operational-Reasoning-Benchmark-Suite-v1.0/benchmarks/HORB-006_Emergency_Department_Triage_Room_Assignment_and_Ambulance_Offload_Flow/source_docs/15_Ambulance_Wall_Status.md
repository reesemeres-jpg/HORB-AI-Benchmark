# Ambulance Wall Status

Ambulance Wall / Offload Status  
Updated: 6:11 PM

| Unit / patient | Current status |
|---|---|
| EMS Wall Unit 12 | 66M near syncope/dizziness; crew reports earlier hypotension and paced rhythm; still on EMS stretcher |
| EMS Unit 8 / DeAndre | Incoming on CPAP ETA 6:18; asks for resus/monitored respiratory space |
| EMS Unit 3 / Fatima | Incoming possible stroke ETA 6:20; ED screen needed immediately on arrival |
| Police transport | Agitated adult ETA 6:25; safe-room/security status unclear |
| Clinic Rosa | Hyperkalemia transfer ETA 6:30 |

Ambulance note: Offload pressure matters, but assigning the only ready resus space should account for incoming respiratory and possible stroke needs.
