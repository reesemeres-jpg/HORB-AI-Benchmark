# Transport Tech Status

ED Tech, Transport, and Support Status  
Updated: 6:11 PM

| Resource | Status |
|---|---|
| ED tech | Available for one immediate task: EKG/troponin redraw, peds cart restock, or patient transport |
| Transport aide | In CT with inpatient transfer; not available until 6:30 |
| EVS | Cleaning Monitored Room 5; no ready time before 6:35 |
| Lab runner | Can take one stat redraw before 6:20 |
| Radiology transporter | Not available for Gloria x-ray until after 6:25 |
| Respiratory therapist | Available for one respiratory patient before 6:30 |
| Security | Ambulance bay until 6:20 |
| Sitter pool | No sitter released yet |
| Registration | Backed up; can still register EMS arrivals bedside |

Support note: The ED cannot safely perform every prep task at once. Assign the first tech/RT/security tasks based on current acuity.
