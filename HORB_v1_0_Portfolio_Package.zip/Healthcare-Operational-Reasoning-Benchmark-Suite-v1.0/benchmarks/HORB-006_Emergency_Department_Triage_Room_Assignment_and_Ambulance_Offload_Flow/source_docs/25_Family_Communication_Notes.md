# Family Communication Notes

Family and Patient Communication Notes  
Updated: 6:12 PM

**Angela Wells**  
Husband is worried about recurrent chest pressure. Staff should not say she is "just fast track" while EKG/troponin review is active.

**Mateo Ruiz**  
Daughter is worried about confusion and hallway placement. Staff should acknowledge reassessment and sepsis workup concerns.

**Brianna Cole**  
Sister is worried about elopement. Staff should explain safety rooming steps without promising immediate safe-room placement.

**Olivia Young**  
Parent is concerned about breathing noise. Staff should explain peds reassessment and equipment restock.

**Gloria Finch**  
Daughter upset about hallway pain. Needs update, but higher-acuity rooming conflicts should be explained.

Communication note: Waiting-room updates should be honest about priority and safety gates without overpromising room times.
