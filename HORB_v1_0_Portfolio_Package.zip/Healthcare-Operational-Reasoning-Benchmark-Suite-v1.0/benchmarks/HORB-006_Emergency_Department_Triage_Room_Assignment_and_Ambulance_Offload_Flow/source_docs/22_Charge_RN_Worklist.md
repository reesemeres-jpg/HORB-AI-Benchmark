# Charge RN Worklist

ED Charge RN Worklist  
Generated: 6:12 PM

- Reconcile ED board with repeat vitals, EKG/lab updates, EMS radio, room status, and security/sitter status.
- Interrupt provider lead for Angela repeat EKG/troponin plan and monitored room decision.
- Ask triage RN to keep Angela out of Fast Track 3 until provider clears.
- Interrupt provider lead or sepsis resource for Mateo hypotension/lactate and IV/lab priorities.
- Do not place Mateo in Hallway 2 unless provider confirms it is safe despite sepsis concerns.
- Hold Brianna in supervised triage until safe room sweep, sitter/BH tech, and security plan are closed.
- Assign RT/Resus 1 plan for DeAndre CPAP arrival.
- Prepare immediate screen plan for Fatima possible stroke.
- Ask ED tech to prioritize the most time-sensitive task after provider decision.
- Ask RN B/provider whether Ethan can truly discharge and free Room 9.
- Ask EVS for monitored Room 5 update but do not plan around it before 6:25.
- Prepare huddle brief with one possible rooming move or clear no-move explanation.
