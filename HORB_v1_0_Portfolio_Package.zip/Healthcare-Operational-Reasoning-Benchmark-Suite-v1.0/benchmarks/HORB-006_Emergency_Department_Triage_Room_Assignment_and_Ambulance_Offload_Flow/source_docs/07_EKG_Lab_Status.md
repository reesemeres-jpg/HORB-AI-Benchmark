# EKG Lab Status

EKG and Lab Status  
Updated: 6:09 PM

| Patient | EKG/lab issue |
|---|---|
| Angela Wells | Repeat EKG at 6:02 shows new ST depressions compared with triage EKG; first troponin hemolyzed; redraw not done |
| Mateo Ruiz | Lactate 3.4; CBC pending; blood cultures not drawn |
| Rosa King | Outpatient potassium 6.1 reported by clinic; ED EKG not done yet |
| EMS Wall Unit 12 | EMS strip shows paced rhythm; ED EKG pending |
| DeAndre Miles | No ED labs yet; CPAP incoming |
| Fatima Noor | Stroke labs not drawn; no CT order until arrival screen |
| Ethan Shaw | CT negative; labs reviewed earlier |
| Gloria Finch | X-ray pending; head injury denied but anticoagulant noted |
| Nolan Grant | No lab issue |

Lab note: A single lab status or old EKG category should not drive rooming when newer critical results or repeat EKG changes exist.
