# Security Sitter Status

Security, Sitter, and Safe Room Status  
Updated: 6:08 PM

| Resource / patient | Status |
|---|---|
| Psych Safe Room 1 | Clean but contraband sweep not documented after prior use |
| Brianna Cole | Belongings bagged in triage; body check not completed; sitter not assigned |
| Behavioral health tech | Available after 6:30; currently escorting patient upstairs |
| Security officer | In ambulance bay until about 6:20 |
| Police transport | Incoming agitated adult around 6:25 |
| Ligature cart | In hallway cabinet, seal check pending |
| Crisis evaluator | On site but finishing another consult |
| Family waiting room | Crowded; no private family room open |

Safety note: A clean safe room is not ready for behavioral health rooming without sweep, sitter/security plan, and handoff.
