# ED Staffing View

ED Staffing and Assignments  
Posted: 6:05 PM

| Staff / role | Assignment |
|---|---|
| Charge RN | Triage flow, room assignment, ambulance wall, 6:25 huddle |
| Triage RN | Waiting room reassessments until 6:30 |
| RN A | Resus 1 / incoming critical patient if assigned |
| RN B | Rooms 8 and 9 |
| RN C | Hallway 1 and Room 12 if Room 12 opens |
| Fast Track RN | Fast Track 1 and 3 |
| Peds RN | Peds Room 6 after respiratory cart restocked |
| Behavioral health tech | Available after 6:30; currently escorting patient upstairs |
| Security officer | Covering ambulance bay until 6:20 |
| ED tech | One tech for EKGs, transport, stocking |
| Respiratory therapist | In ED; can support one respiratory patient before 6:30 |
| Provider lead | In sign-out; available for urgent interrupts |

Staffing note: The charge RN can complete one direct call or rooming decision at a time. Assignments must fit acuity, equipment, staffing, and safety needs.
