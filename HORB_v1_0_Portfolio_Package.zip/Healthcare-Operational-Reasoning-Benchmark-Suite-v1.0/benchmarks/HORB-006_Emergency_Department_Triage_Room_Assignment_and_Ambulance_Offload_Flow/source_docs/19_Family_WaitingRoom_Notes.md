# Family WaitingRoom Notes

Family / Waiting Room Notes  
Updated: 6:10 PM

**Angela Wells**  
Husband says chest pressure returned and asks why she is going to fast track.

**Mateo Ruiz**  
Daughter says he is "not acting like himself" and asks for him not to sit in hallway.

**Brianna Cole**  
Sister present, worried patient may try to leave if left alone.

**Olivia Young**  
Parent worried about breathing noise and fever.

**Gloria Finch**  
Daughter upset that patient is in hallway with hip pain.

**Nolan Grant**  
Stable, asking how long repair will take.

Family note: Family concerns are not the only basis for rooming, but they can highlight changes not visible on the tracking board.
