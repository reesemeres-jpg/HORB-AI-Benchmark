# Triage Status Summary

ED Triage Status Summary  
Updated: 6:09 PM

| Patient | Current triage status |
|---|---|
| Angela Wells | 58F chest pain improved; initial board suggests Fast Track; repeat EKG from 6:02 shows new ST depressions; first troponin specimen hemolyzed |
| Mateo Ruiz | 74M fever/weakness; originally hallway candidate; repeat BP 88/54 after triage; lactate 3.4 resulted; daughter says more confused than baseline |
| Brianna Cole | 31F suicidal statements; cooperative right now; belongings bagged but contraband sweep of safe room not documented; sitter coverage not assigned |
| Olivia Young | 5F cough/fever; possible croup; oxygen 93% while crying; peds respiratory cart not restocked |
| Ethan Shaw | 42M abdominal pain; CT negative; pain improved; discharge pending provider reassessment |
| Gloria Finch | 81F fall with hip pain; on apixaban; x-ray pending; hallway location uncomfortable |
| Nolan Grant | 24M finger laceration; stable; fast-track repair appropriate |
| EMS Wall Unit 12 | 66M dizziness/near syncope; crew reports paced rhythm and hypotension earlier; still on stretcher |
| DeAndre Miles | Incoming SOB on CPAP; needs resus or respiratory-ready monitored space |
| Fatima Noor | Incoming possible stroke; last-known-well unclear from EMS radio |

Status note: Earlier triage category may not reflect newer EKG, lab, repeat vital signs, EMS radio, or safety updates.
