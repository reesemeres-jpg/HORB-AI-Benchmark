# Discharge And BedTurn Status

Discharge / Bed Turn Status  
Updated: 6:11 PM

| Patient / room | Status |
|---|---|
| Ethan Shaw / Room 9 | CT negative and pain improved, but provider reassessment and discharge instructions not complete |
| Monitored Room 5 | Dirty after isolation rule-out; EVS cleaning, earliest 6:35 |
| Room 12 | Clean but monitor battery missing; could become monitored if battery replaced and RN accepts |
| Fast Track 3 | Clean, no monitor |
| Hallway 2 | Empty, not monitored |
| Peds Room 6 | Clean, but respiratory cart restock incomplete |
| Psych Safe Room 1 | Clean, but sweep/sitter/security process incomplete |

Bed-turn note: The fastest physical space is not always the safest first rooming choice.
