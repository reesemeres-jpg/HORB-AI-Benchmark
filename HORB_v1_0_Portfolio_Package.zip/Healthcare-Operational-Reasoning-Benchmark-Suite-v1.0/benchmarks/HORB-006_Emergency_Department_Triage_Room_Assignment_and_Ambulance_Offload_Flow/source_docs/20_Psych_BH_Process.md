# Psych BH Process

Behavioral Health Rooming Process  
Updated: 6:10 PM

Process steps before behavioral health rooming:
1. Medical screening triage status documented.
2. Belongings secured.
3. Safe room sweep documented.
4. Ligature-risk cart/seal checked.
5. Sitter or behavioral health tech assigned.
6. Security aware if elopement or agitation risk.
7. Crisis evaluator notified after medical clearance step.

Current Brianna status:
- Belongings bagged.
- Body check not completed.
- Safe room sweep not documented.
- Sitter not assigned.
- Security not available until about 6:20.
- Crisis evaluator busy with another consult.

Process note: A clean safe room alone is not enough for safe behavioral health placement.
