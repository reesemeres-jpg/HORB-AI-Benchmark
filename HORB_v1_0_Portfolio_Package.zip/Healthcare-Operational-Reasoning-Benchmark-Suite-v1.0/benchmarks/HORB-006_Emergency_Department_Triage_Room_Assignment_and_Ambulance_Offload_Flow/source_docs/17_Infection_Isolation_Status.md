# Infection Isolation Status

Infection / Isolation Status  
Updated: 6:10 PM

| Patient / room | Status |
|---|---|
| Mateo Ruiz | Fever, possible sepsis; no isolation flag, but cultures and source workup pending |
| Olivia Young | Respiratory symptoms; mask placed; peds respiratory equipment pending |
| DeAndre Miles | Severe respiratory distress on CPAP; mask/respiratory precautions expected |
| Monitored Room 5 | Dirty after prior isolation rule-out |
| Triage area | Masks available |
| Waiting room | Crowded |
| Gloria Finch | No isolation issue |
| Brianna Cole | No isolation issue; safety issue |

Infection note: Respiratory and fever patients can affect room choice and cleaning needs.
