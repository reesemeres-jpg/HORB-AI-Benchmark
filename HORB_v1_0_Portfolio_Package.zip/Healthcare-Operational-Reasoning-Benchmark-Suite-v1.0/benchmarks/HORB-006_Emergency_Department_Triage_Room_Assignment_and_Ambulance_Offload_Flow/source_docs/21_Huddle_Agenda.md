# Huddle Agenda

ED Triage and Rooming Huddle  
Scheduled: 6:25 PM

Requested decisions:
- Is there a defensible first rooming/offload move before 6:25?
- Can Angela go to Fast Track 3, or do repeat EKG/troponin issues require monitored care?
- Can Mateo go to Hallway 2, or do hypotension/lactate/confusion require roomed sepsis evaluation?
- Can Brianna go to Psych Safe Room 1, or do sweep/sitter/security steps block placement?
- Should Resus 1 be held for DeAndre on CPAP or used for a current waiting-room patient?
- How should Fatima possible stroke be received on arrival?
- What should be done with EMS Wall Unit 12 before more ambulances arrive?
- Which one ED tech task should happen first?
- What can be safely deferred to fast track or later reassessment?
- What should be communicated to waiting families without overpromising?

Huddle note: Bring current blockers and owners. Do not rely on green tracking-board status alone.
