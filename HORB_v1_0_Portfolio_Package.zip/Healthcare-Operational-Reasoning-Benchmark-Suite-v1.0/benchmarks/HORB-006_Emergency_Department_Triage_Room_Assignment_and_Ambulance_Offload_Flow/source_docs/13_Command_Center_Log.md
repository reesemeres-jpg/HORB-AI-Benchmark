# Command Center Log

ED Operations Log  
5:45–6:12 PM

5:45 — ED waiting room count 18.  
5:50 — Fast Track 3 marked clean.  
5:55 — Hallway 2 opened after discharge.  
6:00 — Resus 1 cleaned and respiratory setup checked.  
6:02 — Angela repeat EKG uploaded.  
6:04 — Angela fast-track route questioned by provider.  
6:06 — Mateo lactate 3.4 and hypotension documented.  
6:07 — Psych Safe Room 1 marked clean but sweep not documented.  
6:08 — Room 12 clean but monitor battery missing.  
6:09 — DeAndre CPAP incoming.  
6:10 — Fatima possible stroke incoming, no activation yet.  
6:11 — ED tech assigned to either EKG redraws or peds restock, not both simultaneously.  
6:12 — Charge asked to bring first-rooming plan or blocker list to 6:25 huddle.
