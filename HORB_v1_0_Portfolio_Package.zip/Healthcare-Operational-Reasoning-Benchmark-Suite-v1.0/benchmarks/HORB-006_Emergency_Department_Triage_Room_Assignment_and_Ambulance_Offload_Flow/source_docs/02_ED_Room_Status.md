# ED Room Status

ED Room, Hallway, and Fast Track Status  
Updated: 6:08 PM

| Space | Status | Comment |
|---|---|---|
| Resus 1 | Clean | Open; respiratory setup checked |
| Resus 2 | Occupied | Trauma patient, no open time |
| Monitored Room 5 | Dirty | EVS requested after isolation rule-out; earliest 6:35 |
| Monitored Room 8 | Occupied | Chest pain patient awaiting second troponin |
| Room 9 | Occupied by Ethan | Possible discharge after provider reassessment |
| Room 12 | Clean | Telemetry monitor battery missing |
| Hallway 1 | Occupied by Gloria | Fall/hip pain |
| Hallway 2 | Empty | Not monitored; chair/stretcher space only |
| Fast Track 3 | Clean | No monitor; quick-treatment chair |
| Peds Room 6 | Clean | Respiratory cart not restocked |
| Psych Safe Room 1 | Clean | Contraband sweep not documented after previous use |
| Triage 2 | Clean | Can take brief reassessment |
| Triage 4 | Occupied by Brianna | Behavioral health intake ongoing |

Room note: A clean room, hallway space, or fast-track chair still needs acuity fit, equipment, staffing, infection/safety checks, and receiving nurse acceptance.
