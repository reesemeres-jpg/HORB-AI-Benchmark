# Stroke ChestPain Sepsis Pathways

ED Pathway Reminders  
Updated: 6:10 PM

Chest pain pathway:
- New EKG changes or recurrent chest pressure require monitored care and provider review.
- Hemolyzed troponin should be redrawn promptly if cardiac workup continues.
- Fast track is not appropriate for unstable or incompletely evaluated chest pain.

Sepsis pathway:
- Hypotension with elevated lactate should be roomed for sepsis evaluation and team response.
- Hallway placement is inappropriate if rapid IV access, frequent reassessment, or fluids/antibiotics are needed.

Stroke screen:
- Possible stroke arrival needs immediate provider/nurse screen, last-known-well clarification, and CT pathway decision.

Pathway note: Pathway needs do not automatically decide the final diagnosis, but they affect safe rooming and first tasks.
