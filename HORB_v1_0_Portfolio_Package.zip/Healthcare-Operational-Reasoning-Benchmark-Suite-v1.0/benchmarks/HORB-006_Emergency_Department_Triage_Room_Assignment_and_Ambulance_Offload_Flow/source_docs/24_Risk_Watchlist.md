# Risk Watchlist

ED Triage / Rooming Risk Watchlist  
Updated: 6:12 PM

High risk / rooming pressure:
- Angela: green fast-track row but new EKG changes, recurrent chest pressure, and hemolyzed troponin.
- Mateo: green hallway row but hypotension, elevated lactate, fever, and confusion.
- DeAndre: incoming CPAP patient likely needs Resus 1 and RT.
- Fatima: possible stroke incoming; needs immediate screen.
- EMS Wall Unit 12: offload delay with prior hypotension/paced rhythm.
- Brianna: behavioral health safety process incomplete.
- Room 12: clean but monitor battery missing.
- ED tech/RT/security: each can support only limited immediate tasks.

Medium risk:
- Olivia: pediatric respiratory symptoms and equipment restock issue.
- Gloria: anticoagulated fall with hip pain; hallway discomfort but not the first rooming release if higher risks unresolved.
- Ethan: possible discharge but not complete.
- Nolan: stable fast-track laceration.
