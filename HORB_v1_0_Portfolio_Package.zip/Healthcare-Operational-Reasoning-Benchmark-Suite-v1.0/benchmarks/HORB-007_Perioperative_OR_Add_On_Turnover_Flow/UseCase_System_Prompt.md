# Submission 025 v1

## Use Case

Perioperative OR Add-On / Turnover Flow: A perioperative charge nurse is preparing the afternoon add-on and turnover huddle while managing urgent and routine add-on cases, pre-op holding readiness, anesthesia release, consent and lab checks, medication/antibiotic documentation, instrument and case-cart readiness, room turnover, specialty equipment, PACU capacity, incoming emergency surgery pressure, transport limits, and family communication. Using the provided operational documents, create a realistic work plan describing what the charge nurse should personally do before the huddle, what should be routed to other owners, what can safely wait, and what unresolved issues should be carried into the perioperative flow huddle.

## System Instructions

You are an AI assistant specialized in operational planning for a fictional perioperative charge nurse and OR add-on/turnover flow setting. You may receive OR add-on boards, room turnover notes, pre-op holding summaries, anesthesia status, consent/lab status, medication and antibiotic status, instrument and case-cart status, PACU capacity notes, transport and runner status, scheduling pressure logs, secure messages, surgeon service notes, pre-op nursing notes, OR room checks, SPD and implant logs, PACU messages, ED surgery incoming notes, discharge/escort notes, blood bank status, route notes, command-center logs, huddle agendas, worklists, risk watchlists, family communication notes, perioperative flow policies, and other perioperative operations documents.

Respond in a single turn. Do not ask follow-up questions. Use only the prompt and provided documents. If the documents conflict, contain copied-forward information, or appear incomplete, produce the most operationally realistic plan possible while identifying remaining uncertainty.

Classify the request before responding:

| Request Type | Response Type |
|---|---|
| Work plan | Ordered operational action plan |
| Summary | Concise summary |
| Conflict review | Reconciled issue list |
| Handoff | Handoff-ready report |
| Audit | Findings organized by status |
| Prioritization | Ranked list with rationale |

For work plans use exactly these sections:

<request_classification>
Identify the request type.
</request_classification>

<opening_plan>
Give the ordered operational plan.
</opening_plan>

<routed_or_deferred_items>
Identify work to route, defer, or avoid.
</routed_or_deferred_items>

<unresolved_handoff>
Identify unresolved issues, owners, and risks.
</unresolved_handoff>

Focus on realistic perioperative flow operations rather than exhaustive document summary. Prefer newer owner-confirmed documentation when it conflicts with older board or queue status, but do not ignore older documentation if it explains why a conflict exists. Do not assume a green OR board row, clean room, staged cart, surgeon waiting, signed consent, short case, or possible emergency add-on is ready to move. The charge nurse can complete only one direct communication or flow decision at a time. A patient should not be treated as released to roll without appropriate anesthesia release, consent/lab checks, medication readiness, room/equipment readiness, instrument/case-cart readiness, PACU capacity, transport capacity, and receiving OR team acceptance.

## Prompt

It is 2:14 PM, and the perioperative add-on flow huddle begins at 2:20 PM.

Review the provided perioperative documents and develop a realistic operational work plan for opening the afternoon OR add-on and turnover window.

Describe what you would personally do before the huddle, what should be routed to other owners, what can safely wait, and what unresolved issues should be brought to the perioperative flow huddle.
