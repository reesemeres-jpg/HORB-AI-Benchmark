# BloodBank And Emergency Readiness

Blood Bank and Emergency OR Readiness  
Updated: 2:10 PM

| Patient / resource | Status |
|---|---|
| Nolan Reed | Type and screen sent from ED, not resulted; blood bank aware only if OR activation occurs |
| Lara Nguyen | No blood bank issue expected |
| Marcus Hill | No type/screen required by ortho, per current plan |
| Evelyn Park | No blood bank issue expected |
| Trauma OR | Not opened; emergency cart available |
| Massive transfusion cooler | Available if activated |
| Blood bank runner | Available if Nolan activates |

Blood bank note: Possible emergency readiness should be tracked, but it is not the same as a confirmed OR case.
