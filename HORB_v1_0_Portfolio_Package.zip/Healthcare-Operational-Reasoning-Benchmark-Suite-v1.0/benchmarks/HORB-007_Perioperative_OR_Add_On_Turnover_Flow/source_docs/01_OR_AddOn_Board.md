# OR Add-On Board

Perioperative Add-On / Turnover Board  
Generated: 2:07 PM  
Display source: OR scheduling board

| OR / area | Patient | Procedure | Visible next step | Board color |
|---|---|---|---|---|
| OR-3 | Lara Nguyen | Laparoscopic appendectomy | Roll from Pre-op Bay 4 | Green |
| OR-6 | Marcus Hill | Ankle ORIF | Roll from Pre-op Bay 7 | Green |
| OR-8 | Evelyn Park | Hysteroscopy / D&C | Roll from Pre-op Bay 2 | Green |
| OR-10 | Jamal Price | Port placement | Waiting for room | Yellow |
| Pre-op Bay 9 | Sonia Feld | Debridement add-on | Surgical review pending | Yellow |
| PACU-04 | Henry Liu | Post-op recovery | Floor transfer pending | Yellow |
| PACU-08 | Carmen Diaz | Post-op airway watch | Continue PACU | Red |
| OR-12 | Empty | Turnover in progress | Available after clean | Yellow |

Incoming / pressure:
| Source | Patient / case | Note | ETA |
|---|---|---|---|
| ED surgery | Nolan Reed | Possible emergent ex-lap | 2:35 |
| Endoscopy | Vera Cole | Needs PACU monitored recovery | 2:45 |
| Ortho clinic | Rae Morgan | Fracture add-on possible | Unknown |
| OR desk | Room pressure | Wants at least one add-on rolling by 2:25 |

Board note: Green reflects the scheduling-board view only. It may not reflect current anesthesia release, consent, pregnancy/lab status, antibiotics, instrument readiness, PACU capacity, transport, or OR team acceptance.
