# Transport Runner Status

Transport / OR Runner Status  
Updated: 2:10 PM

| Resource | Status |
|---|---|
| Pre-op transporter | Available for one patient movement before 2:30 |
| OR runner | Available for one equipment/supply route before 2:25 |
| PACU transporter | With floor transfer; available after 2:30 |
| C-arm tech | Finishing case in OR-14; earliest 2:25 |
| Blood bank runner | Available if Nolan ex-lap activates |
| Family liaison | Covering waiting-room calls |
| EVS | Cleaning OR-12 |
| SPD runner | Bringing trays from SPD; can do one priority delivery |

Route note: Transport wants one confirmed patient/equipment route after anesthesia, OR, equipment, and recovery gates are settled.
