# OR Room Turnover Status

OR Room and Turnover Status  
Updated: 2:09 PM

| Room | Status | Comment |
|---|---|---|
| OR-3 | Clean | Laparoscopic tower present; anesthesia machine checkout not signed after morning leak test |
| OR-6 | Clean | Ortho table ready; C-arm requested but not yet in room |
| OR-8 | Clean | Hysteroscopy tower ready; fluid management tubing missing from case cart |
| OR-10 | Occupied | Vascular case closing late |
| OR-12 | Turnover in progress | EVS estimates 2:30 if no delay |
| Trauma OR | On standby | Reserved if Nolan emergent ex-lap activates |
| Pre-op Bay 2 | Occupied by Evelyn | Day surgery pathway |
| Pre-op Bay 4 | Occupied by Lara | Add-on pathway |
| Pre-op Bay 7 | Occupied by Marcus | Ortho add-on pathway |
| PACU overflow chair | Available | Not for airway-watch or high-monitoring patients |

Room note: A clean OR still requires anesthesia checkout, equipment, instrument, staffing, and receiving-side readiness.
