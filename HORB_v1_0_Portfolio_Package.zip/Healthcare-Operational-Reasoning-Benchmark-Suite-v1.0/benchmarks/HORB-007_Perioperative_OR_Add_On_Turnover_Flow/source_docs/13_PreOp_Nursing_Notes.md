# PreOp Nursing Notes

Pre-op Nursing Notes  
Updated: 2:12 PM

**Lara Nguyen / Bay 4**  
Patient ready in gown, IV patent, family updated. Pregnancy test collected but not visible in results. Metronidazole not documented as administered. Patient reports nausea but no emesis.

**Marcus Hill / Bay 7**  
Patient anxious and wants to proceed. Home med reconciliation inconsistent regarding apixaban. Regional block consent not signed because anesthesia plan not finalized.

**Evelyn Park / Bay 2**  
Patient dressed and consented. Spouse left to pick up child and may return around 3:30. Patient says neighbor could drive, but no adult escort verified in chart.

**Jamal Price**  
Waiting calmly. Platelet result pending.

**Sonia Feld**  
Needs surgeon bedside review before consent.

Pre-op note: Ready-in-gown does not equal ready-to-roll.
