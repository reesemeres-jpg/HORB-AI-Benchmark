# Transport Equipment Routes

Transport and Equipment Route Status  
Updated: 2:12 PM

| Route / task | Typical time | Current gate |
|---|---:|---|
| Pre-op Bay 4 to OR-3 / Lara | 5–7 min | Pregnancy result, antibiotic charting, anesthesia note/machine checkout |
| Pre-op Bay 7 to OR-6 / Marcus | 5–7 min | C-arm, implant tray B, anticoagulant/anesthesia plan |
| Pre-op Bay 2 to OR-8 / Evelyn | 5–7 min | Fluid tubing and escort plan |
| SPD to OR-6 | 6–8 min | Tray B quality review not complete |
| Supply room to OR-8 | 4–6 min | Tubing being located |
| PACU-04 to floor / Henry | 8–12 min | Pain-plan acceptance |
| ED to trauma OR / Nolan | 8–12 min | Activation pending |
| OR runner route | One priority route before 2:25 | Needs confirmed target |

Transport note: Movement should follow release decisions, not create them.
