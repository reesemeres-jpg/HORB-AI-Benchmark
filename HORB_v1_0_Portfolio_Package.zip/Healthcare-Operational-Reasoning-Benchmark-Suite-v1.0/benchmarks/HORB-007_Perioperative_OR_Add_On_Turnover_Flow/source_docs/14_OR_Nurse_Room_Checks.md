# OR Nurse Room Checks

OR Nurse Room and Equipment Checks  
Updated: 2:11 PM

| Room | Circulator check |
|---|---|
| OR-3 | Room clean, lap tower powered on, insufflator checked, but anesthesia machine checkout signature missing |
| OR-6 | Room clean, ortho table ready, implant tray A present, implant tray B not in room, C-arm not delivered |
| OR-8 | Room clean, hysteroscopy tower ready, fluid management tubing missing |
| OR-10 | Still occupied |
| OR-12 | Turnover active; not available |
| Trauma OR | Standby, not opened |

Circulator note: Room setup should be called "setup pending" if required equipment or anesthesia checkout is incomplete.
