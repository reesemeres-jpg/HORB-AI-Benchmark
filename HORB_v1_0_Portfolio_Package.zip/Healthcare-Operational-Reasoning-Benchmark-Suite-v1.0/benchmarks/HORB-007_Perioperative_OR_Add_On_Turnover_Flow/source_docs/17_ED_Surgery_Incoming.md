# ED Surgery Incoming

ED Surgery Incoming Add-On  
Updated: 2:12 PM

**Nolan Reed**  
ED surgery evaluating for possible emergent exploratory laparotomy. Patient has worsening abdominal pain and concerning CT per ED verbal report. Surgery attending reviewing images. No final OR activation posted yet. If activated, anesthesia wants trauma OR, blood bank alert, and PACU monitored recovery plan.

ED surgery note:
"Do not hold every room indefinitely, but keep trauma capacity visible until we decide."

Incoming note: Nolan is not a confirmed OR route yet, but he may change room and PACU priorities quickly.
