# Family Communication Notes

Family / Waiting Room Communication Notes  
Updated: 2:12 PM

**Lara Nguyen**  
Family expects surgery soon because ED told them she was an add-on. They should not be promised a roll time until readiness gates close.

**Marcus Hill**  
Patient is anxious and spouse is asking why the surgeon is ready but transport has not arrived.

**Evelyn Park**  
Patient says spouse left for school pickup and neighbor might help. Staff need verified responsible adult or revised discharge plan before proceeding as ambulatory case.

**Jamal Price**  
Family waiting for port placement timing.

**Nolan Reed**  
ED family has not been told surgery is definite.

Communication note: Avoid exact OR times until anesthesia, equipment, consent/lab, PACU, and route decisions are closed.
