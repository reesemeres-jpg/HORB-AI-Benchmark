# Risk Watchlist

Perioperative Add-On Risk Watchlist  
Updated: 2:14 PM

High risk / schedule pressure:
- Lara: green urgent add-on but pregnancy/antibiotic/anesthesia/machine-check gates unresolved.
- Marcus: green ortho add-on but implant tray, C-arm, anticoagulant history, and anesthesia plan unresolved.
- Evelyn: green short case but tubing and escort/discharge plan unresolved.
- PACU: only one possible clean bay if staffed; airway-watch patient blocks easy capacity assumptions.
- Nolan: possible emergent ex-lap may change trauma OR, anesthesia, blood bank, and PACU priorities.
- Transport/runner: one confirmed movement/equipment route before 2:25.

Medium risk:
- Jamal: platelet count pending and no room.
- Sonia: no consent/surgeon review.
- Henry: PACU floor transfer delayed by pain-plan handoff.
- Carmen: airway watch, not near discharge.
