# Scheduling Pressure Log

OR Scheduling Pressure Log  
Updated: 2:10 PM

1:55 — OR desk asked for one add-on to roll by 2:25.  
1:58 — Surgery team said Lara should go as soon as safe.  
2:00 — Ortho team said Marcus surgeon is ready and patient is anxious.  
2:02 — GYN team said Evelyn is short case and could help turnover metrics.  
2:04 — PACU warned that recovery capacity is tight because Carmen cannot leave.  
2:06 — ED surgery called about Nolan possible ex-lap.  
2:08 — Anesthesia asked not to overpromise OR starts until PACU and machine/equipment issues clear.  
2:10 — Charge nurse asked to bring first-roll recommendation or blocker list to 2:20 huddle.

Scheduling note: Schedule pressure does not override anesthesia, equipment, medication, lab, consent, or PACU release gates.
