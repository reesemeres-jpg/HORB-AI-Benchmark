# PreOp Holding Status

Pre-op Holding Status Summary  
Updated: 2:10 PM

| Patient | Current pre-op status |
|---|---|
| Lara Nguyen | NPO since midnight; consent signed; pregnancy test collected but result not posted; antibiotics ordered but not documented as given; anesthesia note still unsigned |
| Marcus Hill | Consent signed; regional block discussed; last apixaban dose uncertain in med history; C-arm and implant tray pending |
| Evelyn Park | Consent signed; ride listed as spouse, but spouse left for school pickup; fluid tubing missing from cart |
| Jamal Price | Port placement consent present; no OR room yet; platelet count pending |
| Sonia Feld | Debridement add-on; wound photo and surgeon review pending |
| Henry Liu | PACU floor transfer delayed; receiving unit asked for pain plan |
| Carmen Diaz | PACU airway watch after opioid desaturation; cannot leave PACU yet |
| Nolan Reed | ED surgery evaluating; possible ex-lap, no final OR activation |

Status note: Earlier ready-to-roll marks may not reflect later lab, medication, anesthesia, equipment, escort, or PACU updates.
