# Recent Updates Digest

Recent Updates Digest  
Compiled 2:14 PM

- Lara looks like the obvious urgent add-on, but pregnancy test, metronidazole documentation, anesthesia note, and OR-3 machine checkout are not all closed.
- Marcus looks ready because OR-6 is clean and surgeon is present, but implant tray B, C-arm, anticoagulant timing, and anesthesia plan remain unresolved.
- Evelyn looks like a short case that could improve throughput, but fluid tubing is missing and the responsible adult escort is not verified.
- PACU capacity is tighter than the board suggests because Carmen remains airway watch and PACU-06 has no finalized receiving RN.
- Nolan may become emergent but is not activated yet.
- Jamal and Sonia are not immediate first-roll candidates due pending platelet count or surgeon review.
- One transporter and one runner can be used before 2:25, so tentative multi-case movement is unrealistic.
