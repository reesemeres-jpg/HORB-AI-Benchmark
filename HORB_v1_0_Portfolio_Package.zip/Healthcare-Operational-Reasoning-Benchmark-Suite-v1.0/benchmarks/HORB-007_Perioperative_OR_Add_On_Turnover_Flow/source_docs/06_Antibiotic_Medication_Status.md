# Antibiotic Medication Status

Medication and Antibiotic Status  
Updated: 2:09 PM

| Patient | Medication issue |
|---|---|
| Lara Nguyen | Ceftriaxone/metronidazole ordered; ceftriaxone charted in ED, metronidazole not documented as administered |
| Marcus Hill | Home med history lists apixaban, but pre-op interview says "blood thinner stopped maybe two days ago"; anesthesia asked for clarification |
| Evelyn Park | Standard pre-op meds ready; PONV prophylaxis requested |
| Jamal Price | Vancomycin pre-op dose not yet released because room timing unclear |
| Sonia Feld | Antibiotic plan pending surgeon review |
| Nolan Reed | ED broad-spectrum antibiotics being discussed if ex-lap activates |
| Carmen Diaz | Opioid-related desaturation in PACU; no new orders |
| Henry Liu | Pain plan needs floor handoff clarification |

Medication note: Medication uncertainty can block anesthesia and procedural readiness even when room and consent appear complete.
