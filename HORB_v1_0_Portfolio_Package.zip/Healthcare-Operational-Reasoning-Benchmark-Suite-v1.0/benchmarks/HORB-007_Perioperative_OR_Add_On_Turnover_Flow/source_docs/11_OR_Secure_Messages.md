# OR Secure Messages

Secure Messages  
Thread: Periop flow 1:58–2:12 PM

1:58 — OR Desk: Need one add-on rolling by 2:25 if possible.

2:00 — Pre-op RN: Lara's pregnancy test was sent. I do not see result yet.

2:01 — Anesthesia: Lara pre-op note not finalized and OR-3 machine checkout still needs signature.

2:02 — Surgery Resident: Lara should go soon, but yes, confirm antibiotics and pregnancy result.

2:03 — Ortho Circulator: OR-6 is clean. Marcus surgeon wants to roll.

2:04 — SPD: Marcus implant tray B still in quality review. C-arm not in room.

2:05 — Anesthesia: Marcus anticoagulant timing unclear. Need med-rec answer before final plan.

2:06 — GYN Circulator: Evelyn is short case and room is clean.

2:07 — Pre-op RN: Evelyn's spouse left for school pickup. Escort back uncertain.

2:08 — OR-8 Nurse: Hysteroscopy fluid tubing missing from cart.

2:09 — PACU Charge: We are tight. PACU-06 clean but no receiving RN assigned. Carmen still airway watch.

2:10 — ED Surgery: Nolan may need ex-lap. Not activated yet.

2:12 — Charge RN: Bring current blockers to 2:20 huddle. Do not roll based only on board green.
