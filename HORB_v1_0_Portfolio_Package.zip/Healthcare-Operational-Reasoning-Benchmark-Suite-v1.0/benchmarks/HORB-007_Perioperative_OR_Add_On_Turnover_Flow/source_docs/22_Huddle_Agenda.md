# Huddle Agenda

Perioperative Add-On Flow Huddle  
Scheduled: 2:20 PM

Requested decisions:
- Is there a defensible first roll before 2:25?
- Can Lara roll to OR-3, or do pregnancy test, antibiotic documentation, anesthesia note, and machine checkout block movement?
- Can Marcus roll to OR-6, or do implant tray B, C-arm, anticoagulant history, and anesthesia plan block movement?
- Can Evelyn roll to OR-8, or do fluid tubing and escort/discharge plan block movement?
- Should PACU-06 be considered available, or does receiving RN assignment remain unresolved?
- Should any room be held flexible for Nolan if ED surgery activates emergent ex-lap?
- Which single transport/equipment route should be used before 2:25?
- What can be told to OR desk and surgeons without overpromising?
- Which tasks should be routed to SPD, supply room, anesthesia, PACU, and pre-op?

Huddle note: Bring current blockers and owners. Do not rely on green OR board status alone.
