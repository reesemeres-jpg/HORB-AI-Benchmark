# General Operational Notices

General Perioperative Operations Notices

- A green OR board row can lag lab, medication, anesthesia, instrument, PACU, and transport updates.
- An urgent add-on still needs pregnancy/lab and medication gates closed when applicable.
- A room can be clean but not anesthesia-ready.
- A surgeon waiting does not make implants, C-arm, or anticoagulant questions resolved.
- A short case can still be blocked by missing supplies or escort/discharge issues.
- PACU should not be counted as open based only on a clean bay.
- One incoming emergency case can change room and recovery priorities quickly.
- One transporter and one runner cannot support several tentative starts at once.
- The charge nurse should give a blocker brief if no first roll is fully supported.
- Update the OR board after live owner decisions close.
