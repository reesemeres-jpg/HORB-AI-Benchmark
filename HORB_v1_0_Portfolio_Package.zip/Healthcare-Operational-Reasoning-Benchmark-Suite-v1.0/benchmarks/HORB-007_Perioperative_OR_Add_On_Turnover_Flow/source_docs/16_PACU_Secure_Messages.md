# PACU Secure Messages

PACU Secure Messages  
Thread: 2:00–2:12 PM

2:00 — PACU Charge: We can probably take one routine general case if PACU-06 gets RN assignment.

2:03 — PACU RN: Henry floor transfer delayed. Floor wants pain plan clarified.

2:04 — Floor Charge: Henry can come after pain-plan handoff, not before.

2:05 — Anesthesia PACU: Carmen had opioid desat; continue airway watch. Do not count PACU-08 as near discharge.

2:07 — PACU Charge: Overflow chair is low-acuity only.

2:09 — PACU Charge: If Nolan emergent ex-lap happens, we need to preserve monitored recovery plan.

2:11 — PACU Charge: Do not tell OR we have "two open bays." We have one possible bay if staffed.

2:12 — Charge RN: PACU capacity needs to be in huddle before first roll.
