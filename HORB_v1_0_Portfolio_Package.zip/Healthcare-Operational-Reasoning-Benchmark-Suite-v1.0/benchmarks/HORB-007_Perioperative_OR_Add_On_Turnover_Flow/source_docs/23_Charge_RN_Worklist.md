# Charge RN Worklist

Perioperative Charge RN Worklist  
Generated: 2:14 PM

- Reconcile OR board with pre-op notes, anesthesia notes, room checks, SPD status, PACU capacity, and ED surgery incoming.
- Ask pre-op/anesthesia for Lara pregnancy result, metronidazole documentation, anesthesia note signature, and OR-3 machine checkout.
- Ask SPD/OR nurse for Lara grasper substitute verification if Lara otherwise clears.
- Ask anesthesia/pre-op to clarify Marcus anticoagulant timing and block/general plan.
- Ask SPD/C-arm tech for Marcus implant tray B and C-arm ETA.
- Ask OR-8 nurse/supply room for Evelyn fluid tubing status.
- Ask pre-op/family liaison for Evelyn verified responsible adult or admitting plan.
- Ask PACU charge whether PACU-06 has a receiving RN and what cases it can safely accept.
- Ask ED surgery whether Nolan is activated or still under review.
- Hold pre-op transport until one route has closed gates.
- Prepare huddle brief with one possible roll or clear no-roll explanation.
- Update OR board only after owner decisions close.
