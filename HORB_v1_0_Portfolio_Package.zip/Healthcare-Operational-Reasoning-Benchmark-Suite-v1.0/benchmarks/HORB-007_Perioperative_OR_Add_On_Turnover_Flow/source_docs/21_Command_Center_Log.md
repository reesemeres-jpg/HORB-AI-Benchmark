# Command Center Log

Perioperative Command Center Log  
1:55–2:14 PM

1:55 — OR desk requested one add-on rolling by 2:25.  
1:58 — OR-3, OR-6, and OR-8 all appeared green on board.  
2:00 — Lara pregnancy test still not resulted.  
2:01 — OR-3 anesthesia machine checkout signature missing.  
2:03 — Marcus surgeon ready, but implant tray B and C-arm not in room.  
2:05 — Marcus anticoagulant timing questioned by anesthesia.  
2:07 — Evelyn spouse left; escort plan uncertain.  
2:08 — OR-8 fluid tubing missing.  
2:09 — PACU warned recovery capacity is one possible bay, not two.  
2:10 — Nolan possible emergent ex-lap reported by ED surgery.  
2:12 — Charge asked for blocker list before 2:20 huddle.  
2:14 — Board still shows Lara/Marcus/Evelyn green because status fields have not been updated.
