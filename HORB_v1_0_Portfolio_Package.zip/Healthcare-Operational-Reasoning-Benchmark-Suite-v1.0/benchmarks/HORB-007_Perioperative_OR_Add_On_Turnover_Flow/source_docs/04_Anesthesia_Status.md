# Anesthesia Status

Anesthesia and Airway Readiness  
Updated: 2:10 PM

| Patient / room | Status |
|---|---|
| Lara Nguyen | Pre-anesthesia assessment started; final note unsigned; machine checkout in OR-3 not signed after morning leak test |
| Marcus Hill | Regional block option discussed; anticoagulant timing unclear; anesthesia wants med-rec confirmation before block or general plan finalized |
| Evelyn Park | Prior PONV; anesthesia okay pending escort/discharge plan and equipment readiness |
| Carmen Diaz | PACU airway watch ongoing; anesthesia asked not to accept additional high-risk recovery until PACU plan clear |
| Nolan Reed | If activated, anesthesia wants trauma OR and blood bank alert |
| OR-3 | Machine checkout pending signature |
| OR-6 | Anesthesia setup available after one provider finishes pre-op call |
| OR-8 | Anesthesia available, but case cart issue pending |

Anesthesia note: "Ready room" does not equal anesthesia release. Unsigned assessments, machine checks, medication risk, and PACU constraints can block rolling.
