# PACU Capacity Status

PACU Capacity and Recovery Status  
Updated: 2:09 PM

| PACU location | Status | Comment |
|---|---|---|
| PACU-01 | Occupied | Routine recovery, possible discharge after 2:45 |
| PACU-02 | Occupied | Awaiting transport to floor |
| PACU-04 | Henry Liu | Floor transfer pending pain-plan acceptance |
| PACU-06 | Empty | Clean, but receiving RN assignment not finalized |
| PACU-08 | Carmen Diaz | Airway watch after desaturation; high monitoring |
| PACU-10 | Occupied | Pediatric recovery, family at bedside |
| Overflow chair | Empty | Low-acuity only; not for airway watch or fresh general anesthesia |
| Phase II Chair 3 | Empty | Available if escort/discharge criteria met |

PACU note: A clean bay or empty chair is not capacity unless nurse assignment, monitoring level, airway risk, and incoming case needs are addressed.
