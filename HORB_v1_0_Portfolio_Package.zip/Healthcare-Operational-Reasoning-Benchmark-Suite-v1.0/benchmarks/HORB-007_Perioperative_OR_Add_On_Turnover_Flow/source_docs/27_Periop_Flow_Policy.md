# Periop Flow Policy

Perioperative Add-On and Turnover Workflow

1. OR board color is a starting point, not final roll release.
2. Patient movement to OR requires current consent/lab checks, anesthesia release, room/equipment readiness, required medications, case cart/instrument readiness, transport, and recovery capacity.
3. Clean OR status does not override missing anesthesia checkout, instrument, implant, disposable, or specialty-equipment needs.
4. Short ambulatory cases still require discharge/escort readiness unless the plan changes.
5. PACU capacity must account for monitoring level, nurse assignment, and incoming case risk.
6. Possible emergency add-ons should be tracked without treating them as confirmed until activated.
7. Transport and runner tasks should follow a confirmed release decision, not create one.

Operational reminder: Rolling a patient before gates close can create an OR delay, unsafe handoff, or recovery bottleneck.
