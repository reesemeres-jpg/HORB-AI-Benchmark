# Consent Lab Status

Consent, Labs, and Required Checks  
Updated: 2:10 PM

| Patient | Consent/lab issue |
|---|---|
| Lara Nguyen | Surgical consent signed; pregnancy test collected at 1:48 but not resulted; CBC resulted; antibiotics not charted |
| Marcus Hill | Surgical consent signed; type/screen not required per surgeon; anticoagulant history inconsistent between home med list and pre-op interview |
| Evelyn Park | Surgical consent signed; urine pregnancy test negative; discharge escort status unresolved |
| Jamal Price | Port consent present; platelet count pending due prior thrombocytopenia |
| Sonia Feld | Consent not signed; surgeon review pending |
| Nolan Reed | ED consent pathway pending surgical decision |
| Henry Liu | No pre-op issue; PACU transfer issue |
| Carmen Diaz | No pre-op issue; recovery issue |

Lab note: A signed consent alone does not close all same-day readiness checks.
