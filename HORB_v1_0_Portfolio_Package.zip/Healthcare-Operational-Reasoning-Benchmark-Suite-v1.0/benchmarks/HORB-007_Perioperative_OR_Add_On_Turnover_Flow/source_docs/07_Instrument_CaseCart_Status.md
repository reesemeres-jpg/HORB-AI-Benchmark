# Instrument CaseCart Status

SPD / Case Cart Status  
Updated: 2:10 PM

| Case | Cart / instrument status |
|---|---|
| Lara Nguyen | Lap appy cart staged; one 5 mm grasper replacement listed but not verified by OR nurse |
| Marcus Hill | Ankle ORIF cart staged; implant tray B still in SPD quality review; C-arm not delivered |
| Evelyn Park | Hysteroscopy cart staged; fluid management tubing missing from cart |
| Jamal Price | Port placement tray ready |
| Sonia Feld | Debridement cart not pulled |
| Nolan Reed | Ex-lap emergency cart sealed and available if trauma OR activated |
| OR-3 | Laparoscopic tower present |
| OR-6 | Ortho table present; C-arm pending |
| OR-8 | Hysteroscopy tower present; tubing missing |

SPD note: A staged case cart is not released until required instruments, specialty supplies, and room equipment are verified by the appropriate owner.
