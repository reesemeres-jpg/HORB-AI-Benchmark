# Surgeon Service Notes

Surgeon and Service Notes  
Updated: 2:12 PM

**Lara Nguyen — General Surgery**  
Surgery wants laparoscopic appendectomy this afternoon. Resident notes patient is stable but should not wait unnecessarily. Attending asks that pregnancy test and antibiotic administration be confirmed before moving to OR.

**Marcus Hill — Orthopedics**  
Surgeon ready for ankle ORIF and says room delay is frustrating. Ortho agrees C-arm and implant tray B are required before incision.

**Evelyn Park — GYN**  
GYN says case is short and could proceed if hysteroscopy setup and discharge plan are complete. Surgeon does not want patient rolled if fluid tubing is missing.

**Jamal Price — Vascular Access**  
Can wait for OR-10 or OR-12 once platelet count is known.

**Sonia Feld — Surgery**  
Needs wound review and consent before any room assignment.

Service note: Surgeon urgency should be balanced against specific release gates for each case.
