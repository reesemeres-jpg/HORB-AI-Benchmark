# HORB-007: Perioperative OR Add-On / Turnover Flow

**Suite:** Healthcare Operational Reasoning Benchmark Suite  
**Version:** 1.0  
**Author:** Meredith Reese, RN  
**Original File Mapping:** Submission 025

> Evaluating operational reasoning under uncertainty in perioperative operations.

## Clinical Domain

Perioperative Operations

## Operational Setting

Afternoon OR add-on and turnover coordination window

## Operational Window

2:14 PM to 2:20 PM before the Perioperative add-on flow huddle.

## Primary Capability Evaluated

OR add-on sequencing and turnover operational reasoning.

## Purpose

Evaluates whether an AI system can coordinate perioperative add-on and turnover flow involving OR room status, case urgency, anesthesia coverage, PACU capacity, instrumentation, patient readiness, vendor/equipment needs, transport, and short-window huddle preparation.

## Primary Evaluation Question

> **Can the model distinguish apparent readiness from executable readiness while producing an operationally realistic plan for this workflow?**

## Capability Profile

| Capability | Evaluated |
|---|:---:|
| Multi-document reasoning | ✓ |
| Operational prioritization | ✓ |
| Temporal reasoning | ✓ |
| Workflow coordination | ✓ |
| Resource allocation | ✓ |
| Ownership boundaries | ✓ |
| Source provenance | ✓ |
| Uncertainty management | ✓ |


## Operational Actors

- OR charge nurse
- Anesthesia lead
- Surgeons / services
- PACU charge
- Pre-op nurses
- SPD / sterile processing
- Transport
- Vendor / equipment support
- Bed control if relevant


## Reasoning Challenges

- Add-on urgency versus readiness
- Turnover status and room release
- Anesthesia and PACU availability
- Instrumentation and equipment readiness
- Patient transport and consent readiness
- Vendor dependencies
- Competing room pressure
- Short huddle window


## Typical Failure Modes

- Choosing a first add-on from board status alone
- Assuming turnover means case-ready
- Ignoring PACU or anesthesia constraints
- Opening instruments prematurely
- Sequencing cases without owner release
- Overcommitting transport or room resources


## Expected High-Quality Response

A strong response should:

- Integrate information across multiple documents.
- Distinguish confirmed information from apparent readiness.
- Respect ownership boundaries and role authority.
- Recognize unresolved dependencies.
- Prioritize realistically under time and resource constraints.
- Recommend only operationally executable actions.
- Carry unresolved issues forward to the appropriate huddle or owner.

## Included Materials

- `UseCase_System_Prompt.md`
- `Strict_Grading_Guidelines.md`
- `source_docs/` (28 fictional operational documents)
- `SourceDocs.zip`
- `original_batches/`

## Estimated Difficulty

**Expert**

## Estimated Human Evaluation Time

Approximately **30–45 minutes**.

## Design Notes

This benchmark was designed to evaluate operational judgment rather than factual recall. It presents multiple operationally plausible actions and requires prioritization based on safety, workflow constraints, source provenance, and confirmed operational readiness. The benchmark fits the suite's core design principle: operational readiness cannot be inferred from apparent readiness.

## Keywords

Perioperative • OR add-on • turnover • surgical flow • resource allocation • AI evaluation • benchmark design • healthcare operations
