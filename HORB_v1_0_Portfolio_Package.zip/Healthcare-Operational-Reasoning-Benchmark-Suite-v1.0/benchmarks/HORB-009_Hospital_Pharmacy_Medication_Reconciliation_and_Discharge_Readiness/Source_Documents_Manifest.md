# Source Documents Manifest

This benchmark includes 28 fictional operational source documents.

| # | File |
|---|---|
| 1 | `01_MedRec_Workqueue.md` |
| 2 | `02_Pharmacy_Staffing_View.md` |
| 3 | `03_Patient_MedRec_Summary.md` |
| 4 | `04_Discharge_Order_Status.md` |
| 5 | `05_MedsToBeds_Status.md` |
| 6 | `06_Anticoagulation_Status.md` |
| 7 | `07_Diabetes_Insulin_Status.md` |
| 8 | `08_Renal_Lab_Status.md` |
| 9 | `09_Allergy_Culture_Status.md` |
| 10 | `10_PriorAuth_Copay_Status.md` |
| 11 | `11_Provider_Secure_Messages.md` |
| 12 | `12_Nursing_Unit_Messages.md` |
| 13 | `13_Pharmacy_Fill_History.md` |
| 14 | `14_Counseling_Interpreter_Status.md` |
| 15 | `15_Prescriber_Clarification_Log.md` |
| 16 | `16_Discharge_Lounge_Pressure.md` |
| 17 | `17_High_Risk_Med_List.md` |
| 18 | `18_Renal_Anticoag_Dose_Note.md` |
| 19 | `19_Insulin_Pump_History.md` |
| 20 | `20_Antibiotic_Culture_Update.md` |
| 21 | `21_Command_Center_Log.md` |
| 22 | `22_Huddle_Agenda.md` |
| 23 | `23_TOC_Pharmacist_Worklist.md` |
| 24 | `24_Recent_Updates_Digest.md` |
| 25 | `25_Risk_Watchlist.md` |
| 26 | `26_Patient_Family_Communication_Notes.md` |
| 27 | `27_MedRec_Flow_Policy.md` |
| 28 | `28_General_Operational_Notices.md` |
