# HORB-009: Hospital Pharmacy / Medication Reconciliation & Discharge Readiness

**Suite:** Healthcare Operational Reasoning Benchmark Suite  
**Version:** 1.0  
**Author:** Meredith Reese, RN  
**Original File Mapping:** Submission 027

> Evaluating operational reasoning under uncertainty in hospital pharmacy and transitions of care.

## Clinical Domain

Hospital Pharmacy and Transitions of Care

## Operational Setting

Medication reconciliation and discharge readiness huddle window

## Operational Window

9:30 AM to 9:45 AM before the Medication reconciliation huddle.

## Primary Capability Evaluated

Medication reconciliation and discharge-readiness operational reasoning.

## Purpose

Evaluates whether an AI system can coordinate transitions-of-care medication readiness while balancing discharge orders, pharmacist verification, renal dosing, duplicate therapies, anticoagulation, insulin, counseling, interpreter needs, prior authorization, meds-to-beds, and discharge timing.

## Primary Evaluation Question

> **Can the model distinguish apparent readiness from executable readiness while producing an operationally realistic plan for this workflow?**

## Capability Profile

| Capability | Evaluated |
|---|:---:|
| Multi-document reasoning | ✓ |
| Operational prioritization | ✓ |
| Temporal reasoning | ✓ |
| Workflow coordination | ✓ |
| Resource allocation | ✓ |
| Ownership boundaries | ✓ |
| Source provenance | ✓ |
| Uncertainty management | ✓ |


## Operational Actors

- Transitions pharmacist
- Pharmacy technician
- Discharge nurse
- Prescriber / hospitalist
- Case manager
- Interpreter services
- Meds-to-beds courier
- Patient / caregiver
- Prior authorization team


## Reasoning Challenges

- Incomplete medication reconciliation
- High-risk medication review
- Renal dosing or duplicate therapy
- Anticoagulation and insulin safety
- Prior authorization status
- Counseling and interpreter needs
- Meds-to-beds delivery
- Discharge timing pressure


## Typical Failure Modes

- Treating signed discharge order as medication-ready
- Equating paid claim with discharge readiness
- Ignoring pharmacist verification or counseling needs
- Missing high-risk medication conflicts
- Overlooking prior authorization or delivery barriers
- Releasing discharge before med rec closure


## Expected High-Quality Response

A strong response should:

- Integrate information across multiple documents.
- Distinguish confirmed information from apparent readiness.
- Respect ownership boundaries and role authority.
- Recognize unresolved dependencies.
- Prioritize realistically under time and resource constraints.
- Recommend only operationally executable actions.
- Carry unresolved issues forward to the appropriate huddle or owner.

## Included Materials

- `UseCase_System_Prompt.md`
- `Strict_Grading_Guidelines.md`
- `source_docs/` (28 fictional operational documents)
- `SourceDocs.zip`
- `original_batches/`

## Estimated Difficulty

**Expert**

## Estimated Human Evaluation Time

Approximately **30–45 minutes**.

## Design Notes

This benchmark was designed to evaluate operational judgment rather than factual recall. It presents multiple operationally plausible actions and requires prioritization based on safety, workflow constraints, source provenance, and confirmed operational readiness. The benchmark fits the suite's core design principle: operational readiness cannot be inferred from apparent readiness.

## Keywords

Medication reconciliation • transitions of care • pharmacy • discharge readiness • medication safety • AI evaluation • benchmark design • healthcare operations
