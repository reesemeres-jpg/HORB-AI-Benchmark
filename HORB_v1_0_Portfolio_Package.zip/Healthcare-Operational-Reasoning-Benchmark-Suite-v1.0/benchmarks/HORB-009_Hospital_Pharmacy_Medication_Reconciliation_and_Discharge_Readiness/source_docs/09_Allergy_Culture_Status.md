# Allergy Culture Status

Allergy, Culture, and Antibiotic Status  
Updated: 9:26 AM

| Patient | Issue |
|---|---|
| Elena Ramirez | Chart allergy says penicillin rash; daughter reports throat swelling and epinephrine as a child; urine culture updated at 8:40 showing resistance to prescribed cephalexin |
| Anita Patel | No antibiotic allergy issue |
| Marcus Lee | No antibiotic issue |
| George Allen | No antibiotic issue |
| Priya Desai | Sulfa intolerance noted |
| Omar Brooks | ICU antibiotics discontinued but one old cefepime order still appears on MAR hold list |
| Nina Torres | No antibiotic issue |
| Tessa Morgan | No antibiotic issue |

Allergy/culture note: Old allergy severity and new culture results can invalidate a previously sent antibiotic prescription.
