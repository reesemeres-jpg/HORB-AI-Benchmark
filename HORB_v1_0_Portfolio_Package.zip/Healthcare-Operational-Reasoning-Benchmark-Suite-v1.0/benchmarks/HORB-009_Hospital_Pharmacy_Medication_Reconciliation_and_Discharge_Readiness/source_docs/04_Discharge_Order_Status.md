# Discharge Order Status

Discharge / Medication Order Status  
Updated: 9:25 AM

| Patient | Order status |
|---|---|
| Anita Patel | Discharge order signed; apixaban prescription sent and filled; warfarin discontinuation note unclear; aspirin still appears on external med list |
| Elena Ramirez | Discharge order drafted; antibiotic prescription sent; attending has not acknowledged new culture result |
| George Allen | Discharge target noon; HF prescriptions drafted; prior auth and potassium issue pending |
| Tessa Morgan | No discharge order yet; counseling request only |
| Nina Torres | No discharge order |
| Marcus Lee | Admission orders active; med rec history marked complete but inpatient insulin plan under review |
| Priya Desai | Observation orders active; discharge not posted |
| Omar Brooks | Transfer orders active; med profile cleanup requested |

Order note: Signed or sent prescriptions still may need provider clarification, duplicate-therapy cleanup, lab review, or counseling before release.
