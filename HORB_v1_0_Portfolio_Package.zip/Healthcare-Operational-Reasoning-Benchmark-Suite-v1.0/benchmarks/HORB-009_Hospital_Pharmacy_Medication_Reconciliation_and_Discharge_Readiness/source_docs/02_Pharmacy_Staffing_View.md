# Pharmacy Staffing View

Transitions Pharmacy Staffing and Capacity  
Updated: 9:25 AM

| Staff / role | Assignment |
|---|---|
| TOC pharmacist | High-risk discharge/admission med rec, 9:45 huddle |
| Pharmacy resident | Can make one provider clarification call before 9:45 |
| Meds-to-beds technician | Filling discharge meds; can deliver one order before 10:00 |
| Insurance specialist | Prior auth/copay calls until 9:50, then meeting |
| Clinical pharmacist | Available by secure message for renal/interaction consults |
| Interpreter services | Spanish video interpreter available after 9:45; Gujarati interpreter by phone only |
| Unit clerk 4W | Can help reach Anita family |
| Diabetes educator | Available after 10:15 |
| Nurse liaison | Can relay one urgent hold message to unit before huddle |
| Prescriber inbox | Backlogged from morning rounds |

Staffing note: The TOC pharmacist can complete one direct clarification or release decision at a time. A green workqueue row is not the same as a safe discharge or med-rec release.
