# MedsToBeds Status

Meds-to-Beds / Dispensing Status  
Updated: 9:26 AM

| Patient | Dispensing status |
|---|---|
| Anita Patel | Apixaban filled; metoprolol filled; discharge bag staged; no documentation that warfarin/aspirin stop instructions are included |
| Elena Ramirez | Antibiotic filled; label printed; allergy verification pending after family report |
| George Allen | Furosemide filled; metoprolol filled; sacubitril/valsartan on hold for prior auth; spironolactone not filled due K issue |
| Tessa Morgan | No discharge bag |
| Nina Torres | No discharge bag |
| Priya Desai | No discharge meds |
| Marcus Lee | No discharge bag; inpatient admission |
| Omar Brooks | No discharge bag |

Meds-to-beds note: A bag being filled or staged does not mean medication reconciliation, counseling, allergy review, or prescriber sign-off is complete.
