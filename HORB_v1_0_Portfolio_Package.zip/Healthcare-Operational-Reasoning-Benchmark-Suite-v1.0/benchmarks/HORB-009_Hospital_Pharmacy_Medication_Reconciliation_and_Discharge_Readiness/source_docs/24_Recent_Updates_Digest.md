# Recent Updates Digest

Recent Updates Digest  
Compiled 9:30 AM

- Anita looks ready because discharge is signed and meds-to-beds is staged, but old warfarin/aspirin remain visible, renal function changed, and anticoag counseling/stop instructions are not complete.
- Marcus looks complete because admission med history is marked done, but he uses a pump, glargine and old sliding scale remain active/imported, and he had overnight hypoglycemia.
- Elena looks ready because the antibiotic prescription is sent and filled, but culture sensitivities changed and allergy severity may be anaphylaxis rather than rash.
- George remains important but is not a first-release candidate because prior auth and potassium issue are unresolved.
- Priya needs fall-risk medication review but is not immediate discharge release.
- Omar and Nina need cleanup/review but can be routed after the high-risk release blockers are controlled.
- Tessa counseling should wait until there is an actual discharge order.
