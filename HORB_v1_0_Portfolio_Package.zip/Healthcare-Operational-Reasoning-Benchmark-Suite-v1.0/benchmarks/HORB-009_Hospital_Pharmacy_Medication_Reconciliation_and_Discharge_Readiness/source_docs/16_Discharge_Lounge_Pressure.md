# Discharge Lounge Pressure

Discharge Lounge / Throughput Notes  
Updated: 9:27 AM

| Patient | Throughput pressure |
|---|---|
| Anita Patel | Family wants pickup by 10:30; bed needed for admission; discharge lounge requested med delivery |
| Elena Ramirez | Ride expected 10:00; nurse asked to avoid delay |
| George Allen | Noon discharge target; case management wants meds resolved early |
| Tessa Morgan | No discharge order; not a throughput priority yet |
| Priya Desai | ED Obs wants decision before noon |
| Marcus Lee | Admission med rec affects inpatient safety, not discharge lounge |
| Omar Brooks | Transfer med cleanup affects stepdown orders |
| Nina Torres | Renal review requested before next dose |

Throughput note: Bed pressure or ride timing does not make an unreconciled medication plan safe.
