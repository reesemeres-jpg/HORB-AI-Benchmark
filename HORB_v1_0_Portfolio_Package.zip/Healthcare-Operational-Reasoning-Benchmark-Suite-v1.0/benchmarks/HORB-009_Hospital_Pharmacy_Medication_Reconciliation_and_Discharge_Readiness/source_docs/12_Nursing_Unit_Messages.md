# Nursing Unit Messages

Nursing and Unit Messages  
Updated: 9:28 AM

**Anita Patel / 4W**  
Nurse says family is eager to leave and discharge lounge has been called. Nurse has not reviewed anticoagulant stop instructions with family.

**Marcus Lee / 5E**  
Nurse reports patient says "the pump handles most of it at home." Patient is worried about receiving both pump-related dosing and hospital insulin.

**Elena Ramirez / 3N**  
Nurse asks if discharge antibiotic can be sent to bedside because ride is coming soon. Daughter is at bedside and reports severe penicillin reaction history.

**George Allen / 6S**  
Nurse says discharge is not before noon but case management wants prior auth update.

**Priya Desai / ED Obs**  
Nurse requests fall-risk medication review before provider discharge decision.

Nursing note: Unit discharge pressure should not override unresolved high-risk med-rec issues.
