# Provider Secure Messages

Provider / Pharmacy Secure Messages  
Thread: 9:10–9:28 AM

9:10 — Discharge Lounge: Anita family wants pickup by 10:30. Is meds-to-beds ready?

9:12 — TOC Tech: Anita bag staged with apixaban and metoprolol. I do not see warfarin stop sheet.

9:13 — Cardiology NP: Anita should not take warfarin with apixaban. Need discharge instructions cleaned up.

9:14 — TOC Pharmacist: Anita creatinine rose overnight; dose criteria need review before counseling.

9:15 — Endocrine NP: Marcus pump history worries me. Please do not call his med rec complete until old basal/scale duplication is resolved.

9:17 — Night RN: Marcus glucose was 52 at 03:40. Treated, now stable.

9:19 — Lab: Elena culture sensitivities updated. Current discharge antibiotic may not cover.

9:20 — Daughter of Elena: Please note mom had throat swelling with penicillin, not just rash.

9:21 — Hospitalist: I have not reviewed Elena's updated culture yet.

9:23 — Insurance Specialist: George prior auth submitted but not approved.

9:25 — Nurse Liaison: I can relay one urgent hold before huddle.

9:28 — TOC Pharmacist: Bring blocker list to 9:45 huddle; do not release green rows automatically.
