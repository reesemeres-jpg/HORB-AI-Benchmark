# Anticoagulation Status

Anticoagulation / High-Risk Medication Status  
Updated: 9:25 AM

| Patient | Issue |
|---|---|
| Anita Patel | New apixaban for atrial fibrillation; outside pharmacy fill history shows warfarin refill 10 days ago and aspirin 81 mg monthly auto-refill; discharge summary says "stop old blood thinner" without naming warfarin |
| Priya Desai | Home meds include aspirin and intermittent ibuprofen; fall risk review requested |
| George Allen | No anticoagulant issue |
| Elena Ramirez | No anticoagulant issue |
| Marcus Lee | No anticoagulant issue |
| Omar Brooks | DVT prophylaxis duplicated in transfer orders |
| Nina Torres | Enoxaparin renal-dose review pending |
| Tessa Morgan | No anticoagulant issue |

Anticoagulation note: Patient counseling and explicit discontinuation instructions matter when old anticoagulants remain visible in fill history or external med lists.
