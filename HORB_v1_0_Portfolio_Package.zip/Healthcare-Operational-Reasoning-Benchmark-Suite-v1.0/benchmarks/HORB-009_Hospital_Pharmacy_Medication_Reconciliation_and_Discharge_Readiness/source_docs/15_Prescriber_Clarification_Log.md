# Prescriber Clarification Log

Prescriber Clarification Log  
Through 9:28 AM

9:05 — Cardiology NP asked to clarify Anita anticoag stop instructions.  
9:09 — No updated Anita discharge med list posted yet.  
9:13 — Cardiology NP replied: "No warfarin with apixaban." Full discharge instructions still pending.  
9:15 — Endocrine NP requested pharmacist review Marcus insulin/pump discrepancy.  
9:18 — Hospitalist paged about Elena culture result and allergy history.  
9:21 — Hospitalist replied: "Have not reviewed culture yet."  
9:22 — 6S provider asked case management about George prior auth; no decision.  
9:25 — ED Obs provider asked pharmacy to flag Priya fall-risk meds.  
9:27 — ICU stepdown provider acknowledged Omar duplicate prophylaxis issue.

Clarification note: A provider acknowledgement is not the same as a corrected active medication list.
