# High Risk Med List

High-Risk Medication Watchlist  
Updated: 9:27 AM

| Medication class | Patient | Concern |
|---|---|---|
| Anticoagulants | Anita Patel | Potential warfarin/apixaban/aspirin overlap and renal dosing question |
| Insulin | Marcus Lee | Pump + glargine + sliding scale discrepancy after hypoglycemia |
| Antibiotics/allergy | Elena Ramirez | Culture resistance and allergy severity mismatch |
| Heart failure meds | George Allen | Prior auth and hyperkalemia issue |
| Sedatives/falls | Priya Desai | Zolpidem, clonazepam, diphenhydramine with dizziness/falls |
| Duplicate prophylaxis | Omar Brooks | Famotidine/pantoprazole and old ICU orders |
| Renal dosing | Nina Torres | Enoxaparin and other dose review pending |
| Opioids | Tessa Morgan | Taper counseling later |

High-risk note: High-risk medication discrepancies should be resolved before routine discharge throughput goals.
