# Pharmacy Fill History

Outside Pharmacy Fill History  
Updated: 9:24 AM

| Patient | Fill-history issue |
|---|---|
| Anita Patel | Warfarin 5 mg tablets filled 10 days ago; aspirin 81 mg auto-refill monthly; apixaban new fill today |
| Marcus Lee | Insulin glargine pens filled monthly; rapid-acting insulin vials filled for pump; old sliding scale appears in external summary |
| Elena Ramirez | Cephalexin filled today; prior amoxicillin allergy listed as "rash" in pharmacy profile |
| George Allen | Lisinopril fill still active from old regimen; sacubitril/valsartan pending |
| Priya Desai | Zolpidem, clonazepam, diphenhydramine OTC documented by med history tech |
| Omar Brooks | Famotidine and pantoprazole both active in inpatient profile |
| Nina Torres | Enoxaparin previous dose auto-populated |
| Tessa Morgan | Oxycodone recent fill from outside pharmacy |

Fill history note: External fill history can conflict with discharge instructions and should be reconciled for high-risk medications.
