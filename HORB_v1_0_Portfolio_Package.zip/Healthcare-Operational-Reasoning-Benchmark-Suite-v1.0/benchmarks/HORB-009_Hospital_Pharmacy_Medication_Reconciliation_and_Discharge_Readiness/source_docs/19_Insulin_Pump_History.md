# Insulin Pump History

Insulin Pump / Admission Med History  
Patient: Marcus Lee  
Updated: 9:28 AM

Patient report:
- Uses insulin pump at home for basal and boluses.
- Pump removed in ED because supplies were not available.
- Patient says he "sometimes still has glargine pens at home but doesn't use them every night."

Current inpatient profile:
- Insulin glargine 40 units nightly
- Correction-scale insulin before meals and bedtime
- Old sliding-scale instructions imported into home med history
- Endocrine NP message asks pharmacy to resolve pump/glargine/scale discrepancy

Clinical note:
Overnight glucose 52 occurred after admission orders were active.

Pump note: Marking the admission med history "complete" does not resolve active inpatient insulin safety.
