# Renal Lab Status

Renal Function and Lab Status  
Updated: 9:25 AM

| Patient | Lab issue |
|---|---|
| Anita Patel | Creatinine increased from 0.9 to 1.5 overnight; eGFR now 36; age 82; weight 58 kg |
| Marcus Lee | Glucose 52 overnight, now 118 after treatment |
| Elena Ramirez | WBC improving; culture sensitivities updated at 8:40 |
| George Allen | Potassium 5.5 yesterday, repeat pending; creatinine stable |
| Priya Desai | Sodium 132; no renal issue |
| Omar Brooks | Creatinine improving after ICU stay |
| Nina Torres | Creatinine increased to 2.1; renal-dose review requested |
| Tessa Morgan | No lab issue |

Lab note: Overnight lab changes can make previously prepared discharge or inpatient medication plans unsafe without review.
