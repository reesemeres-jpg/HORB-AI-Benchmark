# General Operational Notices

General Pharmacy / Med-Rec Operations Notices

- A filled prescription is not the same as a reconciled discharge.
- A sent prescription can become unsafe after new labs, cultures, or allergy information.
- A "history complete" flag can still leave unsafe active inpatient orders.
- External fill history matters when stopping or replacing high-risk medications.
- Family/caregiver counseling matters when someone else fills the pillbox.
- Provider acknowledgement is not the same as corrected orders.
- Prior authorization submitted is not the same as approved.
- Throughput pressure should not override high-risk medication discrepancies.
- The safest plan may be to hold release and bring a blocker list to huddle.
- Update the med-rec queue after owner-confirmed decisions close.
