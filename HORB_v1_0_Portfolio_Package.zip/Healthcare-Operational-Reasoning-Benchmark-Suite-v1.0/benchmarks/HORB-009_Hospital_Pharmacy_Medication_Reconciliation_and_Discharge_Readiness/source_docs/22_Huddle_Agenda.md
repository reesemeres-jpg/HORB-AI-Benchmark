# Huddle Agenda

Medication Reconciliation / TOC Huddle  
Scheduled: 9:45 AM

Requested decisions:
- Is there a defensible first medication release or med-rec signoff before 10:00?
- Can Anita discharge meds be delivered, or do anticoagulant duplication, renal-dose review, stop instructions, and counseling block release?
- Can Marcus admission med history remain "complete," or does pump/glargine/scale duplication after hypoglycemia require pharmacy/endocrine cleanup first?
- Can Elena discharge antibiotic be sent home, or do culture resistance and allergy-severity update block release?
- What should be told to discharge lounge and unit nurses without overpromising?
- Which one urgent provider clarification should resident/pharmacist make before huddle?
- Which counseling tasks should wait until the medication plan is final?
- What can safely wait until after huddle?
- Which queue statuses need to be changed from green/ready?

Huddle note: Bring current blockers and owners. Do not rely on green med-rec queue status alone.
