# Patient Family Communication Notes

Patient and Family Communication Notes  
Updated: 9:29 AM

**Anita Patel**  
Daughter manages medications and pillbox, arrives around 10:20. Family wants pickup by 10:30. They need explicit instructions about stopping old anticoagulant therapy before leaving.

**Marcus Lee**  
Patient says he does not want duplicate insulin and is worried after low glucose overnight. He understands pump use better than the imported med list.

**Elena Ramirez**  
Daughter is at bedside and asking why allergy list says rash when she remembers throat swelling. Ride expected soon.

**George Allen**  
Family wants to know whether expensive HF medication is approved.

**Priya Desai**  
Patient says she takes sleep meds "only when needed" but has had multiple falls.

Communication note: Patient-facing counseling should wait until medication plans are correct and prescriber decisions are posted.
