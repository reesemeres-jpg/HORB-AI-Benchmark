# Diabetes Insulin Status

Diabetes / Insulin Medication Status  
Updated: 9:25 AM

| Patient | Issue |
|---|---|
| Marcus Lee | Admission med history says glargine 40 units nightly plus sliding-scale insulin; patient reports insulin pump at home; pump removed in ED; inpatient orders still include glargine 40 units and correction scale; glucose 52 overnight |
| Anita Patel | No diabetes issue |
| Elena Ramirez | No diabetes issue |
| George Allen | Type 2 diabetes; no urgent insulin issue |
| Priya Desai | No insulin issue |
| Omar Brooks | Stress hyperglycemia sliding scale still active after ICU transfer |
| Nina Torres | No insulin issue |
| Tessa Morgan | No insulin issue |

Diabetes note: A "history complete" flag does not resolve duplicate basal/pump/scale questions or recent hypoglycemia.
