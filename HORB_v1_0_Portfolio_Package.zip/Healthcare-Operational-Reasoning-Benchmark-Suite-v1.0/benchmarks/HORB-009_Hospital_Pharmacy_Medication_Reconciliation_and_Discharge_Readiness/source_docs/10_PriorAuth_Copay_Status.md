# PriorAuth Copay Status

Prior Authorization and Copay Status  
Updated: 9:26 AM

| Patient | Insurance / cost issue |
|---|---|
| Anita Patel | Apixaban paid claim went through with $47 copay; daughter not yet counseled on cost/refill plan |
| George Allen | Sacubitril/valsartan prior auth submitted; no approval number yet; copay unknown |
| Elena Ramirez | Antibiotic paid claim processed |
| Tessa Morgan | No discharge prescriptions yet |
| Marcus Lee | No discharge prescription |
| Priya Desai | No discharge prescription |
| Omar Brooks | No discharge prescription |
| Nina Torres | No discharge prescription |

Prior auth note: A claim or submission can support planning, but counseling and prescriber decisions still determine discharge readiness.
