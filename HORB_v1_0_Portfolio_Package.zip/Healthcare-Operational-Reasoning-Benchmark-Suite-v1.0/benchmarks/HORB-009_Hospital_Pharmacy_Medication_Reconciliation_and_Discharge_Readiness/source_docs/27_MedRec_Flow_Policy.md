# MedRec Flow Policy

Medication Reconciliation / Transitions-of-Care Workflow

1. Workqueue green status is a starting point, not final medication release.
2. Discharge medication delivery requires reconciled active medication list, discontinued medication clarity, lab/renal review when relevant, prescriber sign-off, and counseling readiness.
3. Admission med history "complete" does not resolve unsafe active inpatient orders imported from old home lists.
4. Antibiotic discharge requires current culture review, allergy severity review, renal/dose review when relevant, and prescriber acceptance.
5. High-risk medications such as anticoagulants, insulin, opioids, sedatives, and renal-dose medications should be prioritized over routine counseling.
6. Meds-to-beds fill status does not replace medication reconciliation or patient/caregiver counseling.
7. Interpreter/caregiver availability should be considered when the caregiver manages medications.
8. Pharmacists should update queue status after live owner decisions close.

Operational reminder: Releasing a prepared medication bag with unresolved discrepancies can create serious medication harm after discharge.
