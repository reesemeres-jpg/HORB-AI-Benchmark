# Renal Anticoag Dose Note

Renal / Anticoagulant Dose Review  
Patient: Anita Patel  
Updated: 9:28 AM

Current discharge prescription:
- Apixaban 5 mg twice daily

Patient factors:
- Age 82
- Weight 58 kg
- Creatinine 1.5 this morning after overnight increase
- eGFR now 36
- Warfarin fill 10 days ago
- Aspirin auto-refill still active in outside med list

Pharmacist note:
Dose and duplicate-therapy counseling need review with cardiology before discharge bag is delivered. Family manages pillbox and should receive specific stop instructions for old anticoagulant therapy.
