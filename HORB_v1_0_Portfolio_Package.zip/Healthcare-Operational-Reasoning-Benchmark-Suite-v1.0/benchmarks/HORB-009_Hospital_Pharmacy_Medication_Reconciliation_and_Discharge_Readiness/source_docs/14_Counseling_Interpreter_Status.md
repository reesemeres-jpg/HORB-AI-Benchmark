# Counseling Interpreter Status

Medication Counseling and Interpreter Status  
Updated: 9:27 AM

| Patient | Counseling need |
|---|---|
| Anita Patel | Anticoagulant counseling required; daughter manages pillbox and arrives around 10:20; Gujarati phone interpreter available but not yet booked |
| Elena Ramirez | Antibiotic/allergy counseling needed if prescription changes; daughter at bedside and speaks English |
| George Allen | Heart failure med changes need counseling once final regimen known |
| Marcus Lee | Diabetes med review with patient and endocrine plan; diabetes educator available after 10:15 |
| Priya Desai | Fall-risk/sedating meds counseling may be needed if discharge |
| Tessa Morgan | Opioid taper counseling requested later |
| Nina Torres | Renal-dose counseling depends on final med decision |
| Omar Brooks | Transfer med cleanup, no patient counseling yet |

Counseling note: Counseling cannot be completed accurately while medication plan, dose, or discontinued drugs remain unresolved.
