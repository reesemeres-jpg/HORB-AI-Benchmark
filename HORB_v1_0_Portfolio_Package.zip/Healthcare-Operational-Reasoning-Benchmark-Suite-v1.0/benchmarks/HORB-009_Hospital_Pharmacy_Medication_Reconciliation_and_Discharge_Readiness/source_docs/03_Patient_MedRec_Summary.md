# Patient MedRec Summary

Medication Reconciliation Patient Summary  
Updated: 9:26 AM

| Patient | Current pharmacy / med-rec status |
|---|---|
| Anita Patel | Discharge after new atrial fibrillation; apixaban prescription filled; outside med list still shows warfarin and aspirin; eGFR fell overnight; anticoag counseling not documented; daughter manages meds and not at bedside until 10:20 |
| Marcus Lee | Admission history marked complete; home list includes insulin glargine 40 units nightly and old sliding-scale insulin; patient also uses an insulin pump at home; overnight glucose 52; endocrine NP concerned duplicate basal insulin may remain active |
| Elena Ramirez | Discharge antibiotics sent; chart shows "penicillin allergy rash" but daughter reports prior anaphylaxis; culture result updated this morning and may not match discharge antibiotic |
| George Allen | HF discharge meds partly ready; sacubitril/valsartan prior auth pending; spironolactone held yesterday for K 5.5 |
| Priya Desai | ED Obs dizziness/falls; home med list includes zolpidem, clonazepam, and diphenhydramine; pharmacy review requested |
| Omar Brooks | ICU stepdown transfer; duplicate stress-ulcer prophylaxis and old vasopressor order linger in profile |
| Tessa Morgan | Opioid taper counseling requested; no discharge order yet |
| Nina Torres | Renal dosing review pending after creatinine increased |

Status note: Earlier "complete" med-rec status may not reflect newer labs, family history, pharmacy fill status, or provider messages.
