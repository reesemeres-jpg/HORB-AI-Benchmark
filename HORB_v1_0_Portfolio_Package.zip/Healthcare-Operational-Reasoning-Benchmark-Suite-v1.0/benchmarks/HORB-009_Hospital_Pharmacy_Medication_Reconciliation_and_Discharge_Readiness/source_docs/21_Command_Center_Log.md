# Command Center Log

Pharmacy Transitions-of-Care Operations Log  
9:00–9:30 AM

9:00 — TOC workqueue showed Anita, Marcus, and Elena green.  
9:05 — Anita discharge lounge requested meds-to-beds delivery.  
9:10 — Anita bag staged but warfarin stop instructions not visible.  
9:14 — Anita creatinine/eGFR change flagged for anticoag dose review.  
9:15 — Endocrine NP flagged Marcus pump/glargine/scale discrepancy.  
9:17 — Marcus overnight glucose 52 documented in message thread.  
9:19 — Elena culture sensitivities updated; discharge antibiotic may not cover.  
9:20 — Daughter reported Elena prior throat swelling/epinephrine with penicillin.  
9:23 — George prior auth submitted, no approval.  
9:25 — Nurse liaison can relay one urgent hold before huddle.  
9:28 — TOC pharmacist asked for blocker list before 9:45 huddle.  
9:30 — Queue still shows green because status fields have not been updated.
