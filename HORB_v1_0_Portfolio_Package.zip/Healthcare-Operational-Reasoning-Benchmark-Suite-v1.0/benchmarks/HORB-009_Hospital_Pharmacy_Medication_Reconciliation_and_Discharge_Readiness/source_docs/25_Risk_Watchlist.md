# Risk Watchlist

Medication Reconciliation Risk Watchlist  
Updated: 9:30 AM

High risk / release pressure:
- Anita: staged discharge bag, but anticoagulant overlap/stop instructions, renal-dose review, family counseling, and interpreter/caregiver timing unresolved.
- Marcus: history complete flag, but insulin pump/glargine/sliding-scale discrepancy and recent hypoglycemia unresolved.
- Elena: filled antibiotic, but culture resistance and allergy severity mismatch unresolved.
- Discharge lounge/unit pressure: family rides and beds create pressure to release before med-rec is safe.
- Staffing: TOC pharmacist/resident/nurse liaison can each only address limited items before huddle.

Medium risk:
- George: HF prior auth and hyperkalemia issue before noon discharge.
- Priya: fall-risk sedating meds in ED Obs.
- Omar: duplicate ICU transfer meds.
- Nina: renal-dose review pending.
- Tessa: opioid counseling later, no discharge order.
