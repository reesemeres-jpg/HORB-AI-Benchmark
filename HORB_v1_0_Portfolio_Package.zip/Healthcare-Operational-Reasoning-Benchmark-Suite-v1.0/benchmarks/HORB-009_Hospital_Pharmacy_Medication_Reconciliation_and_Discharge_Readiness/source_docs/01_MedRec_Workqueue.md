# MedRec Workqueue

Pharmacy Medication Reconciliation / Discharge Readiness Workqueue  
Generated: 9:22 AM  
Display source: pharmacy transitions-of-care workqueue

| Patient | Unit | Task | Visible status | Queue color |
|---|---|---|---|---|
| Anita Patel | 4W | Discharge med rec / anticoag counseling | Meds-to-beds ready | Green |
| Marcus Lee | 5E | Admission med rec / diabetes meds | History complete | Green |
| Elena Ramirez | 3N | Discharge antibiotics | Prescriptions sent | Green |
| George Allen | 6S | Heart failure discharge meds | Prior auth pending | Yellow |
| Priya Desai | ED Obs | Med rec for dizziness/falls | Pharmacy review needed | Yellow |
| Omar Brooks | ICU stepdown | Transfer med cleanup | Provider review pending | Yellow |
| Tessa Morgan | 4W | Opioid taper counseling | Ready later | Green |
| Nina Torres | 5W | Renal-dose review | Lab pending | Yellow |

Incoming / pressure:
| Source | Patient | Note |
|---|---|---|
| Discharge lounge | Anita Patel | Family wants pickup by 10:30 |
| Nursing | Elena Ramirez | Asking if antibiotics can go home now |
| Endocrine NP | Marcus Lee | Concerned old insulin scale may still be active |
| Case management | George Allen | Wants HF meds resolved before noon discharge |

Queue note: Green reflects pharmacy workqueue status only. It may not reflect current prescriber sign-off, duplicate therapies, renal function, allergy history, insurance approval, counseling completion, interpreter/caregiver availability, or medication-delivery readiness.
