# TOC Pharmacist Worklist

TOC Pharmacist Worklist  
Generated: 9:30 AM

- Reconcile workqueue status with fill history, discharge orders, labs, allergy/culture updates, provider messages, and counseling needs.
- Put urgent hold note on Anita meds-to-beds delivery until anticoagulant duplication and renal/dose review are clarified.
- Ask cardiology NP to update Anita discharge med list with explicit warfarin/aspirin instructions and apixaban dose confirmation.
- Arrange Gujarati interpreter/daughter counseling only after Anita final plan is posted.
- Put urgent hold note on Marcus "history complete" status until insulin pump/glargine/scale discrepancy is reviewed with endocrine.
- Ask endocrine/provider to revise active insulin orders if duplicate basal/scale issue is confirmed.
- Put hold note on Elena antibiotic delivery until hospitalist reviews culture and allergy severity.
- Route George prior auth to insurance specialist; do not treat as first release.
- Route Priya fall-risk sedating-med review after the three high-risk blockers are stabilized.
- Route Omar duplicate prophylaxis cleanup to clinical pharmacist/provider after urgent discharge/admission risks.
- Prepare huddle brief with one possible safe release or clear no-release explanation.
- Update queue status only after owner decisions close.
