# SNF Authorization Status

Skilled Nursing Facility / Authorization Status  
Updated: 11:26 AM

| Patient | SNF / auth issue |
|---|---|
| Victor Nguyen | Maple Grove SNF bed offered; insurance authorization submitted at 9:50 but no approval number; PASRR status says "pending review"; PT note from two days ago may be too old for final authorization |
| Irene Patel | Acute rehab authorization under clinical review; no decision |
| Talia Brooks | LTC return does not need SNF auth, but facility nurse review pending |
| Denise Carter | No SNF need |
| Sofia Martinez | No SNF need |
| Martin Hall | No SNF need |
| Caleb Stone | No SNF need |
| Rosa Bennett | No SNF need |

Facility note: A bed offer is not the same as payer authorization, level-of-care paperwork completion, or final facility acceptance.
