# Lead CM Worklist

Lead Case Manager Worklist  
Generated: 11:30 AM

- Reconcile discharge board with DME, UR, facility, home health, wound care, transport, caregiver, and dialysis notes.
- Put hold note on Denise discharge-lounge plan until portable oxygen, qualifying test, daughter pickup, and lounge acceptance are confirmed.
- Ask DME coordinator for Denise portable tank ETA and oxygen documentation status.
- Ask 5W nurse/provider whether Denise can safely wait on unit until daughter arrives if oxygen is unresolved.
- Put hold note on Victor transport until SNF authorization, PASRR, updated PT note need, and final Maple Grove acceptance close.
- Ask UR nurse/facility liaison to clarify Victor auth/PASRR and updated PT note.
- Put hold note on Sofia discharge until home VAC supplier release, final wound orders, home health SOC, and caregiver teaching are confirmed.
- Ask wound care and home health liaison to coordinate Sofia device/order/SOC plan.
- Ask dialysis coordinator for Martin chair time and ride confirmation.
- Route Caleb/Rosa/Talia/Irene to appropriate social work/facility/rehab follow-up after high-risk discharge blockers.
- Prepare huddle brief with one possible discharge or clear no-discharge explanation.
- Update board only after owner decisions close.
