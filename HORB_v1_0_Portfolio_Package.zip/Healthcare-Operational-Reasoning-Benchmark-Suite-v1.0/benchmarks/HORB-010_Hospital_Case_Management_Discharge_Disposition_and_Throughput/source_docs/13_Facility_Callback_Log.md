# Facility Callback Log

Facility and Community Callback Log  
Through 11:28 AM

9:50 — Victor SNF authorization submitted.  
10:05 — Maple Grove offered bed for Victor pending auth/PASRR.  
10:20 — Maple Grove requested updated PT note if transport after noon.  
10:45 — Rehab facility requested more clinicals for Irene.  
11:00 — Talia LTC facility asked for updated wound and behavior notes before return.  
11:10 — Valley Home Health asked for Sofia wound VAC release before confirming SOC.  
11:18 — Shelter desk said no male beds currently, asked social work to call back after noon for Caleb.  
11:24 — Dialysis coordinator called Martin outpatient center; no callback yet.  
11:28 — Hospice liaison confirmed availability for Rosa family meeting at 1:00.

Callback note: A facility or agency request may look like acceptance, but conditional callbacks still leave discharge gates open.
