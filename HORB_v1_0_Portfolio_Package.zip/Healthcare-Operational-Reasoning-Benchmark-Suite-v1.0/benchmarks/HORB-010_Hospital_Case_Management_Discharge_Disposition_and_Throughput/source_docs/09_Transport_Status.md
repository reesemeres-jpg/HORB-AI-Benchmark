# Transport Status

Transport and Route Status  
Updated: 11:26 AM

| Patient | Transport issue |
|---|---|
| Denise Carter | Daughter cannot pick up until after 2:00; discharge lounge asking if patient can wait there with oxygen; portable tank not confirmed |
| Victor Nguyen | Stretcher transport tentatively held for 12:30, but transport company requires authorization/facility confirmation before dispatch |
| Sofia Martinez | Cousin can pick up around 1:30 if wound VAC plan confirmed |
| Martin Hall | Needs reliable ride to outpatient dialysis tomorrow if discharged |
| Irene Patel | Rehab transport pending auth |
| Caleb Stone | Needs shelter transport if bed found |
| Rosa Bennett | No transport plan until family meeting |
| Talia Brooks | Facility van possible after nurse review |

Transport note: A tentatively held pickup or family ride does not make a discharge executable if destination, equipment, or acceptance is unresolved.
