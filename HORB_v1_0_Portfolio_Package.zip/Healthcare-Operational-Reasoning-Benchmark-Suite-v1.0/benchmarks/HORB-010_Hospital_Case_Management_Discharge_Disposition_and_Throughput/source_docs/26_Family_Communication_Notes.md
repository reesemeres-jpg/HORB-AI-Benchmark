# Family Communication Notes

Patient and Family Communication Notes  
Updated: 11:29 AM

**Denise Carter**  
Daughter manages oxygen setup and cannot arrive until after 2:00. Patient wants to leave but is anxious about oxygen tank.

**Victor Nguyen**  
Spouse believes SNF transfer is happening today because the bed was offered. Needs clear explanation that payer/PASRR/facility acceptance must close.

**Sofia Martinez**  
Cousin is willing to drive but has not demonstrated wound VAC troubleshooting and does not know if supplies will be at home.

**Martin Hall**  
Patient wants home discharge and says neighbor can help, but neighbor needs dialysis time.

**Caleb Stone**  
No family contact. Social work should avoid shelter promises until bed confirmed.

Communication note: Families should get clear status updates without exact discharge or transport times until disposition gates close.
