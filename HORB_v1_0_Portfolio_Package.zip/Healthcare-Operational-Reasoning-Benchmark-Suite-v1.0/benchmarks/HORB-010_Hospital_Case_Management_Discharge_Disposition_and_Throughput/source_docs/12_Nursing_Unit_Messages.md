# Nursing Unit Messages

Nursing and Unit Messages  
Updated: 11:28 AM

**Denise Carter / 5W**  
Nurse says patient is dressed and wants to leave. Patient becomes short of breath walking to bathroom without oxygen. Nurse asks whether discharge lounge can accept her.

**Victor Nguyen / 4E**  
Nurse says spouse packed belongings. Patient needs assistance with transfers and cannot sit upright in wheelchair for long.

**Sofia Martinez / 6N**  
Nurse says wound VAC dressing is intact and asks whether it can be converted to home VAC before discharge.

**Martin Hall / 3S**  
Nurse says patient wants to leave today but understands dialysis chair must be confirmed.

**Talia Brooks / 6E**  
Nurse says LTC facility requested updated wound and behavior notes.

Nursing note: Patient dressed, packed, or eager to leave does not mean the disposition is executable.
