# Payer UR Status

Payer / Utilization Review Status  
Updated: 11:28 AM

| Patient | Payer / UR issue |
|---|---|
| Victor Nguyen | SNF authorization submitted; no approval; PASRR pending; payer may request updated PT note |
| Irene Patel | Acute rehab authorization under review; estimated decision after 2:00 |
| Sofia Martinez | Home wound VAC payer release pending supplier order completion |
| Denise Carter | Oxygen qualification documentation required for DME billing; scanned test not found |
| Martin Hall | Dialysis chair confirmation, not insurance issue |
| Caleb Stone | No payer issue; shelter capacity issue |
| Rosa Bennett | Hospice information visit covered; election not signed |
| Talia Brooks | LTC return covered if facility accepts |

UR note: Authorization submitted, review pending, or paperwork requested is not the same as approval.
