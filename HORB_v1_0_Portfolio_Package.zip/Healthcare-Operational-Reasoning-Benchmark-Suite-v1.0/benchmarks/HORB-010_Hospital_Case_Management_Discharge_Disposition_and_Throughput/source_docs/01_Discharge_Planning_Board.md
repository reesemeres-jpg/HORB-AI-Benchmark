# Discharge Planning Board

Hospital Case Management / Discharge Planning Board  
Generated: 11:22 AM  
Display source: hospital discharge planning board

| Patient | Unit | Disposition | Visible next step | Board color |
|---|---|---|---|---|
| Denise Carter | 5W | Home with oxygen | Discharge lounge / DME complete | Green |
| Victor Nguyen | 4E | Skilled nursing facility | Transport to Maple Grove SNF | Green |
| Sofia Martinez | 6N | Home health + wound VAC | Home health arranged | Green |
| Martin Hall | 3S | Home with dialysis | Confirm chair time | Yellow |
| Irene Patel | 5W | Acute rehab | Insurance review | Yellow |
| Caleb Stone | ED Obs | Shelter discharge | Social work review | Yellow |
| Rosa Bennett | 4W | Hospice informational | Family meeting pending | Yellow |
| Talia Brooks | 6E | Long-term care return | Facility nurse review | Yellow |

Incoming / pressure:
| Source | Patient | Note |
|---|---|---|
| Bed control | Denise Carter | Needs 5W bed for admission by 1:00 |
| Nursing | Victor Nguyen | Family asking when stretcher transport arrives |
| Wound care | Sofia Martinez | Asking if home VAC can be released |
| Dialysis coordinator | Martin Hall | Outpatient chair confirmation not visible |

Board note: Green reflects visible discharge-board status only. It may not reflect payer authorization, DME delivery details, oxygen qualification, home health acceptance, wound VAC release, transportation confirmation, caregiver readiness, or receiving-facility acceptance.
