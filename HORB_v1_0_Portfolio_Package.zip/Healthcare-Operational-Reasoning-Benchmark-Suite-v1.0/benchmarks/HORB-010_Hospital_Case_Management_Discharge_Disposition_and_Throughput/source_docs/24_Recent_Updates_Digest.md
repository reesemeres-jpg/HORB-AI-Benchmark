# Recent Updates Digest

Recent Updates Digest  
Compiled 11:30 AM

- Denise looks ready because discharge is signed and DME portal says complete, but portable oxygen, qualifying documentation, daughter pickup, and discharge lounge criteria are not closed.
- Victor looks ready because Maple Grove offered a bed and transport is tentatively held, but SNF authorization, PASRR, possible updated PT note, and final facility acceptance are still unresolved.
- Sofia looks ready because an old note says home health accepted, but home wound VAC release, final wound orders, start-of-care timing, and caregiver teaching are not complete.
- Martin wants to leave but outpatient dialysis chair and next-day ride are not confirmed.
- Irene is not ready because acute rehab authorization is still under review.
- Caleb needs shelter/social work plan, not routine discharge.
- Rosa has a family meeting before hospice direction.
- Talia can return to LTC only after facility nurse accepts updated wound/behavior notes.
