# CM Flow Policy

Case Management Discharge Disposition Workflow

1. Discharge-board color is a starting point, not final discharge release.
2. Home oxygen discharge requires qualifying documentation, equipment availability, portable oxygen for transport, caregiver teaching when relevant, and safe pickup/transport plan.
3. SNF transfer requires facility acceptance, payer authorization when required, level-of-care/PASRR completion when required, current therapy documentation, transport confirmation, and nursing handoff.
4. Home wound VAC discharge requires home device release, final wound orders, home health start-of-care confirmation, supplies, payer release, and caregiver teaching.
5. Dialysis discharge requires confirmed outpatient chair and transportation plan.
6. Discharge lounge should not be used as a holding area for unresolved DME, oxygen, home health, or facility authorization issues.
7. Transport should be booked or released only after destination and equipment gates are closed.
8. Case management should update board status after live owner decisions close.

Operational reminder: A patient can be medically ready but not disposition-ready.
