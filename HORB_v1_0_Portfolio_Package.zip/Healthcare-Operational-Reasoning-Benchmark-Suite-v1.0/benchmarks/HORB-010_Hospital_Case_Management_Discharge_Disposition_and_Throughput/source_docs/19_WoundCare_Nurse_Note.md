# WoundCare Nurse Note

Wound Care Nurse Note  
Patient: Sofia Martinez  
Updated: 11:25 AM

Current wound plan:
- Hospital wound VAC dressing intact.
- Hospital VAC pump cannot leave with patient.
- Home VAC must be applied or delivered with correct settings.
- Home health must be able to see patient within safe start-of-care window.
- Cousin caregiver observed dressing but did not demonstrate pump troubleshooting.
- Wound care RN can provide teaching at 12:30 if home device plan is confirmed.

Wound care note:
Do not discharge with hospital VAC or without confirmed home VAC/home health plan.
