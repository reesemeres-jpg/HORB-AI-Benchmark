# CM Staffing View

Case Management and Social Work Staffing View  
Updated: 11:25 AM

| Staff / role | Assignment |
|---|---|
| Lead case manager | Discharge priority coordination, 11:45 huddle |
| CM A | 5W and 4E discharge cases |
| CM B | 6N and 6E discharge cases |
| Social worker | ED Obs/shelter and hospice family support |
| Utilization review nurse | Payer authorizations and level-of-care forms |
| DME coordinator | Oxygen, wound VAC, and equipment calls until noon |
| Home health liaison | Agency referrals and acceptance checks |
| Transport coordinator | One confirmed transport booking before noon cutoff |
| Discharge lounge nurse | Can take one medically stable patient with completed plan |
| Interpreter services | Spanish video interpreter available after noon |
| Facility liaison | SNF/rehab/facility callbacks, limited before huddle |

Staffing note: The lead case manager can complete one direct call or disposition decision at a time. A green board row is not the same as a safe or executable discharge.
