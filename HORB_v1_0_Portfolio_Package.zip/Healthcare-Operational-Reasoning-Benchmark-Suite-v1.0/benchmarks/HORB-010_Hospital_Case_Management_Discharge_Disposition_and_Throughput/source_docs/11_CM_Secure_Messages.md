# CM Secure Messages

Case Management Secure Messages  
Thread: 11:05–11:28 AM

11:05 — Bed Control: 5W needs Denise bed by 1:00 if discharge can happen.

11:08 — 5W RN: Denise oxygen tank is not at bedside. Can she go to discharge lounge?

11:10 — DME Coordinator: Denise concentrator delivered, but portable tank still driver pending. Qualifying O2 test not scanned.

11:12 — CM A: Do not move Denise to lounge unless oxygen and pickup plan are real.

11:13 — Maple Grove SNF: We have Victor bed today if auth and PASRR clear.

11:15 — UR Nurse: Victor auth submitted, no approval number. PASRR pending review.

11:17 — Transport Coordinator: I have 12:30 stretcher tentatively held for Victor, but company wants facility/auth confirmation.

11:19 — Wound Care RN: Sofia hospital VAC cannot go home. Home VAC release not confirmed.

11:21 — Valley Home Health: We need home VAC supplier release and SOC date before we confirm start.

11:24 — Dialysis Coordinator: Martin chair time for tomorrow not visible. Calling center.

11:27 — Lead CM: Bring blockers to 11:45 huddle. Do not count green discharges as actual departures.
