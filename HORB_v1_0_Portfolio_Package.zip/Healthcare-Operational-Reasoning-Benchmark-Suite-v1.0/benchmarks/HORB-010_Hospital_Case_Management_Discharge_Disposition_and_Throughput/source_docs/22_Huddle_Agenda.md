# Huddle Agenda

Case Management Discharge Flow Huddle  
Scheduled: 11:45 AM

Requested decisions:
- Is there a defensible first discharge or transfer before noon?
- Can Denise leave the unit or go to discharge lounge, or do oxygen tank, qualifying documentation, daughter pickup, and lounge criteria block discharge?
- Can Victor transfer to Maple Grove SNF, or do authorization, PASRR, updated PT note, and final facility acceptance block transport?
- Can Sofia discharge home, or do home wound VAC, final orders, home health SOC, and caregiver teaching block discharge?
- Can Martin discharge if dialysis chair and ride are not confirmed?
- What should be routed to UR, DME, home health, wound care, transport, and social work?
- Which tentative transport or pickup should be held without overpromising?
- What can safely wait until after the huddle?
- What should bed control and unit nurses be told?

Huddle note: Bring current blockers and owners. Do not rely on green discharge-board status alone.
