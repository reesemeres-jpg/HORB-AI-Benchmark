# Risk Watchlist

Case Management Discharge Risk Watchlist  
Updated: 11:30 AM

High risk / throughput pressure:
- Denise: green home discharge, but oxygen tank/documentation, caregiver pickup, and lounge acceptance unresolved.
- Victor: green SNF transfer, but auth/PASRR/PT note/facility acceptance unresolved.
- Sofia: green home health discharge, but home VAC, orders, SOC, payer release, and caregiver teaching unresolved.
- Bed control: needs beds but discharge blockers remain real.
- Transport: one confirmed booking before noon cutoff.
- DME/home health/UR: each has limited callback time before huddle.

Medium risk:
- Martin: dialysis chair and ride confirmation pending.
- Irene: rehab auth pending.
- Caleb: shelter bed not confirmed.
- Rosa: hospice meeting pending.
- Talia: LTC facility nurse review pending.
