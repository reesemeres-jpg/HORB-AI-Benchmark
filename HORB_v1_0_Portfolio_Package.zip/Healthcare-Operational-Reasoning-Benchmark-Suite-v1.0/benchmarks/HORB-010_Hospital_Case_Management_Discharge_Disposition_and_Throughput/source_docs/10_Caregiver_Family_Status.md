# Caregiver Family Status

Caregiver and Family Availability  
Updated: 11:25 AM

| Patient | Caregiver/family issue |
|---|---|
| Denise Carter | Daughter manages medications and oxygen setup; cannot arrive until after 2:00; patient anxious about oxygen tank |
| Victor Nguyen | Spouse at bedside, expects SNF today; asks for Maple Grove address |
| Sofia Martinez | Cousin caregiver can pick up around 1:30 but says she has never managed a wound VAC |
| Martin Hall | Lives alone; neighbor can drive to dialysis only if chair time confirmed |
| Irene Patel | Family prefers acute rehab and private room |
| Caleb Stone | No family contact; social work involved |
| Rosa Bennett | Adult children arriving for 1:00 goals meeting |
| Talia Brooks | LTC facility is primary caregiver |

Caregiver note: Family willingness does not replace equipment, training, receiving acceptance, or transport confirmation.
