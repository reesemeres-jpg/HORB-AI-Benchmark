# Transportation Call Log

Transportation Call Log  
Updated: 11:28 AM

| Patient | Transportation status |
|---|---|
| Victor Nguyen | 12:30 stretcher tentatively held; dispatch requires SNF final acceptance and authorization confirmation |
| Denise Carter | Daughter pickup after 2:00 only; portable oxygen needed if leaving unit |
| Sofia Martinez | Cousin pickup around 1:30 if home VAC plan is ready |
| Martin Hall | Neighbor ride depends on dialysis chair time |
| Irene Patel | Rehab transport not booked until auth |
| Caleb Stone | Shelter transport not booked because no bed |
| Talia Brooks | LTC facility van possible if facility nurse accepts |
| Rosa Bennett | No transport until family decision |

Transport note: A tentative ride does not make discharge safe if destination or equipment gates are still open.
