# Discharge Order Status

Provider Discharge Order and Medical Readiness Status  
Updated: 11:25 AM

| Patient | Order / readiness issue |
|---|---|
| Denise Carter | Discharge order signed; oxygen noted in instructions; provider asks CM to verify home oxygen and caregiver pickup |
| Victor Nguyen | Discharge order conditional on SNF authorization and transport; provider says rehab placement appropriate |
| Sofia Martinez | Discharge order drafted but not signed; provider waiting on home wound VAC/home health confirmation |
| Martin Hall | Discharge possible if dialysis chair and transport plan confirmed |
| Irene Patel | Medically ready for rehab once payer approves |
| Caleb Stone | ED provider says medically stable but unsafe discharge if no shelter/plan |
| Rosa Bennett | No discharge order; family meeting pending |
| Talia Brooks | Discharge back to LTC if facility accepts updated status |

Order note: A signed or drafted order still may require executable disposition, receiving acceptance, DME, transport, or caregiver plan before discharge.
