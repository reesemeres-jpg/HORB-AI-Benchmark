# General Operational Notices

General Case Management Operations Notices

- A green discharge board row can lag DME, payer, transport, home health, and caregiver updates.
- A bed offer is not the same as final SNF acceptance.
- Authorization submitted is not authorization approved.
- DME delivery complete may not include portable equipment or required documentation.
- Home health accepted in an old note can become conditional when DME or orders change.
- A hospital wound VAC cannot be assumed to go home with the patient.
- Discharge lounge cannot solve unresolved oxygen or facility authorization problems.
- A tentative transport hold is not a confirmed discharge route.
- Bed pressure should not override an unsafe or non-executable disposition.
- The safest huddle output may be a blocker list rather than a named discharge.
