# HomeHealth Referral Status

Home Health and Community Referral Status  
Updated: 11:25 AM

| Patient | Referral status |
|---|---|
| Sofia Martinez | Old referral note says "accepted by Valley Home Health"; new message from agency asks for wound VAC supplier release and start-of-care date before confirming; no final SOC time documented |
| Denise Carter | Home health not ordered; daughter requested nurse call after discharge |
| Martin Hall | No home health ordered |
| Irene Patel | Rehab disposition, not home health |
| Talia Brooks | LTC facility care |
| Caleb Stone | Shelter/social work referral needed |
| Rosa Bennett | Hospice information referral pending family decision |
| Victor Nguyen | SNF disposition |

Home health note: A prior "accepted" note may become stale if DME, wound care orders, start date, or staffing change.
