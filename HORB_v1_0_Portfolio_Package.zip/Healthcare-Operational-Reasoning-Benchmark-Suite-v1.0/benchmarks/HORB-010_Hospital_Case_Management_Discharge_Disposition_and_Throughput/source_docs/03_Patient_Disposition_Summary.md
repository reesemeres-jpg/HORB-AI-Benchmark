# Patient Disposition Summary

Case Management Patient Disposition Summary  
Updated: 11:26 AM

| Patient | Current disposition status |
|---|---|
| Denise Carter | COPD exacerbation improving; discharge order signed; home oxygen order placed; DME portal says delivery complete, but portable tank and qualifying oxygen documentation are not confirmed; daughter cannot meet patient until after 2:00 |
| Victor Nguyen | Post-stroke rehab needs; Maple Grove SNF bed offered; transport tentatively requested; insurance authorization and PASRR confirmation not visible; current PT note is from two days ago |
| Sofia Martinez | Diabetic foot wound; home health referral says "accepted" in old note; wound VAC order needs supplier release and home health start date confirmation; cousin caregiver unsure about dressing supplies |
| Martin Hall | ESRD patient after missed dialysis; wants home discharge; outpatient dialysis chair time for tomorrow not confirmed in current record |
| Irene Patel | Acute rehab recommended; payer review pending; family wants private room |
| Caleb Stone | ED Obs medically stable but homeless; shelter bed not confirmed |
| Rosa Bennett | Family considering hospice; goals-of-care meeting at 1:00 |
| Talia Brooks | LTC resident returning to facility; facility nurse wants updated behavior and wound notes before accepting return |

Status note: Earlier "ready" or "accepted" impressions may not reflect current payer, DME, home health, transport, facility, dialysis, or caregiver updates.
