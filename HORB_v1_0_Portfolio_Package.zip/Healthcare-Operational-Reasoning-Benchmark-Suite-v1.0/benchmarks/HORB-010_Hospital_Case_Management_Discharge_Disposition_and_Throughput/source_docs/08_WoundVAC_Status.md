# WoundVAC Status

Wound VAC and Wound Care Status  
Updated: 11:26 AM

| Patient | Wound issue |
|---|---|
| Sofia Martinez | Wound VAC needed at discharge; hospital VAC cannot leave with patient; home VAC supplier waiting on signed final order, home health SOC date, and payer release |
| Talia Brooks | Chronic wound dressing instructions updated this morning; LTC facility requests copy before return |
| Rosa Bennett | Pressure injury risk, hospice discussion pending |
| Victor Nguyen | No wound VAC issue |
| Denise Carter | No wound issue |
| Martin Hall | No wound issue |
| Caleb Stone | Minor abrasion only |
| Irene Patel | No wound issue |

Wound care note: A home discharge with wound VAC is not ready until home device, supplies, orders, and home health start are aligned.
