# Dialysis Coordination

Dialysis Coordination Notes  
Updated: 11:28 AM

**Martin Hall**  
Patient normally dialyzes Monday/Wednesday/Friday at Eastside Dialysis. He missed one outpatient session before admission. Hospital dialysis completed yesterday. Discharge can proceed if tomorrow's outpatient chair and transportation are confirmed.

Current status:
- Eastside Dialysis chair time not visible in discharge packet.
- Dialysis coordinator left message at 11:24.
- Neighbor can drive only if chair time is known before evening.
- Patient lives alone.
- Nephrology says do not discharge without chair confirmation.

Dialysis note: Patient preference to leave does not replace confirmed outpatient dialysis handoff.
