# HomeHealth Agency Message

Valley Home Health Message  
Patient: Sofia Martinez  
Received: 11:21 AM

Message:
"We may be able to staff start of care tomorrow morning, but cannot confirm acceptance until home wound VAC supplier releases the device and we receive final wound care orders. Please send final discharge summary, wound VAC settings, and caregiver teaching note. We cannot accept a same-day discharge if the device is not in the home."

Agency note:
Old referral status showed "accepted," but current acceptance is conditional on device release and orders.
