# Command Center Log

Case Management Command Center Log  
10:45–11:30 AM

10:45 — Discharge board projected Denise, Victor, and Sofia as likely noon discharges.  
11:05 — Bed control requested Denise bed by 1:00 if possible.  
11:10 — Denise portable oxygen tank and qualifying test still not confirmed.  
11:13 — Maple Grove bed offer for Victor posted as conditional.  
11:15 — Victor SNF authorization and PASRR still pending.  
11:17 — Victor 12:30 stretcher transport tentatively held.  
11:19 — Wound care noted Sofia hospital VAC cannot go home.  
11:21 — Valley Home Health made Sofia acceptance conditional on home VAC release and orders.  
11:24 — Martin dialysis chair confirmation not visible; call placed.  
11:27 — Lead CM asked for blocker list before huddle.  
11:30 — Board still shows Denise/Victor/Sofia green because status fields have not updated.
