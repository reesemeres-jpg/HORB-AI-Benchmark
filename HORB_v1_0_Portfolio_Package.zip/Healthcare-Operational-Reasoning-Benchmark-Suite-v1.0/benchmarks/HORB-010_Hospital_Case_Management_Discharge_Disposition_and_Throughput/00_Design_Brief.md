# HORB-010: Hospital Case Management / Discharge Disposition & Throughput

**Suite:** Healthcare Operational Reasoning Benchmark Suite  
**Version:** 1.0  
**Author:** Meredith Reese, RN  
**Original File Mapping:** Submission 028

> Evaluating operational reasoning under uncertainty in case management and discharge planning.

## Clinical Domain

Case Management and Discharge Planning

## Operational Setting

Late-morning discharge disposition and throughput window

## Operational Window

11:30 AM to 11:45 AM before the Case management discharge flow huddle.

## Primary Capability Evaluated

Discharge disposition and throughput operational reasoning.

## Purpose

Evaluates whether an AI system can coordinate case management discharge planning while balancing discharge orders, SNF or facility acceptance, payer authorization, PASRR/level-of-care requirements, DME, home oxygen, dialysis, wound VAC, caregiver readiness, transport, discharge lounge capacity, and family communication.

## Primary Evaluation Question

> **Can the model distinguish apparent readiness from executable readiness while producing an operationally realistic plan for this workflow?**

## Capability Profile

| Capability | Evaluated |
|---|:---:|
| Multi-document reasoning | ✓ |
| Operational prioritization | ✓ |
| Temporal reasoning | ✓ |
| Workflow coordination | ✓ |
| Resource allocation | ✓ |
| Ownership boundaries | ✓ |
| Source provenance | ✓ |
| Uncertainty management | ✓ |


## Operational Actors

- Case manager
- Social worker
- Bed control
- Discharge nurse
- Provider
- SNF/facility liaison
- Payer / authorization team
- DME / oxygen vendor
- Transport
- Patient / family


## Reasoning Challenges

- Destination acceptance
- Payer and level-of-care approvals
- DME / oxygen readiness
- Dialysis or wound VAC dependencies
- Caregiver and family pickup readiness
- Transport confirmation
- Discharge lounge capacity
- Bed throughput pressure


## Typical Failure Modes

- Counting signed discharge order as executable discharge
- Treating facility bed offer as final acceptance
- Ignoring payer/PASRR requirements
- Assuming DME portal status means home setup ready
- Overcommitting transport or discharge lounge capacity
- Releasing discharge before receiving handoff


## Expected High-Quality Response

A strong response should:

- Integrate information across multiple documents.
- Distinguish confirmed information from apparent readiness.
- Respect ownership boundaries and role authority.
- Recognize unresolved dependencies.
- Prioritize realistically under time and resource constraints.
- Recommend only operationally executable actions.
- Carry unresolved issues forward to the appropriate huddle or owner.

## Included Materials

- `UseCase_System_Prompt.md`
- `Strict_Grading_Guidelines.md`
- `source_docs/` (28 fictional operational documents)
- `SourceDocs.zip`
- `original_batches/`

## Estimated Difficulty

**Expert**

## Estimated Human Evaluation Time

Approximately **30–45 minutes**.

## Design Notes

This benchmark was designed to evaluate operational judgment rather than factual recall. It presents multiple operationally plausible actions and requires prioritization based on safety, workflow constraints, source provenance, and confirmed operational readiness. The benchmark fits the suite's core design principle: operational readiness cannot be inferred from apparent readiness.

## Keywords

Case management • discharge planning • throughput • disposition • care coordination • AI evaluation • benchmark design • healthcare operations
