# Toxicity Screening Queue

Immunotherapy / Treatment Screening Queue  
Updated: 8:27 AM

| Patient | Screening issue |
|---|---|
| Daniel Ortiz | Portal message yesterday: 5 loose stools/day, mild cramping; toxicity questionnaire not completed |
| Maya Chen | Reports poor appetite and weight loss; provider review pending |
| Robert Miles | TB screen date not visible on checklist |
| Evelyn Park | Transfusion consent missing |
| Lena Morris | Standard infusion checklist complete except slower-rate observation note |
| Priya Shah | Pregnancy-test flag unresolved |
| Omar Reed | No toxicity screen needed |
| Walk-in add-on | No screen yet |

Screening note: Same-day symptom screening can block treatment even if the order is signed and the chair is available.
