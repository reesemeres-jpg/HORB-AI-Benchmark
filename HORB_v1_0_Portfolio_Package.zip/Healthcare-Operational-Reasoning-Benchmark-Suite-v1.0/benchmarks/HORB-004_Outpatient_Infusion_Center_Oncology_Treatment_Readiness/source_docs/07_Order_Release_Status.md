# Order Release Status

Provider Order Release Status  
Updated: 8:25 AM

| Patient | Order status |
|---|---|
| Maya Chen | Chemo plan signed last week; today's release held for provider review after lab/weight alert |
| Robert Miles | Infusion order active; financial clearance not confirmed for today's date |
| Evelyn Park | Transfusion order active; consent not found in scanned documents |
| Daniel Ortiz | Immunotherapy order signed; nurse toxicity screen not completed after diarrhea portal message |
| Lena Morris | Iron order signed; slower-rate observation note present |
| Omar Reed | Port flush/lab order active |
| Priya Shah | Injection order signed; pregnancy-test flag unresolved |
| Walk-in add-on | No order yet |

Order note: A signed standing plan or active order still may need same-day release, screening, or documentation before treatment starts.
