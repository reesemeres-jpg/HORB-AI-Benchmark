# Recent Updates Digest

Recent Updates Digest  
Compiled 8:30 AM

- Maya looks ready on the board, but ANC and platelets are below treatment-notification parameters, weight is down 9%, and provider review is pending.
- Robert looks ready because he arrived and the drug is in the refrigerator, but authorization expired yesterday and TB-screen checklist is incomplete.
- Evelyn looks ready because transfusion is scheduled, but antibody screen is positive, special units are not released, and current transfusion consent is missing.
- Daniel has signed immunotherapy orders, but yesterday's diarrhea message needs toxicity review before treatment.
- Lena appears to have the clearest start if slower-rate/observation plan is acknowledged.
- Priya's injection is waiting on pregnancy-test requirement clarification.
- Omar is late, so his port/lab visit should not drive first-wave chair decisions.
- Pharmacy should avoid mixing or pulling drugs that may be held.
