# Consent Documentation

Consent and Required Documentation  
Updated: 8:24 AM

| Patient | Documentation status |
|---|---|
| Maya Chen | Chemo consent on file from cycle 1 |
| Robert Miles | Biologic infusion consent on file; TB screen checklist incomplete in today's packet |
| Evelyn Park | Blood transfusion consent not found in scan queue; older consent expired by local policy |
| Daniel Ortiz | Immunotherapy consent on file; toxicity questionnaire incomplete |
| Lena Morris | Iron consent on file; reaction plan note present |
| Priya Shah | Injection consent on file; pregnancy-test documentation unresolved |
| Omar Reed | Port consent not needed for routine access |
| Walk-in add-on | No documentation yet |

Documentation note: Missing consent or screening checklist should be resolved before treatment starts.
