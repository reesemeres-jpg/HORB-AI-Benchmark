# Provider Clinic Messages

Provider and Clinic Messages  
Updated: 8:28 AM

**Maya Chen**  
Oncology NP: "Hold final chemo release until I review ANC, platelets, weight loss, and symptoms. Do not mix until I respond."

**Robert Miles**  
GI clinic nurse: "Clinical order still active. We were not aware authorization expired. Financial team needs to confirm before infusion."

**Evelyn Park**  
Oncology provider: "Transfusion still indicated today if compatible units and consent are cleared. Please confirm before starting."

**Daniel Ortiz**  
Oncology fellow: "Diarrhea could be immune-related. Needs nurse toxicity screen and provider review before pembrolizumab."

**Lena Morris**  
Infusion provider: "Okay to give iron slowly with observation per prior reaction note if standard checklist is complete."

**Priya Shah**  
Clinic nurse: "Injection depends on current pregnancy-test rule. Check order set before administration."

Provider note: Clinical intent to treat is not the same as final same-day treatment release.
