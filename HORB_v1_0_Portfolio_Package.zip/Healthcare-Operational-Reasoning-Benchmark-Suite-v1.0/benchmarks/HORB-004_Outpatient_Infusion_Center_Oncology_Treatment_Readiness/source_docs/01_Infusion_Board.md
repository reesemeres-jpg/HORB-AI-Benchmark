# Infusion Board

Outpatient Infusion Center Board  
Generated: 8:22 AM  
Display source: infusion scheduling board

| Chair | Patient | Treatment | Visible status | Board color |
|---|---|---|---|---|
| Chair 2 | Robert Miles | Infliximab infusion | Arrived / med available | Green |
| Chair 4 | Maya Chen | FOLFOX cycle 3 | Labs back / chemo pending | Green |
| Chair 6 | Evelyn Park | 2 units PRBC | Blood bank ready | Green |
| Chair 8 | Daniel Ortiz | Pembrolizumab | Check-in pending | Yellow |
| Chair 10 | Lena Morris | Iron sucrose | Arrived | Green |
| Chair 12 | Omar Reed | Port flush + labs | Scheduled | Yellow |
| Fast Track 1 | Priya Shah | Injection visit | Waiting | Green |
| Fast Track 2 | Empty | Available | Green |

Incoming / pressure:
| Source | Patient | Note |
|---|---|---|
| Oncology clinic | Maya Chen | Provider asked infusion to hold final release until lab/weight review |
| Blood bank | Evelyn Park | Special matched unit status updated |
| Specialty pharmacy | Robert Miles | Authorization note imported overnight |
| Front desk | Walk-in dehydration add-on | Possible add-on after 9:30 |

Board note: Green reflects visible infusion-board status only. It may not reflect current order release, lab parameters, consent, authorization, pharmacy mixing, blood bank compatibility, port access, premedication, or nurse assignment.
