# Infusion Staffing View

Infusion Staffing and Assignment View  
Posted: 8:24 AM

| Staff/role | Assignment |
|---|---|
| Charge RN | Treatment readiness, pharmacy communication, 8:45 huddle |
| RN A | Chairs 2 and 4 if both safe to start |
| RN B | Chairs 6 and 8 |
| RN C | Chairs 10 and 12 |
| Fast Track RN | Fast Track 1 and 2 until 9:00 |
| Oncology pharmacist | Chemo verification and compounding queue |
| Pharmacy tech | Medication pulls and refrigerated biologics |
| Front desk | Check-in, consent scan requests, authorization messages |
| Financial counselor | Available by secure message until 8:50 |
| Lab runner | One pickup to oncology lab before 9:00 |
| EVS | Cleaning Private Room A; no exact finish time yet |

Staffing note: The charge RN can complete one direct call/message or treatment-release decision at a time. A drug in the refrigerator or a chair on hold is not the same as a safe treatment start.
