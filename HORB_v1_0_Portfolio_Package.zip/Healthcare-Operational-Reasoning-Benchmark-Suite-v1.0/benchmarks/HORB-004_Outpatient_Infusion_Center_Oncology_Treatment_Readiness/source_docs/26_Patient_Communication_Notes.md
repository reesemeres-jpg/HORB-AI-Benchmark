# Patient Communication Notes

Patient and Family Communication Notes  
Updated: 8:29 AM

**Robert Miles**  
Patient is frustrated because medication is physically present. Needs explanation that financial/safety checklist is still being cleared.

**Maya Chen**  
Patient asks whether treatment will be delayed. She reports poor appetite and weight loss. Do not promise chemo until provider releases.

**Evelyn Park**  
Daughter asks whether both units are ready. Blood bank says do not chart or state units are ready yet.

**Daniel Ortiz**  
Patient not checked in. Portal message may need call before arrival if schedule changes.

**Lena Morris**  
Anxious about prior reaction but willing to proceed slowly.

**Priya Shah**  
Waiting in fast track; wants to know if injection will be quick.

Communication note: Patient-facing updates should explain blockers without promising start times before owner decisions close.
