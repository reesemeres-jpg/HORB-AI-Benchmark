# Nursing Secure Messages

Secure Messages  
Thread: Infusion readiness 8:10–8:28 AM

8:10 — RN A: Maya is here. Do you want port accessed while provider reviews labs?

8:11 — Pharmacist: Do not mix Maya yet. ANC/platelets below parameters and weight drop needs provider confirmation.

8:13 — Provider NP: I need to review Maya before release. She has been losing weight.

8:14 — Chair 2 RN: Robert's med is in the fridge and he is asking to start.

8:15 — Financial Counselor: Robert auth expired yesterday. Renewal pending, no approval yet.

8:16 — Pharmacist: I cannot release Robert drug administration until auth and TB checklist are cleared.

8:17 — Blood Bank: Evelyn has antibody screen positive. Special matched units are being crossmatched. Do not tell her units are ready yet.

8:18 — Front Desk: I cannot find Evelyn's current transfusion consent.

8:20 — RN B: Daniel portal message says 5 loose stools/day yesterday. Should not start immunotherapy without toxicity screen.

8:22 — Pharmacy Tech: Lena iron is available. Slower-rate note acknowledged.

8:24 — Fast Track RN: Priya injection order has pregnancy-test flag. Need direction before giving.

8:26 — Charge RN: Bring me clean blockers and one safe start candidate before 8:45 huddle.
