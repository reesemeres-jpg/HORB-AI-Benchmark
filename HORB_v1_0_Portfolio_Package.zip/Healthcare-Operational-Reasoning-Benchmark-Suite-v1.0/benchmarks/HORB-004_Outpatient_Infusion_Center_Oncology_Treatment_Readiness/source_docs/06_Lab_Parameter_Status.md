# Lab Parameter Status

Lab and Treatment Parameter Status  
Updated: 8:25 AM

| Patient | Lab/parameter issue |
|---|---|
| Maya Chen | ANC 0.9; platelets 92k; treatment plan parameter says notify provider if ANC <1.0 or platelets <100k; weight down 9% from previous cycle |
| Evelyn Park | Hemoglobin 7.1; antibody screen positive; special crossmatch in progress |
| Daniel Ortiz | CMP acceptable; TSH pending; portal diarrhea message not yet reviewed |
| Lena Morris | Hemoglobin stable; no lab hold |
| Robert Miles | No same-day labs required in board; TB screen date not visible |
| Priya Shah | Pregnancy test last documented 6 weeks ago; order set flag says current test required if applicable |
| Omar Reed | Labs to be drawn on arrival |
| Walk-in add-on | No labs or orders yet |

Lab note: A lab result being "back" does not necessarily mean it meets treatment parameters.
