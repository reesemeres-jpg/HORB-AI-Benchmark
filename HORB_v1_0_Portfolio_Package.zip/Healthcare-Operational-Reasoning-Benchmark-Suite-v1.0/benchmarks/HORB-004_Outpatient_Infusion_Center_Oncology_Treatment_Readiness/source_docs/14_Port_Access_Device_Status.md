# Port Access Device Status

Port, IV Access, and Device Status  
Updated: 8:27 AM

| Patient | Access/device status |
|---|---|
| Maya Chen | Port present; not accessed yet; RN waiting because chemo release held |
| Robert Miles | Peripheral IV acceptable; not started |
| Evelyn Park | Peripheral IV placed; transfusion not started |
| Daniel Ortiz | Peripheral IV planned if treatment cleared |
| Lena Morris | Peripheral IV placed |
| Omar Reed | Port flush/labs scheduled; patient late |
| Priya Shah | Injection only |
| Walk-in add-on | Unknown |

Access note: Port access can be appropriate for labs, but accessing a port for a held chemo case can create unnecessary line time and chair use if release is not imminent.
