# Front Desk Intake Log

Front Desk and Intake Log  
Updated: 8:28 AM

| Patient | Intake issue |
|---|---|
| Robert Miles | Checked in; financial counselor message attached |
| Maya Chen | Checked in; weight today 9% below prior treatment weight |
| Evelyn Park | Checked in; daughter asking how long transfusion will take; consent not found |
| Daniel Ortiz | Not checked in; portal message attached to chart |
| Lena Morris | Checked in; prior reaction anxiety noted |
| Omar Reed | Called to say he is running late |
| Priya Shah | Checked in; fast track waiting |
| Walk-in add-on | Clinic may send after 9:30 |

Front desk note: Patient check-in and family questions should not be treated as treatment release.
