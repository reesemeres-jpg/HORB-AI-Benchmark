# Authorization Financial Status

Authorization and Financial Clearance Status  
Updated: 8:24 AM

| Patient | Authorization/financial status |
|---|---|
| Robert Miles | Prior authorization for infliximab expired yesterday per imported payer note; renewal submitted but not confirmed |
| Maya Chen | Chemo authorization active |
| Evelyn Park | Transfusion covered under active episode |
| Daniel Ortiz | Immunotherapy authorization active through next month |
| Lena Morris | Iron authorization active |
| Priya Shah | Injection authorization active |
| Omar Reed | Port flush/labs covered |
| Walk-in add-on | Unknown until order entered |

Financial note: Medication on site does not guarantee treatment can proceed when authorization status changed overnight.
