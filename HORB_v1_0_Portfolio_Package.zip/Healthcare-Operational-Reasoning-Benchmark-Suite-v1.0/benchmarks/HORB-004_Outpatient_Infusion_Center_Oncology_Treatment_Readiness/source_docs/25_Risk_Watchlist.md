# Risk Watchlist

Infusion Readiness Risk Watchlist  
Updated: 8:30 AM

High risk / treatment pressure:
- Maya: green chemo row but below lab parameters, weight loss, and provider hold.
- Robert: green biologic row but authorization expired and TB checklist incomplete.
- Evelyn: green transfusion row but special crossmatch and consent unresolved.
- Daniel: immunotherapy risk due diarrhea portal message.
- Pharmacy: risk of wasting high-cost mixed drugs if release gates are not closed.
- Chair capacity: long treatments can occupy chairs while not actually start-ready.

Medium risk:
- Lena: prior iron reaction requires slower rate and observation but may be startable if checklist complete.
- Priya: injection pending pregnancy-test rule.
- Omar: late arrival affects lab timing.
- Walk-in dehydration add-on: no orders yet.
