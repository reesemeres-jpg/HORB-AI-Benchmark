# General Operational Notices

General Infusion Center Operational Notices

- A green board row can lag lab, consent, authorization, blood bank, and pharmacy updates.
- Drug availability is not the same as permission to administer.
- A signed treatment plan may still need same-day provider release.
- Lab results being back does not mean they meet treatment parameters.
- Blood bank "working on units" does not mean transfusion units are ready.
- Authorization submitted is not the same as authorization approved.
- Patient arrival should not pressure nurses into starting before release gates close.
- Starting a lower-risk short infusion may be safer than holding a chair for an unresolved long treatment.
- Pharmacy should avoid mixing expensive or unstable drugs until treatment release is real.
- The charge nurse should give one clear first-start candidate only if all gates are actually closed.
