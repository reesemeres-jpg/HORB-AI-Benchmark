# Chair Capacity View

Infusion Chair and Room Capacity  
Updated: 8:24 AM

| Location | Status | Comment |
|---|---|---|
| Chair 2 | Occupied by Robert | Biologic infusion shown as ready; authorization question open |
| Chair 4 | Held for Maya | Long chemo chair; provider release pending |
| Chair 6 | Held for Evelyn | Transfusion chair; blood bank/consent questions open |
| Chair 8 | Empty | Could take immunotherapy if patient arrives and orders clear |
| Chair 10 | Occupied by Lena | Short infusion if iron order clear |
| Chair 12 | Empty | Fast lab/port access possible |
| Fast Track 1 | Occupied by Priya | Injection not yet administered |
| Fast Track 2 | Empty | Available for brief injections/labs only |
| Private Room A | Dirty | EVS after isolation precaution patient; earliest 9:15 |
| Pharmacy pass-through | Crowded | Chemo mix queue backed up |

Capacity note: A chair is not usable for a treatment until orders, safety checks, drug availability, nurse assignment, and monitoring needs are settled.
