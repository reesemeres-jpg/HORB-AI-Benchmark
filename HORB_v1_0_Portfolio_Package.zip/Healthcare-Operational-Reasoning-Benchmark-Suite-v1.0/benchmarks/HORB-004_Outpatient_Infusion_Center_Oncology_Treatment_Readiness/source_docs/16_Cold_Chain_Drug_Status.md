# Cold Chain Drug Status

Cold-Chain / Drug Handling Status  
Updated: 8:26 AM

| Medication | Status |
|---|---|
| Robert infliximab | In refrigerator; not spiked; administration not released |
| Maya oxaliplatin | Not mixed |
| Maya 5-FU | Not mixed |
| Daniel pembrolizumab | Refrigerator stock available; not assigned until toxicity screen clears |
| Lena iron sucrose | Pulled and ready |
| Priya injection | In refrigerator; not removed pending pregnancy-test question |
| Emergency meds | Crash cart and reaction kit checked |
| Walk-in fluids | Normal saline available; no add-on order |

Pharmacy note: Cold-chain availability does not mean treatment may start. Mixing or removing refrigerated medication too early can create waste if treatment is held.
