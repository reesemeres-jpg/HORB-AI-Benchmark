# Charge RN Worklist

Infusion Charge RN Worklist  
Generated: 8:30 AM

- Reconcile infusion board with pharmacy queue, lab parameters, provider messages, financial clearance, blood bank, consent, and screening notes.
- Ask oncology provider for Maya same-day decision on ANC/platelets/weight loss before pharmacy mixes.
- Ask financial counselor/GI clinic whether Robert has same-day authorization and TB-screen clearance.
- Ask blood bank/front desk to confirm Evelyn compatible unit release and current transfusion consent.
- Ask RN B to hold Evelyn education without implying blood is ready.
- Ask RN A not to access Maya port for chemo until release is closer unless provider requests labs.
- Ask RN C to start Lena only if slower-rate observation plan is acknowledged and chair coverage is safe.
- Ask Fast Track RN to clarify Priya pregnancy-test requirement before injection.
- Ask clinic/provider to review Daniel diarrhea before pembrolizumab if he arrives.
- Keep pharmacy from mixing high-cost chemo/immunotherapy until release gates close.
- Prepare huddle brief with one possible safe start or clear no-start explanation.
- Update infusion board only after owner decisions close.
