# Huddle Agenda

Infusion Treatment-Readiness Huddle  
Scheduled: 8:45 AM

Requested decisions:
- Is there a defensible first treatment start before 9:00?
- Can Maya receive FOLFOX today, or do labs/weight/provider review block mixing?
- Can Robert start infliximab, or do authorization and TB-screen questions block treatment?
- Can Evelyn start transfusion, or do blood bank compatibility and consent block treatment?
- Can Lena safely start iron at slower rate while higher-risk starts are held?
- Can Priya receive injection, or does pregnancy-test requirement block administration?
- Should Chair 8 be held for Daniel if he arrives, given diarrhea/toxicity concern?
- How should pharmacy prioritize mixing/pulls to avoid waste?
- Which single patient should nursing start only if all release gates are closed?
- What should be communicated to waiting patients without overpromising?

Huddle note: Bring blockers and owners. Do not rely on green infusion-board status alone.
