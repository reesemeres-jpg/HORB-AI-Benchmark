# Infusion Flow Policy

Infusion Center Treatment Readiness Workflow

1. Infusion-board color is a starting point, not final treatment release.
2. Chemotherapy should not be mixed until same-day lab parameters, dose/weight issues, consent, provider release, and pharmacy verification are settled.
3. Biologic infusion requires current authorization, screening requirements, medication availability, and nurse release checks.
4. Transfusion requires current consent, compatible blood release, patient identification, and transfusion monitoring capacity.
5. Immunotherapy symptom screens can block treatment even when orders are signed.
6. Refrigerated or high-cost medications should not be pulled or mixed prematurely if treatment may be held.
7. Chair assignment does not replace nurse capacity, monitoring needs, safety checks, or patient communication.
8. Charge RN should prepare a release-gate brief rather than launching several tentative treatments.

Operational reminder: Starting the wrong treatment or mixing a drug before release can create patient safety risk, waste, and chair delays.
