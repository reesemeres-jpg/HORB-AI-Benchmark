# Patient Contact Checkin

Patient Contact and Check-In Log  
Updated: 8:26 AM

| Patient | Check-in/contact status |
|---|---|
| Robert Miles | Checked in 8:05; waiting in Chair 2; asks why medication is not started |
| Maya Chen | Checked in 8:10; port not accessed yet; reports poor appetite and weight loss |
| Evelyn Park | Checked in 8:15; symptomatic fatigue; daughter present |
| Daniel Ortiz | Not checked in; portal message yesterday reported 5 loose stools/day |
| Lena Morris | Checked in 8:18; anxious about prior reaction |
| Omar Reed | Called at 8:20; may be 45 minutes late |
| Priya Shah | Waiting in Fast Track 1 |
| Walk-in add-on | Not arrived |

Contact note: Patient arrival does not replace order release, screening, consent, or safety review.
