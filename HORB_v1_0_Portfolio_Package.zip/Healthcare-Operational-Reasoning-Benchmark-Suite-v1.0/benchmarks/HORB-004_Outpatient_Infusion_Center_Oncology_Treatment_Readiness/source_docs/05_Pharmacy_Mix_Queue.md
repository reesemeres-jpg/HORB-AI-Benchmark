# Pharmacy Mix Queue

Infusion Pharmacy Verification / Mix Queue  
Updated: 8:25 AM

| Patient | Drug/treatment | Pharmacy status |
|---|---|---|
| Maya Chen | FOLFOX | Not mixed; pharmacist waiting for provider confirmation due ANC/platelets and weight change |
| Robert Miles | Infliximab | Medication physically available; authorization and TB checklist not cleared |
| Evelyn Park | PRBC | Not pharmacy mixed; blood bank compatibility/consent pending |
| Daniel Ortiz | Pembrolizumab | Drug available; immune-toxicity symptom review pending |
| Lena Morris | Iron sucrose | Ready to release after slower-rate order acknowledged |
| Priya Shah | Injection medication | Refrigerated; pregnancy-test flag on order set not reconciled |
| Omar Reed | Port flush/labs | No pharmacy need |
| Add-on dehydration | No medication orders |

Pharmacy note: Physical medication availability does not close clinical parameters, authorization, consent, pregnancy-test, or toxicity review requirements.
