# Lab Runner Courier Status

Lab Runner / Specimen Handling Status  
Updated: 8:28 AM

| Task | Status |
|---|---|
| Maya labs | Already resulted |
| Omar port labs | Patient late; no draw yet |
| Priya pregnancy test | Could be collected if order confirmed |
| Daniel TSH | Pending in main lab |
| Add-on labs | No orders |
| Lab runner | One pickup to oncology lab before 9:00 |
| Pneumatic tube | Delays reported from oncology clinic side |
| Point-of-care testing | Pregnancy test kits available in med room |

Lab note: A test that can be collected quickly still needs a valid order and workflow decision.
