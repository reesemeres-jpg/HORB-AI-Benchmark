# Patient Readiness Summary

Infusion Patient Readiness Summary  
Updated: 8:25 AM

| Patient | Current operational/clinical status |
|---|---|
| Robert Miles | Arrived for infliximab; medication in refrigerator; imported authorization note says coverage expired yesterday; TB screen date not visible on today's checklist |
| Maya Chen | FOLFOX cycle 3; labs returned; ANC 0.9, platelets 92k; weight down 9% from prior cycle; provider asked to review before pharmacy mixes |
| Evelyn Park | Symptomatic anemia; transfusion scheduled; antibody screen positive; blood bank says special matched units are being crossmatched; transfusion consent not found in scan queue |
| Daniel Ortiz | Pembrolizumab; patient not checked in; reports diarrhea in portal yesterday; provider toxicity review not documented |
| Lena Morris | Iron sucrose; arrived; infusion order signed; prior reaction note says give slower rate and observe |
| Omar Reed | Port flush and labs; patient called to say he may be 45 minutes late |
| Priya Shah | Injection visit; pharmacy refrigerator has medication; pregnancy test requirement unclear in order set |
| Walk-in add-on | Clinic may send dehydration patient after 9:30; no orders yet |

Status note: Earlier "ready" impressions may not reflect newer lab, authorization, consent, toxicity, reaction, or blood bank updates.
