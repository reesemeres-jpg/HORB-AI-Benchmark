# HORB-004: Outpatient Infusion Center / Oncology Treatment Readiness

**Suite:** Healthcare Operational Reasoning Benchmark Suite  
**Version:** 1.0  
**Author:** Meredith Reese, RN  
**Original File Mapping:** Submission 022

> Evaluating operational reasoning under uncertainty in outpatient infusion and oncology operations.

## Clinical Domain

Outpatient Infusion and Oncology Operations

## Operational Setting

Ambulatory infusion center treatment-readiness window

## Operational Window

8:30 AM to 8:45 AM before the Infusion treatment-readiness huddle.

## Primary Capability Evaluated

Treatment-readiness reasoning across pharmacy, nursing, authorization, and chair capacity constraints.

## Purpose

Evaluates whether an AI system can coordinate an outpatient infusion readiness window involving chemotherapy and biologic treatment readiness, lab parameters, pharmacy compounding, prior authorization, blood product compatibility, port access, chair capacity, nurse assignments, and patient communication.

## Primary Evaluation Question

> **Can the model distinguish apparent readiness from executable readiness while producing an operationally realistic plan for this workflow?**

## Capability Profile

| Capability | Evaluated |
|---|:---:|
| Multi-document reasoning | ✓ |
| Operational prioritization | ✓ |
| Temporal reasoning | ✓ |
| Workflow coordination | ✓ |
| Resource allocation | ✓ |
| Ownership boundaries | ✓ |
| Source provenance | ✓ |
| Uncertainty management | ✓ |


## Operational Actors

- Infusion charge nurse
- Infusion RN
- Oncology provider
- Pharmacy / compounding
- Prior authorization team
- Lab / blood bank
- Patient access / front desk
- Patient / caregiver


## Reasoning Challenges

- Lab parameter verification
- Pharmacy compounding readiness
- Prior authorization status
- Chair and nurse capacity
- Blood product compatibility
- Port access or access device readiness
- Premedication requirements
- Patient communication and arrival timing


## Typical Failure Modes

- Treating chair availability as treatment readiness
- Assuming pharmacy can compound without verified release
- Ignoring prior authorization or lab dependencies
- Starting treatment based on schedule status alone
- Overlooking blood product or access issues
- Unrealistic chair sequencing


## Expected High-Quality Response

A strong response should:

- Integrate information across multiple documents.
- Distinguish confirmed information from apparent readiness.
- Respect ownership boundaries and role authority.
- Recognize unresolved dependencies.
- Prioritize realistically under time and resource constraints.
- Recommend only operationally executable actions.
- Carry unresolved issues forward to the appropriate huddle or owner.

## Included Materials

- `UseCase_System_Prompt.md`
- `Strict_Grading_Guidelines.md`
- `source_docs/` (28 fictional operational documents)
- `SourceDocs.zip`
- `original_batches/`

## Estimated Difficulty

**Expert**

## Estimated Human Evaluation Time

Approximately **30–45 minutes**.

## Design Notes

This benchmark was designed to evaluate operational judgment rather than factual recall. It presents multiple operationally plausible actions and requires prioritization based on safety, workflow constraints, source provenance, and confirmed operational readiness. The benchmark fits the suite's core design principle: operational readiness cannot be inferred from apparent readiness.

## Keywords

Infusion center • oncology • treatment readiness • chemotherapy • operational coordination • AI evaluation • benchmark design • healthcare operations
