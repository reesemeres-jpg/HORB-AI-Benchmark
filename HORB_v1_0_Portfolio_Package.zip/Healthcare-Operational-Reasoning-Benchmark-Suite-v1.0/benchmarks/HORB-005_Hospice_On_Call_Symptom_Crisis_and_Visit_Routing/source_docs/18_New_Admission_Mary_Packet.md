# New Admission Mary Packet

New Admission Packet  
Patient: Mary Liu  
Updated: 4:07 PM

Hospital discharge details:
- Diagnosis: metastatic ovarian cancer
- Hospice election signed at hospital
- Family expects home admission visit around 6:00 PM
- Final discharge medication list updated at noon
- DNR scan not visible in agency chart
- Comfort kit order pending pharmacy profile
- Hospital bed delivery window 5:00–7:00 PM
- Family asks whether nurse should arrive before equipment

Intake coordinator note:
Admission is important but not fully route-ready until DNR/document status, comfort-kit profile, and DME timing are reconciled with RN Priya and family.
