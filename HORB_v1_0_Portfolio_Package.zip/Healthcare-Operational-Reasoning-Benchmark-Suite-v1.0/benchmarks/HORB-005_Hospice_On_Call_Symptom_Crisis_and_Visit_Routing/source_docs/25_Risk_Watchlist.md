# Risk Watchlist

Hospice On-Call Risk Watchlist  
Updated: 4:10 PM

High risk / route pressure:
- Helen: severe pain, caregiver afraid, unsigned dose-change note, RN assessment likely needed after supervisor/provider clarification.
- Frank: dyspnea and possible oxygen equipment failure; DME confirmation not closed; LPN scope concern.
- Mary: new admission with incomplete DNR/comfort-kit/DME profile.
- Pharmacy courier: last same-day route at 4:45.
- RN Kelly: one urgent first route; cannot cover Helen, Frank, and June at once.
- Supervisor: available only until 4:20 before meeting.

Medium risk:
- June: family support need, but facility nurse present and symptoms reportedly comfortable.
- Rosa: caregiver crisis/respite discussion, no active symptom emergency.
- Owen: teaching delayed until son available.
- Thomas: stable routine tuck-in.
- Paul: unreachable after missed visit.
