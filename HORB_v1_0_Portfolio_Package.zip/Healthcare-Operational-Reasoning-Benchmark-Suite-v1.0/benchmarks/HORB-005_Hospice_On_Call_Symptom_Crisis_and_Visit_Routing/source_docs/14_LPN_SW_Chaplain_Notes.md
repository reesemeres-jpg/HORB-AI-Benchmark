# LPN SW Chaplain Notes

LPN / Social Work / Chaplain Notes  
Updated: 4:07 PM

**LPN Sam**  
Scheduled for Frank dyspnea follow-up and Owen medication teaching. Sam can reinforce stable care plans, check basic status, and report changes, but should not independently manage an unstable dyspnea/equipment failure or medication-plan change.

**SW Nina**  
Can call Rosa's daughter before 5:00 to discuss caregiver crisis and respite questions. Field visit possible after 6:00 if needed.

**Chaplain**  
Can call June's family after 4:30 if requested. No field visit before 7:00.

**Triage RN**  
Can make one symptom follow-up call before 5:00 handoff to overnight line.

Role note: Discipline-specific scope matters when routine visits turn into symptom crisis or family distress.
