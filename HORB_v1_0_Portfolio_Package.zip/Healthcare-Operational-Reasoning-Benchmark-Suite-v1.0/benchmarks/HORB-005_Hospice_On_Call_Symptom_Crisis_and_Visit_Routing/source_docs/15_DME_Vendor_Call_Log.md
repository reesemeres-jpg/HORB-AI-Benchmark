# DME Vendor Call Log

DME Vendor Call Log  
Updated: 4:08 PM

3:40 — Frank oxygen delivery marked complete in vendor portal.  
3:52 — Vendor route note says concentrator installed and backup tank left.  
4:00 — Frank wife reports concentrator beeping and backup tank low.  
4:04 — DME coordinator called vendor dispatch; hold time estimated 12 minutes.  
4:07 — No technician assigned yet.  
4:08 — DME coordinator can make one more vendor call before 4:30.

Vendor note: Completed delivery documentation does not resolve patient-reported equipment failure.
