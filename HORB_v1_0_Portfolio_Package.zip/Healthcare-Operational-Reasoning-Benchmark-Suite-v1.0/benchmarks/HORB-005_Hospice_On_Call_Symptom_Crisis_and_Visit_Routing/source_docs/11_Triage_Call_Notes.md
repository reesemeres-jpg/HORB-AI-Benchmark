# Triage Call Notes

Triage Call Notes  
Updated: 4:08 PM

**Helen Warner — 3:55 PM daughter call**  
Daughter reports patient crying out with pain, "10/10," last morphine dose given around 2:45 PM. Daughter says bottle label does not match what NP discussed yesterday. Daughter afraid to give another dose without nurse guidance. No new fall, no new bleeding. Daughter alone in home until sister arrives after 6:00.

**Frank Morales — 4:00 PM wife call**  
Wife reports oxygen machine beeping and patient more short of breath walking to bathroom. Backup tank gauge may be low. Wife has hearing impairment and struggled with phone troubleshooting. No cyanosis reported; patient can speak short phrases.

**June Alvarez — 4:03 PM facility call**  
Facility nurse reports breathing pattern changed and family is distressed. Facility nurse says comfort meds are available and patient appears comfortable at the moment.

Triage note: Symptom severity, caregiver ability, and order clarity all affect route priority.
