# Field RN Route Notes

Field RN Kelly Route Notes  
Updated: 4:07 PM

Planned route from board:
1. Helen Warner — 4:30
2. June Alvarez facility support — 5:30

RN Kelly note:
- I can take one urgent visit first.
- I need clarity on whether Helen's increased morphine plan is signed or just discussed.
- If Frank's oxygen equipment is failing, I need DME involved before I arrive or I may be stuck without a fix.
- I can support an actively dying facility family later if symptoms are controlled and facility nurse remains present.
- I cannot also cover Mary's new admission unless the route changes and paperwork is ready.
