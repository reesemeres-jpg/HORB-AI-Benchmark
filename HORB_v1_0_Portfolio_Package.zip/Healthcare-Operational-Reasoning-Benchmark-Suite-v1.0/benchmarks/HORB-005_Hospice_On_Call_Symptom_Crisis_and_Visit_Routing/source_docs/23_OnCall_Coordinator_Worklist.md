# OnCall Coordinator Worklist

On-Call Coordinator Worklist  
Generated: 4:10 PM

- Reconcile schedule board with triage calls, medication profile, DME status, pharmacy cutoff, caregiver ability, and staff scope.
- Call clinical supervisor before 4:20 about Helen's severe pain and unsigned dose-change note.
- Confirm whether provider can sign or clarify Helen medication plan before RN teaches caregiver.
- Tell RN Kelly not to teach increased morphine dosing from "consider" note alone.
- Continue DME vendor escalation for Frank concentrator alarm and backup tank status.
- Decide whether Frank requires RN/DME-first plan instead of LPN routine follow-up.
- Ask triage RN or chaplain to support June family by phone while facility nurse confirms symptom comfort.
- Verify Mary DNR scan, comfort-kit pharmacy profile, and DME bed delivery before confirming 6:00 admission route.
- Ask SW Nina to call Rosa's daughter before 5:00 if possible.
- Hold Owen teaching until son is available after 6:00.
- Prepare huddle brief with one possible route or clear no-route explanation.
- Update schedule board only after owner decisions close.
