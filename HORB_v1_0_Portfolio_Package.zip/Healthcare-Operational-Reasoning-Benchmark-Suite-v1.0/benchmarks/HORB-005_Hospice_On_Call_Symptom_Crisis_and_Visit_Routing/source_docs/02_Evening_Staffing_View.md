# Evening Staffing View

Hospice Evening Staffing and Capacity View  
Updated: 4:05 PM

| Staff member | Role | Current availability |
|---|---|---|
| RN Kelly | Field RN | Can start one confirmed urgent route by 4:30; must call supervisor before any medication-plan change |
| RN Priya | Admission RN | Scheduled for Mary admission, but hospital discharge packet not fully reconciled |
| LPN Sam | Field LPN | Can do stable routine visits and reinforce existing plans; cannot independently triage unstable symptom crises or change medication plans |
| Triage RN | Phone triage | Available until 5:00, then switches to overnight line |
| Clinical supervisor | RN supervisor | Available by phone until 4:20, then IDG meeting until 5:15 |
| Social worker Nina | SW | Can make one caregiver crisis call before 5:00, visit after 6:00 if safe |
| Chaplain | Chaplain | On call by phone, no field visit before 7:00 |
| DME coordinator | Office | Can make two vendor calls before 4:30 |
| Pharmacy coordinator | Office | Can call hospice pharmacy once before courier cutoff |
| Courier | Medication courier | Last same-day route leaves pharmacy at 4:45 |
| Scheduler | Office | Can call one caregiver/facility at a time |

Staffing note: The on-call coordinator can complete one direct call or routing decision at a time. A visible visit assignment is not actionable without symptom plan, access, scope, supplies, and route readiness.
