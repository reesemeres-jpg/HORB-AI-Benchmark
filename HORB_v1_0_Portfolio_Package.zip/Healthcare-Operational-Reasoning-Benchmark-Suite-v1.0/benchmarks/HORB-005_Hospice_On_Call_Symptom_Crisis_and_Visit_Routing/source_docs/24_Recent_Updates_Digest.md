# Recent Updates Digest

Recent Updates Digest  
Compiled 4:10 PM

- Helen looks like the obvious first RN visit because pain is severe and she is green on the board, but the increased morphine plan is not signed and daughter is afraid to medicate.
- Frank looks like a routine LPN dyspnea follow-up because the oxygen delivery is marked complete, but wife reports the concentrator is alarming and backup tank may be low.
- June is active dying with family distress, but facility nurse is present and reports patient appears comfortable right now.
- Mary admission is important, but DNR scan, comfort kit profile, discharge med reconciliation, and DME timing are not ready.
- Owen teaching can wait until son is available after 6:00.
- Rosa needs caregiver support today, likely phone-first before field visit.
- Pharmacy courier cutoff is 4:45.
- Supervisor availability closes soon, so medication/DME route decisions should be clarified before then.
