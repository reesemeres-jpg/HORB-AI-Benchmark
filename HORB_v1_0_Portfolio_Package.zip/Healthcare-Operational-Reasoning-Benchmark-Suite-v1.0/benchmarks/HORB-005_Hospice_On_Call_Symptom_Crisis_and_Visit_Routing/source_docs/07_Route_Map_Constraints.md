# Route Map Constraints

Hospice Route Geography and Timing  
Updated: 4:05 PM

| Route | Typical drive time | Current note |
|---|---:|---|
| Office to Helen | 24 min | Home access confirmed; urgent symptom call |
| Office to Frank | 18 min | Home access confirmed; DME oxygen issue |
| Helen to Frank | 32 min | Cross-town; rush-hour traffic starting |
| Frank to June facility | 22 min | Facility access confirmed |
| Office to June facility | 28 min | Family at bedside |
| Office to Mary | 35 min | Admission packet not ready; DME delivery 5–7 |
| Office to Owen | 26 min | Son not available until after 6 |
| Office to Rosa | 30 min | SW visit after 6 possible |
| Office to Paul | 40 min | No answer |

Route note: The evening route cannot safely absorb multiple failed or unresolved urgent visits before medication courier cutoff and supervisor availability windows close.
