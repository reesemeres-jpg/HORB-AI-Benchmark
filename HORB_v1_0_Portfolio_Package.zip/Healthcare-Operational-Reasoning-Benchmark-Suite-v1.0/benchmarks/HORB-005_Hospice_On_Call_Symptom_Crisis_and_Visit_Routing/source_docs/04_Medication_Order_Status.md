# Medication Order Status

Hospice Medication and Order Status  
Updated: 4:05 PM

| Patient | Medication/order issue |
|---|---|
| Helen Warner | Current active order: morphine 5 mg q2h PRN pain/dyspnea; NP note says "consider 10 mg q1h PRN if uncontrolled," but signed order not visible |
| Frank Morales | Comfort kit contains morphine and haloperidol; lorazepam line listed as "pending delivery"; wife unsure what was given at noon |
| June Alvarez | Comfort meds in facility e-kit; facility nurse has standing order sheet |
| Thomas Greene | Haloperidol PRN order active; no refill issue |
| Mary Liu | Hospital discharge med list contains oxycodone; hospice comfort-kit order pending pharmacy confirmation |
| Owen Clark | Lorazepam order signed today; caregiver teaching requested |
| Rosa Delgado | No medication issue noted |
| Paul Bennett | Medication status unknown due missed visit |

Medication note: Draft notes, "consider" language, and old hospital discharge lists are not the same as active hospice medication orders.
