# Supervisor Notes

Clinical Supervisor Notes  
Updated: 4:08 PM

**Helen Warner**  
RN visit likely needed, but clarify whether there is an active signed order before teaching any increased morphine dose. If pain remains severe and daughter cannot follow current plan, RN Kelly should assess and call provider/supervisor from the home if needed.

**Frank Morales**  
Dyspnea/equipment concern may need DME escalation before sending LPN. If equipment is not functioning, DME technician and backup oxygen status should be clarified. LPN should not be expected to troubleshoot a failed concentrator alone.

**June Alvarez**  
Facility has licensed nurse present and comfort meds available. Family support important, but this may be phone/SW/chaplain support unless symptoms change.

**Mary Liu**  
New admission should not be launched until admission packet, DNR status, comfort kit, and DME timing are reconciled.

Supervisor note: Do not build a route solely from the green board. Use the next 10 minutes to close the most important gates.
