# Patient Status Summary

Hospice Patient Status Summary  
Updated: 4:06 PM

| Patient | Current operational/clinical status |
|---|---|
| Helen Warner | Metastatic cancer; daughter reports pain 10/10 despite last morphine dose; comfort kit in home but daughter unsure about instructions; new pain order discussed by NP but signed order not visible |
| Frank Morales | End-stage COPD; LPN follow-up green; DME portal says oxygen concentrator delivered; wife reports machine "beeping and not giving enough air"; rescue meds unclear |
| June Alvarez | Dementia, active dying at facility; family requesting support; facility nurse says breathing changed, no crisis meds requested yet |
| Thomas Greene | Routine tuck-in call after agitation yesterday; caregiver says stable in morning voicemail |
| Mary Liu | New admission from hospital with ovarian cancer; discharge packet updated; DNR scan and comfort kit delivery pending |
| Owen Clark | Medication teaching after new lorazepam order; son available after 6:00 |
| Rosa Delgado | Caregiver overwhelmed, requesting respite discussion; no active symptom crisis reported |
| Paul Bennett | Missed visit yesterday; no answer today |

Status note: Earlier scheduled status may not reflect newer symptom escalation, caregiver ability, medication-order status, or DME function.
