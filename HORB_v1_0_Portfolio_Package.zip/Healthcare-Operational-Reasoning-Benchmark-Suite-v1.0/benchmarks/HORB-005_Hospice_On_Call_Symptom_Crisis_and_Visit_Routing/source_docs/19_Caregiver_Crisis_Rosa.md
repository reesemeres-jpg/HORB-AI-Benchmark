# Caregiver Crisis Rosa

Caregiver Crisis Note  
Patient: Rosa Delgado  
Updated: 4:06 PM

Daughter called at 3:45 PM:
- "I can't do another night like this."
- Patient not in uncontrolled pain or dyspnea at time of call.
- Daughter asks about respite options and whether someone can come tonight.
- Social worker visit requested.
- No immediate safety threat reported.
- Daughter can take a call at 5:30 after work.

SW note:
This should be addressed today, but it may be phone-first unless symptom or safety risk escalates.
