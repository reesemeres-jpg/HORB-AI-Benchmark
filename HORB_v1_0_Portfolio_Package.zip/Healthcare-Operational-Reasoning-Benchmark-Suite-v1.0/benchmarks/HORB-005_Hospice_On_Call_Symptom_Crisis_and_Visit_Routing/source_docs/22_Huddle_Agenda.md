# Huddle Agenda

Hospice On-Call Route Huddle  
Scheduled: 4:15 PM

Requested decisions:
- Is there a defensible first urgent field route by 4:30?
- Can Helen be RN Kelly's first route, or do medication-order clarity and caregiver instructions need supervisor/provider closure first?
- Can Frank remain an LPN visit, or does oxygen equipment failure require DME/RN triage before dispatch?
- Does June need immediate RN field visit, or phone/chaplain/SW support while facility nurse remains present?
- Can Mary admission proceed at 6:00, or do DNR, comfort-kit, DME, and med profile issues block route readiness?
- What must be done before pharmacy courier cutoff?
- Which caregiver/facility calls should happen before 4:30?
- What can be safely deferred to phone support or later field follow-up?
- What should RN Kelly, LPN Sam, and RN Priya be told without overpromising?

Huddle note: Bring current blockers and owners. Do not rely on green schedule-board status alone.
