# Admission Intake Status

Admission and Intake Status  
Updated: 4:05 PM

| Patient | Intake/order status |
|---|---|
| Mary Liu | Hospice election signed at hospital; DNR scan not visible in agency chart; final discharge med list updated at noon; comfort kit order pending pharmacy profile |
| Helen Warner | Established hospice patient; plan of care active |
| Frank Morales | Established hospice patient; DME oxygen order active |
| June Alvarez | Established facility hospice patient |
| Owen Clark | Established hospice patient |
| Rosa Delgado | Established hospice patient |
| Thomas Greene | Established hospice patient |
| Paul Bennett | Established hospice patient; missed visit documentation pending |

Intake note: A scheduled admission is not route-ready if legal documents, medication profile, DME timing, or family expectations are incomplete.
