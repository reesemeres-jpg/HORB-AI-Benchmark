# Medication Profile Comparison

Medication Profile Comparison  
Updated: 4:07 PM

**Helen Warner**  
Current agency MAR:
- Morphine concentrate 5 mg PO/SL every 2 hours PRN pain or dyspnea
- Lorazepam 0.5 mg every 4 hours PRN anxiety/restlessness
- Haloperidol 0.5 mg every 6 hours PRN nausea/agitation

NP progress note from yesterday:
- "Pain worsening. May need morphine 10 mg every 1 hour PRN if persistent. Discussed with daughter."
- No signed medication order visible in pharmacy or MAR.

**Frank Morales**
- Morphine 5 mg PO/SL every 2 hours PRN dyspnea
- Lorazepam pending refill delivery
- Nebulizer listed from prior plan, not confirmed in home

**Mary Liu**
- Hospital discharge list includes oxycodone and bowel regimen
- Hospice comfort-kit profile pending

Medication note: A provider discussion note is not the same as an active MAR order for caregiver teaching.
