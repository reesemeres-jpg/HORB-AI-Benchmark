# Safety Triage Alerts

Hospice Safety and Symptom Triage Alerts  
Updated: 4:06 PM

| Patient | Alert |
|---|---|
| Helen Warner | Severe uncontrolled pain reported; caregiver afraid to medicate; possible need for RN assessment and supervisor/provider order clarification |
| Frank Morales | Dyspnea/equipment concern; wife reports oxygen concentrator alarm and low backup tank |
| June Alvarez | Active dying, family distress; facility nurse present and no medication crisis reported yet |
| Mary Liu | New admission with incomplete DNR/comfort-kit/DME readiness |
| Owen Clark | Teaching need, but caregiver not available until after 6 |
| Rosa Delgado | Caregiver crisis/respite request, no symptom emergency reported |
| Paul Bennett | Missed visit and unreachable |
| Thomas Greene | Routine tuck-in, stable voicemail |

Safety note: Green routine status should be overridden by severe symptoms, equipment failure, caregiver inability, and medication-order gaps.
