# Facility Communication June

Facility Communication  
Patient: June Alvarez  
Updated: 4:08 PM

Facility nurse report:
- Patient is minimally responsive.
- Breathing pattern has changed.
- No signs of grimacing or distress right now.
- Comfort medications are present in facility e-kit.
- Family is at bedside and asking for support and explanation.
- Facility nurse can call hospice if symptoms change.
- Facility requested hospice nurse visit "when possible," but did not describe uncontrolled symptoms.

Family request:
- Daughter asks whether hospice nurse can come soon.
- Family also open to chaplain phone call.

Facility note: June has important emotional support needs, but a licensed facility nurse is present and no medication crisis is reported at this moment.
