# DME Oxygen Status

DME, Oxygen, and Equipment Status  
Updated: 4:05 PM

| Patient | DME/equipment issue |
|---|---|
| Helen Warner | Hospital bed, oxygen concentrator, and bedside table in home; daughter says oxygen is not the current concern |
| Frank Morales | DME portal says concentrator and backup tank delivered; wife reports concentrator alarm/beeping and backup tank gauge "looks low"; DME technician not yet dispatched |
| June Alvarez | Facility oxygen available; no home DME issue |
| Mary Liu | Hospital bed requested; delivery window 5:00–7:00; oxygen not ordered; bedside commode pending |
| Owen Clark | No DME issue |
| Rosa Delgado | Family asked about respite bed; no DME issue |
| Thomas Greene | No DME issue |
| Paul Bennett | DME unknown |

DME note: Vendor delivery complete does not prove equipment is functioning or adequate in the home.
