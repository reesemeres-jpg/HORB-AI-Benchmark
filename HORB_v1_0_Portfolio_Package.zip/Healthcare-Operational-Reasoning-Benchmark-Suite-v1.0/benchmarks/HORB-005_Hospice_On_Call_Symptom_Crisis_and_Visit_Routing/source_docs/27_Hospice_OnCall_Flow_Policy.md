# Hospice OnCall Flow Policy

Hospice On-Call Visit Coordination Workflow

1. Schedule-board green status is a starting point, not final field-route release.
2. Symptom crisis visits require current medication orders, caregiver ability, staff scope, and route feasibility.
3. Field staff should not teach from draft or "consider" medication notes that are not active orders.
4. Oxygen/DME failure reports require vendor escalation and backup-equipment planning.
5. LPN visits should stay within scope and should not substitute for RN/provider triage of unstable symptoms or equipment failure.
6. Facility active-dying support should account for whether a licensed nurse is present and whether symptoms are controlled.
7. New admissions require legal paperwork, medication profile, comfort kit, DME timing, and family expectations to be reconciled.
8. Late-day pharmacy and DME cutoffs should be addressed before field dispatch when they determine whether the visit can solve the problem.

Operational reminder: Sending a field clinician before medication, DME, or caregiver gates close can leave the family unsupported and delay a higher-priority crisis.
