# Late Day Courier DME Cutoffs

Late-Day Vendor and Courier Cutoffs  
Updated: 4:07 PM

| Service | Cutoff / status |
|---|---|
| Hospice pharmacy same-day courier | Last route leaves at 4:45 |
| Pharmacy new orders | Must be signed and received before courier leaves |
| DME urgent oxygen technician | Dispatch available until 6:00, but wait time variable |
| DME routine bed delivery | Mary delivery window 5:00–7:00 |
| Facility e-kit refill | Next courier tomorrow morning unless urgent |
| Nurse supply pickup | Office pickup possible until 5:00 |

Cutoff note: If pharmacy or DME questions are not addressed before the cutoff windows, field staff may arrive without the tools needed to fix the problem.
