# Hospice On-Call Board

Hospice On-Call / Evening Visit Board  
Generated: 4:02 PM  
Display source: hospice scheduling board

| Patient | Current plan | Assigned staff | Visible time | Board status |
|---|---|---|---:|---|
| Helen Warner | Pain crisis visit | RN Kelly | 4:30 PM | Green |
| Frank Morales | Dyspnea follow-up | LPN Sam | 4:45 PM | Green |
| June Alvarez | Active-dying support visit | RN Kelly | 5:30 PM | Yellow |
| Thomas Greene | Routine tuck-in call | Triage RN | 5:00 PM | Green |
| Mary Liu | New hospice admission | RN Priya | 6:00 PM | Yellow |
| Owen Clark | Medication teaching | LPN Sam | 6:15 PM | Green |
| Rosa Delgado | Social work caregiver crisis | SW Nina | 6:30 PM | Yellow |
| Paul Bennett | Missed visit follow-up | Unassigned | Hold | Yellow |

Incoming alerts:
| Source | Patient | Note |
|---|---|---|
| Daughter call | Helen Warner | Pain "10/10" and caregiver scared to give more meds |
| DME vendor | Frank Morales | Oxygen equipment delivery marked complete |
| Facility nurse | June Alvarez | Family asking if "this is the end" |
| Intake desk | Mary Liu | Hospital discharge packet updated |

Board note: Green reflects schedule-board status only. It may not reflect updated symptom calls, medication orders, comfort-kit contents, DME function, caregiver ability, RN/LPN scope, admission paperwork, or route feasibility.
