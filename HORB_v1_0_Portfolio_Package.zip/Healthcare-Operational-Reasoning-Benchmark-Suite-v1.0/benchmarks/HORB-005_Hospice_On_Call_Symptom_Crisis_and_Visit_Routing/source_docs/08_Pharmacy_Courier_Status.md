# Pharmacy Courier Status

Hospice Pharmacy and Courier Status  
Updated: 4:06 PM

| Patient | Pharmacy status |
|---|---|
| Helen Warner | Comfort kit already in home; no new signed dose-change order received by pharmacy |
| Frank Morales | Lorazepam refill pending; courier can add if order confirmed before 4:45 |
| Mary Liu | New admission comfort kit pending; pharmacy waiting for final admission med profile |
| Owen Clark | Lorazepam delivered to home this morning per pharmacy portal |
| June Alvarez | Facility e-kit stocked |
| Thomas Greene | No pharmacy need |
| Rosa Delgado | No pharmacy need |
| Paul Bennett | Unknown |

Courier note: Last same-day pharmacy courier leaves at 4:45. Pharmacy cannot fill "consider" dose changes or pending profiles without signed orders.
