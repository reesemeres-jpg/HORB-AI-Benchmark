# Family Communication Notes

Family and Facility Communication Notes  
Updated: 4:09 PM

**Helen Warner**  
Daughter is scared and wants someone to tell her exactly what to give. She may not be able to safely follow complex instructions by phone unless the order is clearly active.

**Frank Morales**  
Wife is worried the oxygen machine is not working. She has hearing impairment and may not manage long phone troubleshooting.

**June Alvarez**  
Family wants support and reassurance. Facility nurse is at bedside and can administer comfort meds if needed.

**Mary Liu**  
Family expects hospice admission nurse around 6:00. They are asking whether equipment must arrive before the nurse.

**Rosa Delgado**  
Daughter wants respite options and emotional support, can talk after 5:30.

Communication note: Family distress matters, but staff should avoid promising routes, medication changes, or admission timing before orders and resources are confirmed.
