# General Operational Notices

General Hospice Operations Notices

- A scheduled urgent visit can still be unsafe to dispatch if medication orders are unclear.
- Caregiver fear or inability can make a visit higher priority, but it also increases the need for clear orders and RN support.
- DME delivery complete does not prove oxygen equipment is working.
- LPN routine visits should be escalated when the issue becomes unstable dyspnea or equipment failure.
- Facility families may need urgent emotional support even when symptoms are controlled.
- Same-day pharmacy courier cutoffs can determine whether medication changes are useful tonight.
- New admissions should not be promised until DNR, medication profile, comfort kit, and DME timing are reconciled.
- The first field route should be the one with closed enough gates to actually help.
- Phone/SW/chaplain support can be appropriate while RN routes are reserved for symptom or equipment crises.
- The coordinator should update the schedule only after live owner decisions close.
