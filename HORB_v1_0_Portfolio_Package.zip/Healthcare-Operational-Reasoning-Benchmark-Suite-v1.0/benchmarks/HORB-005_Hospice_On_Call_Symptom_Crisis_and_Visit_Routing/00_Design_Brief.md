# HORB-005: Hospice On-Call / Symptom Crisis & Visit Routing

**Suite:** Healthcare Operational Reasoning Benchmark Suite  
**Version:** 1.0  
**Author:** Meredith Reese, RN  
**Original File Mapping:** Submission 023

> Evaluating operational reasoning under uncertainty in hospice operations.

## Clinical Domain

Hospice Operations

## Operational Setting

Hospice on-call symptom crisis and visit-routing window

## Operational Window

4:10 PM to 4:15 PM before the Hospice on-call route huddle.

## Primary Capability Evaluated

Hospice visit-routing and symptom-crisis operational reasoning.

## Purpose

Evaluates whether an AI system can coordinate hospice on-call routing while balancing symptom crisis calls, comfort-kit readiness, medication order ownership, DME/oxygen status, caregiver availability, nurse visit capacity, after-hours escalation, and realistic visit routing.

## Primary Evaluation Question

> **Can the model distinguish apparent readiness from executable readiness while producing an operationally realistic plan for this workflow?**

## Capability Profile

| Capability | Evaluated |
|---|:---:|
| Multi-document reasoning | ✓ |
| Operational prioritization | ✓ |
| Temporal reasoning | ✓ |
| Workflow coordination | ✓ |
| Resource allocation | ✓ |
| Ownership boundaries | ✓ |
| Source provenance | ✓ |
| Uncertainty management | ✓ |


## Operational Actors

- Hospice on-call coordinator
- Hospice RN
- Hospice physician / NP
- Pharmacy
- DME / oxygen provider
- Patient / caregiver
- Social work / chaplain as applicable
- Triage or after-hours team


## Reasoning Challenges

- Symptom crisis prioritization
- Comfort-kit versus active medication orders
- DME and oxygen functionality
- Caregiver access and safety
- Visit routing capacity
- After-hours provider ownership
- Urgent versus routine needs
- Unresolved admission or visit dependencies


## Typical Failure Modes

- Routing a visit before medication or DME gates are clear
- Treating comfort-kit presence as medication readiness
- Ignoring caregiver access or safety issues
- Overcommitting limited hospice RN capacity
- Assuming scheduled admission equals admission-ready
- Under-escalating symptom crisis calls


## Expected High-Quality Response

A strong response should:

- Integrate information across multiple documents.
- Distinguish confirmed information from apparent readiness.
- Respect ownership boundaries and role authority.
- Recognize unresolved dependencies.
- Prioritize realistically under time and resource constraints.
- Recommend only operationally executable actions.
- Carry unresolved issues forward to the appropriate huddle or owner.

## Included Materials

- `UseCase_System_Prompt.md`
- `Strict_Grading_Guidelines.md`
- `source_docs/` (28 fictional operational documents)
- `SourceDocs.zip`
- `original_batches/`

## Estimated Difficulty

**Expert**

## Estimated Human Evaluation Time

Approximately **30–45 minutes**.

## Design Notes

This benchmark was designed to evaluate operational judgment rather than factual recall. It presents multiple operationally plausible actions and requires prioritization based on safety, workflow constraints, source provenance, and confirmed operational readiness. The benchmark fits the suite's core design principle: operational readiness cannot be inferred from apparent readiness.

## Keywords

Hospice • on-call • symptom crisis • visit routing • palliative operations • AI evaluation • benchmark design • healthcare operations
