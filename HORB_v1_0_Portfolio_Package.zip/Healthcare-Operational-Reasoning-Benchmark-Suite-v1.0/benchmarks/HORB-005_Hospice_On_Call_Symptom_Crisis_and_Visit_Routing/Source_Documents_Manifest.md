# Source Documents Manifest

This benchmark includes 28 fictional operational source documents.

| # | File |
|---|---|
| 1 | `01_Hospice_OnCall_Board.md` |
| 2 | `02_Evening_Staffing_View.md` |
| 3 | `03_Patient_Status_Summary.md` |
| 4 | `04_Medication_Order_Status.md` |
| 5 | `05_DME_Oxygen_Status.md` |
| 6 | `06_Caregiver_Contact_Log.md` |
| 7 | `07_Route_Map_Constraints.md` |
| 8 | `08_Pharmacy_Courier_Status.md` |
| 9 | `09_Safety_Triage_Alerts.md` |
| 10 | `10_Admission_Intake_Status.md` |
| 11 | `11_Triage_Call_Notes.md` |
| 12 | `12_Supervisor_Notes.md` |
| 13 | `13_Field_RN_Route_Notes.md` |
| 14 | `14_LPN_SW_Chaplain_Notes.md` |
| 15 | `15_DME_Vendor_Call_Log.md` |
| 16 | `16_Medication_Profile_Comparison.md` |
| 17 | `17_Facility_Communication_June.md` |
| 18 | `18_New_Admission_Mary_Packet.md` |
| 19 | `19_Caregiver_Crisis_Rosa.md` |
| 20 | `20_Late_Day_Courier_DME_Cutoffs.md` |
| 21 | `21_Command_Center_Log.md` |
| 22 | `22_Huddle_Agenda.md` |
| 23 | `23_OnCall_Coordinator_Worklist.md` |
| 24 | `24_Recent_Updates_Digest.md` |
| 25 | `25_Risk_Watchlist.md` |
| 26 | `26_Family_Communication_Notes.md` |
| 27 | `27_Hospice_OnCall_Flow_Policy.md` |
| 28 | `28_General_Operational_Notices.md` |
