# OR Cancellation Pressure

OR Cancellation and Throughput Pressure  
Updated: 3:06 PM

| Case | Pressure |
|---|---|
| Carla Benton | First case; cancellation would delay implant room and vendor |
| Amir Qureshi | Robot block protected; surgeon concerned about lost block time |
| Denise Ward | ASC wants to avoid morning cataract delays |
| Victor Hale | High-risk vascular case may need decision before staffing finalization |
| Paul Sweeney | Short case can move if labs clear |
| Mei Lin | Surgeon available only tomorrow morning |
| Nora James | Endo anesthesia schedule full |
| Hector Alvarez | Could move later if clearance delayed |

Pressure note: Avoiding cancellation is important, but should not override unresolved safety or readiness gates.
