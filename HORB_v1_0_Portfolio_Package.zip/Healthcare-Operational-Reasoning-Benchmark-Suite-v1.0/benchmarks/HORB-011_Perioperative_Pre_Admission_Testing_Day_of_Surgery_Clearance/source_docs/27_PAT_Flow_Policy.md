# PAT Flow Policy

Pre-Admission Testing / Day-of-Surgery Readiness Workflow

1. Readiness-dashboard color is a starting point, not final surgical clearance.
2. Final readiness requires anesthesia acceptance, medication-hold clarity, lab/diagnostic review, consent readiness, equipment/implant readiness, and patient callback completion when new issues arise.
3. Anticoagulant holds and regional anesthesia plans must be explicitly verified when relevant.
4. GLP-1 or NPO updates after the ready call require anesthesia review before final clearance.
5. New fever or respiratory symptoms after ready call require ASC/anesthesia review before arrival instructions.
6. Interpreter needs should be resolved before relying on consent documentation.
7. Vendor alternatives must be approved by the surgeon when preference-card backup equipment is affected.
8. PAT staff should update dashboard status only after live owner decisions close.

Operational reminder: Preventing cancellation matters, but preserving an unsafe first case creates day-of-surgery delays and patient risk.
