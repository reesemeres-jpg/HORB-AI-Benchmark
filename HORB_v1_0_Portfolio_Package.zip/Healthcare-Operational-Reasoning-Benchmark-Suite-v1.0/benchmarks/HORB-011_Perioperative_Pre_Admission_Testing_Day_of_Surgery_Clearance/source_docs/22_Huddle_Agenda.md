# Huddle Agenda

PAT / Day-of-Surgery Readiness Huddle  
Scheduled: 3:20 PM

Requested decisions:
- Is there a defensible first final-clearance case for tomorrow?
- Can Carla remain first case, or do apixaban hold, block plan, implant backup, and surgeon/anesthesia signoff block clearance?
- Can Amir remain cleared, or does semaglutide taken yesterday require anesthesia/surgeon review before preserving robot block?
- Can Denise proceed, or do new fever/cough symptoms require ASC anesthesia review before arrival instructions?
- What should happen with Victor high-risk vascular clearance before staffing is finalized?
- Which cases need patient callbacks before 4:00?
- Which tasks should be routed to surgeon office, anesthesia, vendor, lab, interpreter services, and endoscopy recovery?
- What can safely wait until tomorrow morning versus what must close today?
- What should OR desk be told without overpromising first-case readiness?

Huddle note: Bring current blockers and owners. Do not rely on green readiness-dashboard status alone.
