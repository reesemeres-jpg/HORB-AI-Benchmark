# Lab Diagnostics Status

Labs and Diagnostics Status  
Updated: 3:06 PM

| Patient | Lab/diagnostic issue |
|---|---|
| Carla Benton | CBC acceptable; type/screen ordered for morning; no lab hold |
| Amir Qureshi | Labs acceptable; issue is medication/NPO risk |
| Denise Ward | No required labs; respiratory symptoms new |
| Hector Alvarez | EKG abnormality needs comparison; labs acceptable |
| Mei Lin | Calcium baseline acceptable |
| Paul Sweeney | Outside potassium 5.7; repeat BMP drawn at 2:40, not resulted |
| Nora James | No labs; sleep apnea equipment issue |
| Victor Hale | Stress test note incomplete; creatinine 1.8, vascular aware |

Diagnostics note: Lab acceptable status on the board may not include same-day repeat, outside abnormality, or incomplete cardiac testing.
