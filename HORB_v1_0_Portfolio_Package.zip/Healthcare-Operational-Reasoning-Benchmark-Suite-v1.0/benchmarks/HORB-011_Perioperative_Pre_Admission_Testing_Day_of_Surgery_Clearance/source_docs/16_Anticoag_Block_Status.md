# Anticoag Block Status

Anticoagulant / Regional Block Status  
Updated: 3:08 PM

**Carla Benton**  
- Apixaban active on home med list.
- Ready call note unclear: "held blood thinner per surgeon."
- Patient could not clearly identify last dose.
- Regional block planned for shoulder arthroplasty if anticoagulant hold adequate.
- Anesthesia note says block plan pending DOAC hold verification.
- Surgeon office has not faxed medication hold documentation.

**Victor Hale**  
- Aspirin/clopidogrel plan differs between vascular and cardiology notes.
- Final cardiac/anesthesia review pending.

Anticoag note: Vague "hold per surgeon" language should not be used as final block or surgery clearance.
