# Ready Call Log

Patient Ready-Call / Callback Log  
Updated: 3:06 PM

| Patient | Call issue |
|---|---|
| Carla Benton | Ready call completed yesterday; patient was unsure whether apixaban last dose was Sunday or Monday |
| Amir Qureshi | NPO call completed; patient later messaged that semaglutide was taken yesterday |
| Denise Ward | Ready call complete; voicemail today reports cough, fever 100.8, and asks whether to still come |
| Hector Alvarez | Ready call pending clearance |
| Mei Lin | Daughter says patient understands Mandarin better than English and wants interpreter |
| Paul Sweeney | Patient instructed to wait for lab callback |
| Nora James | Patient says CPAP machine is broken and cannot be brought |
| Victor Hale | Patient told final call depends on cardiology/anesthesia |

Ready-call note: A completed call can be superseded by later patient messages.
