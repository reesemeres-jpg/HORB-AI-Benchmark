# OSA CPAP Review

OSA / CPAP / Recovery Review  
Updated: 3:08 PM

**Nora James**  
- Known obstructive sleep apnea.
- Patient says CPAP machine is broken and cannot be brought tomorrow.
- Endoscopy under anesthesia scheduled at 1:00 PM.
- Endoscopy recovery area has limited monitored recovery capacity after noon.
- Anesthesia asks whether extended monitoring or reschedule plan is needed.
- GI office says case is routine but defers to anesthesia recovery plan.

OSA note: A routine endoscopy slot does not equal anesthesia recovery readiness when CPAP/OSA planning is unresolved.
