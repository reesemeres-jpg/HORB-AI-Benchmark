# Surgery Schedule View

Tomorrow Surgical Schedule Snapshot  
Updated: 3:04 PM

| OR / area | Patient | Case type | Operational pressure |
|---|---|---|---|
| OR-2 | Carla Benton | Total shoulder arthroplasty | First case; implants and beach-chair setup required |
| OR-5 | Victor Hale | Vascular bypass | High-risk case; cardiac clearance under review |
| OR-7 | Amir Qureshi | Robotic prostatectomy | Robot block reserved; long case |
| ASC Room 1 | Denise Ward | Cataract surgery | Short case; quick turnover |
| OR-9 | Hector Alvarez | Hernia repair | Standard general case |
| OR-10 | Mei Lin | Thyroidectomy | Interpreter/consent issue |
| ASC Room 3 | Paul Sweeney | Knee arthroscopy | Short case if labs clear |
| Endo Room 4 | Nora James | Anesthesia endoscopy | OSA/CPAP review needed |

Schedule note: Schedule priority does not override anesthesia, medication, lab, consent, equipment, or clearance gates.
