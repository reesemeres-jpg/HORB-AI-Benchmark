# Patient Family Communication Notes

Patient / Family Communication Notes  
Updated: 3:09 PM

**Carla Benton**  
Patient expects early arrival. She was unsure of last apixaban dose. Family has arranged transportation for 5:30 AM.

**Amir Qureshi**  
Patient is worried he "messed up" by taking semaglutide. Needs clear callback after anesthesia decision.

**Denise Ward**  
Patient left voicemail asking whether fever/cough means she should still come.

**Mei Lin**  
Daughter says patient prefers Mandarin for medical details and wants interpreter if consent is discussed.

**Nora James**  
Patient says CPAP repair appointment is next week and asks whether endoscopy can still happen.

Communication note: Patients should not receive final arrival/proceed instructions until owner decisions close.
