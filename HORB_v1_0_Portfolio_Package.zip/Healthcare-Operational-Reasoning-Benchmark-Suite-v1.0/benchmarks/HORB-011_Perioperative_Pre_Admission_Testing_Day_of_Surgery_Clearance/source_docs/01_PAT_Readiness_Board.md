# PAT Readiness Board

Pre-Admission Testing / Day-of-Surgery Readiness Board  
Generated: 3:02 PM  
Display source: perioperative readiness dashboard

| Patient | Surgery | Scheduled | Visible status | Board color |
|---|---|---:|---|---|
| Carla Benton | Total shoulder arthroplasty | Tomorrow 7:30 AM | PAT complete | Green |
| Amir Qureshi | Robotic prostatectomy | Tomorrow 9:00 AM | Cleared | Green |
| Denise Ward | Cataract surgery | Tomorrow 8:15 AM | Ready call complete | Green |
| Hector Alvarez | Hernia repair | Tomorrow 10:30 AM | Clearance pending | Yellow |
| Mei Lin | Thyroidectomy | Tomorrow 11:00 AM | Interpreter consent pending | Yellow |
| Paul Sweeney | Knee arthroscopy | Tomorrow 12:00 PM | Labs pending | Yellow |
| Nora James | Endoscopy under anesthesia | Tomorrow 1:00 PM | OSA review needed | Yellow |
| Victor Hale | Vascular bypass | Tomorrow 7:45 AM | Cardiology review | Red |

Incoming / pressure:
| Source | Patient | Note |
|---|---|---|
| OR desk | Carla Benton | First case should not cancel |
| Urology office | Amir Qureshi | Surgeon wants robot time preserved |
| Eye center | Denise Ward | Wants early discharge workflow |
| Anesthesia clinic | Victor Hale | Requests updated cardiac note before final decision |

Board note: Green reflects dashboard status only. It may not reflect current anticoagulant holds, GLP-1/NPO instructions, cardiac clearance, lab abnormalities, consent language, equipment/implant readiness, or anesthesia acceptance.
