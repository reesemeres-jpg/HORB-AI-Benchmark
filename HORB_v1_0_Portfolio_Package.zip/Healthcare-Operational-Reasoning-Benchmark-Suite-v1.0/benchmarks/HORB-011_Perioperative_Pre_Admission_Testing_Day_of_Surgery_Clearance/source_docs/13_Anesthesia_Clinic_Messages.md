# Anesthesia Clinic Messages

Anesthesia Clinic Message Log  
Updated: 3:08 PM

2:48 — Anesthesia requested updated cardiac note for Victor before final clearance.  
2:55 — Anesthesia asked PAT to verify Carla DOAC hold before regional block decision.  
3:02 — Anesthesia machine/room not relevant yet; issue is clearance and medication readiness.  
3:05 — Amir semaglutide message received. Anesthesia wants aspiration-risk review and possible delay/modified plan decision.  
3:06 — Denise fever/cough message routed for ASC anesthesia review.  
3:07 — Paul repeat BMP pending; anesthesia will not clear until potassium issue addressed.  
3:08 — Nora OSA/CPAP issue routed to anesthesia and endoscopy recovery lead.

Anesthesia clinic note: A dashboard "cleared" status can be reversed or held by new patient calls or medication/lab updates.
