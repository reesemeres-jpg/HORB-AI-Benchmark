# Risk Watchlist

PAT / Day-of-Surgery Readiness Risk Watchlist  
Updated: 3:10 PM

High risk / cancellation pressure:
- Carla: first-case pressure, unclear DOAC hold, regional block not final, implant backup backordered without surgeon approval.
- Amir: robot block pressure, GLP-1 taken yesterday, aspiration-risk review not documented.
- Denise: early ASC case, new cough/fever message after ready call.
- Victor: high-risk vascular case, incomplete cardiology stress-test addendum, anesthesia acceptance pending.
- Paul: potassium 5.7 outside lab, repeat pending.
- Mei: consent language/interpreter attestation issue.
- Nora: OSA with broken CPAP and limited monitored recovery.

Medium risk:
- Hector: abnormal EKG comparison pending.
- OR desk pressure: wants first-case/robot block answers today.
- Interpreter/lab/vendor callbacks: limited time before end of day.
