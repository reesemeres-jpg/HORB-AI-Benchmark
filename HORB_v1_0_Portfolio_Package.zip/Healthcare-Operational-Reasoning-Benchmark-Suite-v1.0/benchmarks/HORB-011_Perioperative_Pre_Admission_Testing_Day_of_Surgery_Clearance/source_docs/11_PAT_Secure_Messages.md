# PAT Secure Messages

PAT / Perioperative Secure Messages  
Thread: 3:00–3:08 PM

3:00 — OR Desk: Carla is first case tomorrow. Need readiness locked by 3:30 if possible.

3:01 — PAT RN: Carla apixaban last dose unclear. Patient said "maybe Monday night."

3:02 — Anesthesia: Do not finalize Carla block plan until DOAC hold is verified.

3:03 — Vendor Desk: Carla shoulder backup glenoid size is backordered. Rep says alternate may work.

3:04 — Surgeon Office: Surgeon has not approved alternate implant size.

3:05 — Amir portal: I took my weekly Ozempic yesterday. Is that okay before surgery?

3:05 — Anesthesia: Amir GLP-1 issue needs review. Do not mark final cleared.

3:06 — ASC Nurse: Denise left voicemail with fever/cough today. Cataract board still shows ready.

3:07 — PAT RN: Mei needs Mandarin interpreter attestation. English consent alone may not be enough.

3:08 — Lead PAT Nurse: Bring blockers to 3:20 huddle. Do not rely on dashboard green.
