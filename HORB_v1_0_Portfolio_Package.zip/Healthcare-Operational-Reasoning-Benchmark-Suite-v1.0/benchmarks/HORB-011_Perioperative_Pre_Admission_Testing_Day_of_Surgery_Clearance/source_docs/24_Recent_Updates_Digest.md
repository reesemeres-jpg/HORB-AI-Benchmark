# Recent Updates Digest

Recent Updates Digest  
Compiled 3:10 PM

- Carla looks ready because PAT is complete and she is first case, but apixaban hold is unclear, block plan is not final, and backup implant size is not approved.
- Amir looks cleared because his labs and consent are fine, but semaglutide was taken yesterday after the NPO call and anesthesia has not reviewed aspiration risk.
- Denise looks ready because cataract ready call is complete, but she reported cough and fever today and ASC anesthesia has not reviewed.
- Victor remains high risk because stress-test addendum and anesthesia acceptance are not finalized.
- Paul needs repeat potassium result reviewed before clearance.
- Mei needs interpreter-supported consent confirmation.
- Nora needs OSA/CPAP recovery plan.
- Hector needs EKG comparison/anesthesia review but is not the most time-sensitive first-case issue.
