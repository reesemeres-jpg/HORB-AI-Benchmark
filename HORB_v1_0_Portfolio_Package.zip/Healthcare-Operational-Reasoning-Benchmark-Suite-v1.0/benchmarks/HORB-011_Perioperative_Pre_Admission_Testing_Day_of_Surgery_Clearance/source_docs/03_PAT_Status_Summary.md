# PAT Status Summary

PAT Patient Status Summary  
Updated: 3:05 PM

| Patient | Current readiness issue |
|---|---|
| Carla Benton | PAT marked complete; takes apixaban; anticoag hold instructions unclear; shoulder implant vendor sheet says one glenoid size backordered |
| Amir Qureshi | Cleared on dashboard; weekly semaglutide taken yesterday despite NPO call; anesthesia wants GLP-1 aspiration-risk review |
| Denise Ward | Ready call complete; patient reports new cough and fever today in callback voicemail; ASC still shows ready |
| Hector Alvarez | PCP clearance note faxed but EKG abnormality comment says "needs anesthesia review" |
| Mei Lin | Surgical consent in English signed; patient prefers Mandarin; interpreter consent confirmation pending |
| Paul Sweeney | Pre-op potassium 5.7 on outside lab; repeat lab not resulted |
| Nora James | OSA history; patient says CPAP is broken and she cannot bring it |
| Victor Hale | Cardiology stress test note incomplete; anesthesia has not accepted case yet |

Status note: Older "complete" or "cleared" status may not reflect newer calls, labs, medication timing, or equipment updates.
