# Equipment Implant Status

Equipment, Vendor, and Implant Readiness  
Updated: 3:06 PM

| Patient / case | Equipment issue |
|---|---|
| Carla Benton | Shoulder implant vendor sheet shows one glenoid size backordered; surgeon preference card requires backup size; vendor rep says alternative may work but surgeon has not approved |
| Amir Qureshi | Robot assigned; no equipment issue |
| Denise Ward | Cataract lens in cabinet; no equipment issue |
| Hector Alvarez | Hernia mesh available |
| Mei Lin | Nerve monitor available |
| Paul Sweeney | Arthroscopy tower ready |
| Nora James | Endo anesthesia recovery bay availability under review due OSA |
| Victor Hale | Vascular graft options available; blood conservation setup pending cardiac decision |

Equipment note: Vendor verbal workaround does not replace surgeon approval or preference-card readiness.
