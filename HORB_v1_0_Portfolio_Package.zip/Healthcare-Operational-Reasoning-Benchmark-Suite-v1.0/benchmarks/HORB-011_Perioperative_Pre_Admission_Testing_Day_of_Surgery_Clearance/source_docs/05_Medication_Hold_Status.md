# Medication Hold Status

Medication Hold / Pre-op Instructions  
Updated: 3:05 PM

| Patient | Medication issue |
|---|---|
| Carla Benton | Apixaban listed; PAT call note says "hold blood thinner per surgeon"; last dose field blank |
| Amir Qureshi | Semaglutide weekly injection taken yesterday; NPO instructions completed before patient disclosed dose |
| Denise Ward | No anticoagulant; reports OTC cold medicine today |
| Hector Alvarez | Takes metoprolol; instructed to continue |
| Mei Lin | Levothyroxine to continue |
| Paul Sweeney | Takes lisinopril and potassium supplement; potassium supplement hold not documented |
| Nora James | Nightly sedative listed; anesthesia review pending |
| Victor Hale | Aspirin and clopidogrel plan differs between vascular note and cardiology note |

Medication note: A generic "hold per surgeon" or completed NPO call is not enough for high-risk medication decisions.
