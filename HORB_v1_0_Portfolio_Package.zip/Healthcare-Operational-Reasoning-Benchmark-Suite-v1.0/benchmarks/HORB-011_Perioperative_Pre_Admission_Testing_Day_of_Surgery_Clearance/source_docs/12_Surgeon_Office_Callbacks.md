# Surgeon Office Callbacks

Surgeon Office Callback Log  
Updated: 3:08 PM

**Carla Benton / Shoulder arthroplasty**  
Orthopedic office says surgeon wants first case preserved but has not approved alternate glenoid size. Office nurse will ask surgeon about implant backup and apixaban hold documentation.

**Amir Qureshi / Robotic prostatectomy**  
Urology office says they do not want robot block cancelled. They ask anesthesia to decide GLP-1 plan.

**Denise Ward / Cataract**  
Eye center says mild symptoms may still be okay, but anesthesia/ASC nurse must review fever/cough before arrival instructions.

**Hector Alvarez / Hernia repair**  
Surgeon office faxed PCP note but does not have prior EKG.

**Mei Lin / Thyroidectomy**  
Surgeon office says interpreter should be used if there is any question about consent understanding.

Callback note: Surgeon preference or schedule pressure does not equal final clearance.
