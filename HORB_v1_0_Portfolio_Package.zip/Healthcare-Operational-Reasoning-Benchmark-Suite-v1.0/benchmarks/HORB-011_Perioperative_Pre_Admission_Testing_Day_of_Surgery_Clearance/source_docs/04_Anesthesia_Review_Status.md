# Anesthesia Review Status

Anesthesia Pre-op Review  
Updated: 3:05 PM

| Patient | Anesthesia review issue |
|---|---|
| Carla Benton | Anesthesia note says "verify DOAC hold before block"; regional block plan not final |
| Amir Qureshi | GLP-1 medication taken yesterday; anesthesia wants surgeon/anesthesia decision about aspiration-risk mitigation |
| Denise Ward | New fever/cough not reviewed by anesthesia |
| Hector Alvarez | EKG shows new right bundle branch block; anesthesia requested prior EKG comparison |
| Mei Lin | Airway note acceptable; consent/interpreter issue remains |
| Paul Sweeney | Potassium 5.7 requires repeat or provider review before anesthesia clearance |
| Nora James | OSA/CPAP issue; anesthesia asks whether post-procedure monitoring is available |
| Victor Hale | Cardiac clearance not finalized; high-risk vascular case |

Anesthesia note: Dashboard clearance does not equal final anesthesia acceptance when medication, airway, lab, or cardiac questions remain.
