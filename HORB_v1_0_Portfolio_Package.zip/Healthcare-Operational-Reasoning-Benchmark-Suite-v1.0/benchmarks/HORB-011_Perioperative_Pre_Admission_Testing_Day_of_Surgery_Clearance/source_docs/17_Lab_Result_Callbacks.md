# Lab Result Callbacks

Lab Callback Status  
Updated: 3:08 PM

| Patient | Status |
|---|---|
| Paul Sweeney | Repeat BMP drawn 2:40; lab says result expected around 3:35 |
| Carla Benton | No pending lab except morning type/screen |
| Amir Qureshi | Labs acceptable |
| Denise Ward | No required labs; fever/cough message active |
| Hector Alvarez | No lab issue |
| Mei Lin | Calcium baseline acceptable |
| Nora James | No lab issue |
| Victor Hale | Creatinine 1.8; vascular aware; cardiac clearance still open |

Lab callback note: Pending repeat lab should not be treated as cleared until result is reviewed by the appropriate owner.
