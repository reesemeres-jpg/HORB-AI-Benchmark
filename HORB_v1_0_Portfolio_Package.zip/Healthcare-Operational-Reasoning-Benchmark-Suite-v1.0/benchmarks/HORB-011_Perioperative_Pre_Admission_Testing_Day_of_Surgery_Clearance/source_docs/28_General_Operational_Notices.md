# General Operational Notices

General PAT / Perioperative Readiness Notices

- A green readiness row can lag patient callbacks, medication timing, labs, and vendor updates.
- A completed ready call can be superseded by new symptoms or medication disclosures.
- "Hold per surgeon" is not sufficient when the last anticoagulant dose is unclear.
- A robot block or first-case slot should not override anesthesia review.
- A signed consent may still require interpreter confirmation.
- A vendor workaround is not final until surgeon approved.
- A broken CPAP can affect anesthesia recovery planning.
- Pending lab repeats should not be treated as cleared.
- The safest huddle output may be a blocker list rather than a named cleared case.
- Update the readiness board after owner-confirmed decisions close.
