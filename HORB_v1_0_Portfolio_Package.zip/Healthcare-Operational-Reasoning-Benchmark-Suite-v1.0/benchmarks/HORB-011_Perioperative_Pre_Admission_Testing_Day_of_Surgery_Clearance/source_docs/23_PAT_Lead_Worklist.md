# PAT Lead Worklist

PAT Lead Nurse Worklist  
Generated: 3:10 PM

- Reconcile readiness dashboard with new patient callbacks, anesthesia notes, medication hold status, lab results, consent/interpreter notes, and equipment/vendor status.
- Put hold note on Carla final clearance until DOAC last dose, regional block decision, implant backup approval, and anesthesia/surgeon signoff are confirmed.
- Ask surgeon office/vendor to resolve Carla backup glenoid approval and medication hold documentation.
- Ask anesthesia to review Amir semaglutide timing and document proceed/delay/modified plan.
- Put hold note on Denise arrival instructions until ASC anesthesia reviews fever/cough message.
- Ask lab to flag Paul repeat BMP result for anesthesia review when available.
- Ask interpreter services/surgeon office to arrange Mandarin consent confirmation for Mei before tomorrow.
- Ask endoscopy recovery/anesthesia for Nora CPAP/OSA monitoring plan.
- Ask cardiology/anesthesia for Victor stress-test addendum and final decision.
- Prepare huddle brief with one possible cleared case or clear no-final-clearance explanation.
- Update readiness dashboard only after owner decisions close.
