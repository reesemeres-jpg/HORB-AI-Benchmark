# Interpreter Consent Notes

Interpreter and Consent Notes  
Updated: 3:08 PM

**Mei Lin**  
- Chart language preference: Mandarin.
- Surgical consent signed in English during office visit.
- Daughter says patient nods along but prefers Mandarin for medical details.
- Interpreter attestation not attached to consent packet.
- Surgeon office says interpreter should be used if there is any uncertainty.
- Interpreter services can schedule Mandarin phone interpreter before tomorrow if requested by 4:00.

Interpreter note: A signed English consent may still require interpreter-supported confirmation when language preference and family report conflict.
