# GLP1 NPO Status

GLP-1 / NPO / Aspiration-Risk Review  
Updated: 3:08 PM

**Amir Qureshi**  
- Weekly semaglutide injection taken yesterday.
- Original NPO call completed before this disclosure.
- Patient denies nausea/vomiting but reports early satiety.
- Robotic prostatectomy is long case under general anesthesia.
- Anesthesia wants surgeon/anesthesia decision before final clearance.
- Urology office wants robot time preserved but defers to anesthesia.

GLP-1 note: Completed NPO instructions do not close aspiration-risk review after new GLP-1 information.
