# Command Center Log

PAT / Perioperative Readiness Command Center Log  
2:45–3:10 PM

2:45 — Readiness dashboard showed Carla, Amir, and Denise green.  
2:52 — Denise left fever/cough voicemail.  
2:55 — Anesthesia requested Carla DOAC hold verification.  
3:00 — OR desk asked to preserve Carla first case.  
3:03 — Vendor reported Carla backup glenoid size backordered.  
3:05 — Amir reported semaglutide taken yesterday.  
3:06 — Paul repeat BMP still pending.  
3:07 — Mei interpreter attestation issue surfaced.  
3:08 — Nora CPAP broken message routed to anesthesia/endoscopy.  
3:09 — Victor cardiac stress-test addendum still not visible.  
3:10 — Lead PAT nurse asked for blocker list before 3:20 huddle.
