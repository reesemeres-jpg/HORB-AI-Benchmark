# HORB-011: Perioperative Pre-Admission Testing / Day-of-Surgery Clearance

**Suite:** Healthcare Operational Reasoning Benchmark Suite  
**Version:** 1.0  
**Author:** Meredith Reese, RN  
**Original File Mapping:** Submission 029

> Evaluating operational reasoning under uncertainty in perioperative pre-admission testing.

## Clinical Domain

Perioperative Pre-Admission Testing

## Operational Setting

Late-afternoon next-day surgery readiness and cancellation-prevention window

## Operational Window

3:10 PM to 3:20 PM before the PAT / day-of-surgery readiness huddle.

## Primary Capability Evaluated

Surgical readiness and cancellation-prevention operational reasoning.

## Purpose

Evaluates whether an AI system can coordinate pre-admission testing and next-day surgical readiness while balancing anesthesia clearance, anticoagulant holds, GLP-1/NPO updates, respiratory symptoms, abnormal labs, cardiac clearance, interpreter/consent needs, OSA/CPAP recovery planning, vendor/implant readiness, callbacks, and OR schedule preservation.

## Primary Evaluation Question

> **Can the model distinguish apparent readiness from executable readiness while producing an operationally realistic plan for this workflow?**

## Capability Profile

| Capability | Evaluated |
|---|:---:|
| Multi-document reasoning | ✓ |
| Operational prioritization | ✓ |
| Temporal reasoning | ✓ |
| Workflow coordination | ✓ |
| Resource allocation | ✓ |
| Ownership boundaries | ✓ |
| Source provenance | ✓ |
| Uncertainty management | ✓ |


## Operational Actors

- PAT lead
- Anesthesia reviewer
- Surgeon office
- Cardiology / clearance owner
- Interpreter services
- Vendor / implant representative
- OR scheduling
- Patient / caregiver
- Lab / diagnostics


## Reasoning Challenges

- Anesthesia acceptance
- Medication-hold review
- NPO/GLP-1 status
- New symptoms or abnormal labs
- Cardiac clearance
- Consent and interpreter readiness
- Vendor/implant readiness
- Patient callback completion


## Typical Failure Modes

- Treating PAT complete as surgery cleared
- Assuming signed consent means anesthesia acceptance
- Ignoring medication-hold or lab gates
- Accepting vendor verbal workaround as final readiness
- Preserving schedule without clearance support
- Overlooking patient callback needs


## Expected High-Quality Response

A strong response should:

- Integrate information across multiple documents.
- Distinguish confirmed information from apparent readiness.
- Respect ownership boundaries and role authority.
- Recognize unresolved dependencies.
- Prioritize realistically under time and resource constraints.
- Recommend only operationally executable actions.
- Carry unresolved issues forward to the appropriate huddle or owner.

## Included Materials

- `UseCase_System_Prompt.md`
- `Strict_Grading_Guidelines.md`
- `source_docs/` (28 fictional operational documents)
- `SourceDocs.zip`
- `original_batches/`

## Estimated Difficulty

**Expert**

## Estimated Human Evaluation Time

Approximately **30–45 minutes**.

## Design Notes

This benchmark was designed to evaluate operational judgment rather than factual recall. It presents multiple operationally plausible actions and requires prioritization based on safety, workflow constraints, source provenance, and confirmed operational readiness. The benchmark fits the suite's core design principle: operational readiness cannot be inferred from apparent readiness.

## Keywords

Pre-admission testing • surgical clearance • day-of-surgery readiness • perioperative • cancellation prevention • AI evaluation • benchmark design • healthcare operations
