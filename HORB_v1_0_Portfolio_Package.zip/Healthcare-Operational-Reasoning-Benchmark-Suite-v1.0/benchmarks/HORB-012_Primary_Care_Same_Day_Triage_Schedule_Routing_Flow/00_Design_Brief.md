# HORB-012: Primary Care Same-Day Triage / Schedule Routing Flow

**Suite:** Healthcare Operational Reasoning Benchmark Suite  
**Version:** 1.0  
**Author:** Meredith Reese, RN  
**Original File Mapping:** Submission 030

> Evaluating operational reasoning under uncertainty in primary care operations.

## Clinical Domain

Primary Care Operations

## Operational Setting

Primary care same-day access and triage-routing window

## Operational Window

1:18 PM to 1:30 PM before the Primary care same-day access huddle.

## Primary Capability Evaluated

Ambulatory triage and schedule-routing operational reasoning.

## Purpose

Evaluates whether an AI system can coordinate primary care same-day triage and routing while balancing appointment requests, nurse-visit slots, telehealth holds, parking-lot symptoms, portal updates, voicemail symptoms, pediatric calls, allergic-reaction screening, interpreter needs, provider slot capacity, front desk routing, and emergency escalation decisions.

## Primary Evaluation Question

> **Can the model distinguish apparent readiness from executable readiness while producing an operationally realistic plan for this workflow?**

## Capability Profile

| Capability | Evaluated |
|---|:---:|
| Multi-document reasoning | ✓ |
| Operational prioritization | ✓ |
| Temporal reasoning | ✓ |
| Workflow coordination | ✓ |
| Resource allocation | ✓ |
| Ownership boundaries | ✓ |
| Source provenance | ✓ |
| Uncertainty management | ✓ |


## Operational Actors

- Triage nurse
- Provider
- Front desk / scheduling
- Call center
- Interpreter services
- Patient / caregiver
- Pediatric or specialty support as relevant
- Clinic leadership / huddle team


## Reasoning Challenges

- Red-flag symptom review
- Same-day versus ED escalation
- Nurse-scope fit
- Telehealth appropriateness
- Parking-lot/waiting-room concerns
- Interpreter or caregiver needs
- Provider slot capacity
- Multiple patient requests competing for access


## Typical Failure Modes

- Treating appointment slot as destination safety
- Routing to nurse visit without scope fit
- Ignoring red-flag symptoms
- Assuming patient-requested visit type is appropriate
- Using portal response when direct escalation is needed
- Overcommitting limited same-day slots


## Expected High-Quality Response

A strong response should:

- Integrate information across multiple documents.
- Distinguish confirmed information from apparent readiness.
- Respect ownership boundaries and role authority.
- Recognize unresolved dependencies.
- Prioritize realistically under time and resource constraints.
- Recommend only operationally executable actions.
- Carry unresolved issues forward to the appropriate huddle or owner.

## Included Materials

- `UseCase_System_Prompt.md`
- `Strict_Grading_Guidelines.md`
- `source_docs/` (28 fictional operational documents)
- `SourceDocs.zip`
- `original_batches/`

## Estimated Difficulty

**Expert**

## Estimated Human Evaluation Time

Approximately **30–45 minutes**.

## Design Notes

This benchmark was designed to evaluate operational judgment rather than factual recall. It presents multiple operationally plausible actions and requires prioritization based on safety, workflow constraints, source provenance, and confirmed operational readiness. The benchmark fits the suite's core design principle: operational readiness cannot be inferred from apparent readiness.

## Keywords

Primary care • same-day triage • schedule routing • ambulatory operations • access huddle • AI evaluation • benchmark design • healthcare operations
