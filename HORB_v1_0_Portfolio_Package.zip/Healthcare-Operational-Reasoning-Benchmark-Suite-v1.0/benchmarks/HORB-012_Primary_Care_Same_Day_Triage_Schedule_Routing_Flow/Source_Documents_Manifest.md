# Source Documents Manifest

This benchmark includes 28 fictional operational source documents.

| # | File |
|---|---|
| 1 | `01_SameDay_Access_Board.md` |
| 2 | `02_Clinic_Staffing_Schedule.md` |
| 3 | `03_Patient_Triage_Summary.md` |
| 4 | `04_Call_Center_Log.md` |
| 5 | `05_RedFlag_Triage_Guide.md` |
| 6 | `06_Nurse_Scope_Workflow.md` |
| 7 | `07_Provider_Slot_Status.md` |
| 8 | `08_Patient_Risk_History.md` |
| 9 | `09_Parking_Lot_Waiting_Status.md` |
| 10 | `10_Interpreter_Accessibility_Status.md` |
| 11 | `11_Triage_RN_Messages.md` |
| 12 | `12_Provider_Lead_Notes.md` |
| 13 | `13_Portal_Message_Updates.md` |
| 14 | `14_Voicemail_Transcripts.md` |
| 15 | `15_SameDay_Slot_Log.md` |
| 16 | `16_ED_Escalation_Workflow.md` |
| 17 | `17_Pediatric_Triage_Note.md` |
| 18 | `18_Allergy_Reaction_Triage.md` |
| 19 | `19_BP_Medication_History.md` |
| 20 | `20_ChestPain_ParkingLot_Note.md` |
| 21 | `21_Command_Center_Log.md` |
| 22 | `22_Huddle_Agenda.md` |
| 23 | `23_Triage_RN_Worklist.md` |
| 24 | `24_Recent_Updates_Digest.md` |
| 25 | `25_Risk_Watchlist.md` |
| 26 | `26_Patient_Communication_Notes.md` |
| 27 | `27_PrimaryCare_Triage_Policy.md` |
| 28 | `28_General_Operational_Notices.md` |
