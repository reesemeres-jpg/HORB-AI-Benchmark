# Triage RN Worklist

Triage RN Worklist  
Generated: 1:18 PM

- Reconcile same-day access board with newest call-center, voicemail, portal, parking-lot, risk-history, and red-flag notes.
- Address Grace first because she is physically in parking lot with chest pressure, pallor, diabetes, and prior stent; coordinate provider lead/front desk and emergency plan if active symptoms.
- Do not have Grace walk in or wait for 2:40 slot until emergency risk is assessed.
- Address Nora as possible stroke symptoms; advise emergency services per protocol if symptoms are current.
- Address Daniel as severe symptomatic hypertension; do not route as routine RN BP check.
- Address Luis as complex UTI/possible pyelonephritis or higher-level evaluation need; use Spanish interpreter if calling.
- Address Aisha promptly for allergic-reaction symptom screen before routine callback.
- Ask pediatric nurse to review Ben hydration/fever before confirming pediatric slot.
- Route Martin work note to portal response after red flags are handled.
- Prepare huddle brief with no unsupported clinic-slot releases and current owner actions.
- Update board statuses only after triage decisions close.
