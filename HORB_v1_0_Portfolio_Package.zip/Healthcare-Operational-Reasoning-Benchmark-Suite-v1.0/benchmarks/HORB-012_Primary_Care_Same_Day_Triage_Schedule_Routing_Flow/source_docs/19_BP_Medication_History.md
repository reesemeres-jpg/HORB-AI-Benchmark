# BP Medication History

Blood Pressure Medication History  
Patient: Daniel Reed  
Updated: 1:13 PM

Relevant history:
- Hypertension.
- CKD stage 3.
- Prior TIA listed in problem list.
- Lisinopril refill overdue by about two weeks.
- Last clinic BP 166/88 three months ago.
- Voicemail today reports BP 204/112 and blurry vision.
- RN BP check scheduled by board before voicemail was reviewed.

Medication note: A refill request plus symptomatic severe BP elevation should not be handled as a routine nurse BP check.
