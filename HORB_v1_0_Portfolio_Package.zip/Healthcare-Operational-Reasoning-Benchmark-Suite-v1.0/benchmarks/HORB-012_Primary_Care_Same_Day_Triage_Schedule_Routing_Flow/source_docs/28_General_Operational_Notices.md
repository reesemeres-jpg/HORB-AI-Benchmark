# General Operational Notices

General Primary Care Access Notices

- A green same-day slot can lag updated portal, voicemail, and call-center information.
- Patient-requested appointment type may not match clinical urgency.
- A nurse visit slot is not appropriate for red-flag symptoms.
- A telehealth slot is not appropriate for possible stroke symptoms.
- Parking-lot proximity does not make emergency symptoms clinic-appropriate.
- Front desk observations can be important triage information.
- Interpreter availability matters, but emergency escalation should not wait for routine visit scheduling.
- Work notes and routine follow-ups can wait behind red-flag triage.
- The safest huddle output may be a blocker/escalation list rather than a named office visit.
- Update the access board after owner-confirmed triage decisions close.
