# Patient Communication Notes

Patient and Family Communication Notes  
Updated: 1:17 PM

**Grace Miller**  
Patient is alone in car and may think she is waiting for a clinic appointment. Communication should avoid telling her to drive elsewhere without triage decision.

**Luis Ortega**  
Spanish preferred. He may need interpreter-assisted triage because portal details raise risk beyond routine UTI.

**Nora Kim**  
Husband speaks English, but patient prefers Korean. Possible emergency advice should not wait for routine telehealth setup.

**Daniel Reed**  
Hearing impairment noted. Voicemail-only communication may not be enough for urgent symptoms.

**Aisha Rahman**  
Portal message lacks full airway symptom screen. Needs direct assessment before routine antibiotic advice.

**Ben Carter**  
Parent is worried about hydration and needs pediatric-specific guidance.

Communication note: Patient-facing messages should reflect acuity and avoid confirming clinic slot use before triage closes.
