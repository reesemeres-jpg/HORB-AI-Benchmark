# Nurse Scope Workflow

RN / MA Visit Scope and Workflow  
Updated: current clinic process

Nurse visit appropriate examples:
- Stable BP recheck without symptoms.
- Urine dip for uncomplicated urinary symptoms without fever, flank pain, vomiting, pregnancy risk, immunocompromise, or complex anatomy.
- Vaccine administration after screening.
- Wound check under existing provider order.
- Routine medication teaching under current plan.

Nurse visit not appropriate without provider/urgent escalation:
- Chest pain or chest pressure.
- Possible stroke symptoms.
- Severe hypertension with symptoms.
- Possible pyelonephritis, vomiting, or solitary kidney concern.
- Possible allergic reaction involving lips/tongue/throat/wheezing.
- Pediatric dehydration concern without clinical triage.

Workflow note: A nurse-visit slot should not be used to absorb a patient whose symptoms exceed nurse-scope triage.
