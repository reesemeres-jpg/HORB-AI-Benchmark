# Same-Day Access Board

Primary Care Same-Day Access / Triage Board  
Generated: 1:07 PM  
Display source: clinic access board

| Patient | Request | Visible next step | Board color |
|---|---|---|---|
| Grace Miller | Chest pressure, wants appointment | Same-day NP slot 2:40 | Green |
| Luis Ortega | UTI symptoms | Nurse visit urine dip 2:15 | Green |
| Nora Kim | Severe headache | Telehealth 3:00 | Green |
| Daniel Reed | Medication refill / BP check | RN BP visit 2:30 | Green |
| Aisha Rahman | New rash after antibiotic | Provider callback | Yellow |
| Ben Carter | Pediatric fever | Pediatric slot hold | Yellow |
| Olivia Hart | Post-ER follow-up | Schedule next available | Yellow |
| Martin Vega | Work note request | Portal response | Green |

Incoming / pressure:
| Source | Patient | Note |
|---|---|---|
| Front desk | Grace Miller | Patient in parking lot asking if she can wait |
| Portal queue | Luis Ortega | Message updated after board assignment |
| Call center | Nora Kim | Husband called with new symptom detail |
| Provider lead | Same-day slots | Wants one slot preserved for true office-appropriate visit |

Board note: Green reflects access-board routing only. It may not reflect current red-flag symptoms, ED criteria, nurse scope, interpreter/caregiver needs, vitals, medication risks, or provider acceptance.
