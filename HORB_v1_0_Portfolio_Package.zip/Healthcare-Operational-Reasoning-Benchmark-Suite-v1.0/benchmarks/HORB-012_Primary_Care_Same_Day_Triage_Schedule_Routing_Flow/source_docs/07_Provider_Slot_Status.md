# Provider Slot Status

Same-Day Provider Slot Status  
Updated: 1:10 PM

| Slot / provider | Status |
|---|---|
| NP Jamie 2:40 | Held by board for Grace chest pressure |
| NP Jamie 4:10 | Open for office-appropriate acute visit |
| Dr. Rao urgent overlay | Possible after 3:30 if case is office-appropriate and not ED-level |
| Pediatric acute hold | Tentatively available at 2:20 if pediatric nurse clears |
| Telehealth 3:00 | Held by board for Nora headache |
| RN urine dip 2:15 | Held by board for Luis |
| RN BP check 2:30 | Held by board for Daniel |
| MA rapid vitals room | Available for brief in-clinic assessment only if safe to enter clinic workflow |

Provider note: Holding a slot does not mean the clinic is the correct destination.
