# Patient Triage Summary

Primary Care Patient Triage Summary  
Updated: 1:12 PM

| Patient | Current status |
|---|---|
| Grace Miller | 62F chest pressure since morning; wants clinic appointment; front desk notes she looks pale in parking lot; history of diabetes and prior stent; board placed NP slot before RN callback |
| Luis Ortega | 34M dysuria; nurse visit assigned; portal update says fever 101.8, flank pain, vomiting, and only one kidney after prior surgery |
| Nora Kim | 45F severe headache; telehealth assigned; husband reports new slurred speech and right arm weakness in call-center note |
| Daniel Reed | 71M refill and BP check; RN visit assigned; patient reports home BP 204/112 and blurry vision in voicemail |
| Aisha Rahman | Started amoxicillin yesterday; new rash and lip tingling; no shortness of breath documented yet |
| Ben Carter | 3M fever and poor intake; parent wants same-day pediatric slot; wet diapers decreased |
| Olivia Hart | ED follow-up after fall; anticoagulant status unclear |
| Martin Vega | Work note request after viral illness; no red flags documented |

Status note: Earlier appointment routing may not reflect newer calls, portal updates, parking-lot appearance, or scope changes.
