# Clinic Staffing Schedule

Clinic Staffing and Same-Day Capacity  
Updated: 1:10 PM

| Staff / role | Assignment |
|---|---|
| Triage RN | Same-day triage, callback queue, 1:30 huddle |
| NP Jamie | Same-day acute slots at 2:40 and 4:10 |
| Dr. Rao | Double-booked; can take one urgent in-office escalation after 3:30 if appropriate |
| RN visit nurse | BP checks, vaccines, urine dips, wound checks until 3:00 |
| MA team | Rooming and rapid vitals; one MA short today |
| Front desk | Schedule changes and parking-lot calls |
| Interpreter services | Spanish phone interpreter available; Korean interpreter by video after 2:30 |
| Pediatric nurse | Available by phone until 2:00 |
| Lab draw station | Open until 4:00 |
| Referral coordinator | Not available until 2:30 |
| Clinic manager | Available for patient flow concerns until 1:25 |

Staffing note: The triage RN can complete one direct call or routing decision at a time. A same-day slot or nurse-visit slot is not safe to use until symptom severity and scope are confirmed.
