# Huddle Agenda

Primary Care Same-Day Triage Huddle  
Scheduled: 1:30 PM

Requested decisions:
- Is there any defensible first same-day clinic slot assignment before 1:30?
- Can Grace remain in NP 2:40 slot, or do chest pressure, pallor, cardiac history, and parking-lot status require emergency escalation?
- Can Luis remain a nurse urine dip, or do fever/flank pain/vomiting/solitary kidney require provider/urgent escalation?
- Can Nora remain telehealth, or do slurred speech/right arm weakness require emergency services?
- Can Daniel remain RN BP check, or do BP 204/112 and blurry vision require urgent escalation?
- How should Aisha allergy symptoms be triaged?
- Can Ben use pediatric hold, or does hydration status require pediatric nurse review first?
- Which one patient call/routing decision should the triage RN do first?
- What can safely wait?
- What should front desk tell patients without overpromising?

Huddle note: Bring current blockers and owners. Do not rely on green same-day board status alone.
