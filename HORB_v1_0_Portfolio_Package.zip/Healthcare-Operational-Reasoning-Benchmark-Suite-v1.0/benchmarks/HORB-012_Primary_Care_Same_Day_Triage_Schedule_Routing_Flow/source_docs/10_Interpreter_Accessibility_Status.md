# Interpreter Accessibility Status

Interpreter and Accessibility Status  
Updated: 1:10 PM

| Patient | Language/access issue |
|---|---|
| Luis Ortega | Spanish preferred; phone interpreter available now |
| Nora Kim | Korean preferred; husband speaks English, but patient communication may need Korean interpreter; video interpreter available after 2:30 |
| Aisha Rahman | English-speaking |
| Grace Miller | English-speaking |
| Daniel Reed | English-speaking; hearing impairment noted |
| Ben Carter | Parent English-speaking |
| Olivia Hart | English-speaking |
| Martin Vega | English-speaking |

Interpreter note: Interpreter availability can affect callback timing, but emergency symptoms should not wait for routine appointment workflow.
