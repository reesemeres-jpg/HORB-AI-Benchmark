# RedFlag Triage Guide

Clinic Red-Flag Triage Guide  
Updated: current clinic protocol

- Chest pressure with pallor, diabetes, prior cardiac history, or weakness should be escalated urgently and may require EMS/ED rather than clinic appointment.
- New slurred speech, unilateral weakness, facial droop, or sudden severe headache should be treated as possible stroke and directed to emergency services.
- Fever with flank pain, vomiting, or single kidney should not be handled as a routine nurse urine dip without provider/urgent-care or ED review.
- Blood pressure over 180 systolic or 120 diastolic with blurry vision, chest pain, neuro symptoms, or severe headache needs urgent evaluation rather than routine BP check.
- Rash with lip/tongue swelling, throat symptoms, wheezing, or rapidly spreading hives requires urgent escalation.
- Decreased wet diapers or poor intake in young child with fever should receive pediatric clinical triage before scheduling.
- Staff should avoid telling patients to drive themselves if emergency symptoms are possible.

Guide note: Triage determines destination; appointment availability does not determine acuity.
