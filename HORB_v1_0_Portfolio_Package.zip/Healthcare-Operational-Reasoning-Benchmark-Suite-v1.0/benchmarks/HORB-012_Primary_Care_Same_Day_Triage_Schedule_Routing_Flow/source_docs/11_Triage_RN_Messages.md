# Triage RN Messages

Triage RN / Clinic Secure Messages  
Thread: 1:05–1:15 PM

1:05 — Front Desk: Grace is in the parking lot looking pale. Should we bring her inside for the 2:40 slot?

1:06 — Triage RN: Do not have her walk in yet. Need phone assessment and likely emergency plan.

1:07 — Call Center: Nora husband says speech is slurred and right arm weak. Telehealth still on board.

1:08 — Provider Lead: Nora should not wait for telehealth if stroke symptoms are current. Triage for emergency services.

1:09 — Portal Nurse: Luis updated UTI message with fever, flank pain, vomiting, one kidney.

1:10 — Provider Lead: Luis is not a routine urine dip. Needs provider/urgent escalation; consider ED if unable to keep fluids down or solitary kidney concern.

1:11 — RN Visit Nurse: Daniel is on my 2:30 BP check. His voicemail says BP 204/112 and blurry vision.

1:12 — Provider Lead: Daniel should not be routine BP visit. Triage urgently.

1:13 — MA Lead: Only one room can be opened for rapid vitals before 1:30.

1:14 — Triage RN: Need blocker list for 1:30 huddle. Do not fill slots until acuity is sorted.

1:15 — Clinic Manager: Front desk asking what to tell patients waiting for call backs.
