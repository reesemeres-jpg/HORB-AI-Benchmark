# PrimaryCare Triage Policy

Primary Care Same-Day Triage and Scheduling Workflow

1. Same-day board color is a starting point, not final triage disposition.
2. Clinic appointment slots should not be used to manage likely emergency symptoms.
3. Nurse visits must remain within RN/MA scope and should not replace provider or emergency triage.
4. Possible stroke, active chest pain with high-risk features, symptomatic severe hypertension, and complex urinary infection signs require urgent escalation.
5. Parking-lot patients with concerning symptoms should be assessed through triage workflow before being asked to walk into clinic or wait.
6. Interpreter needs should be addressed, but emergency symptoms should not be delayed by routine scheduling workflow.
7. Pediatric fever with poor intake or decreased urine output requires pediatric clinical triage before slot confirmation.
8. The triage RN should update the board only after live triage decisions close.

Operational reminder: A same-day slot can be the wrong answer when the destination should be emergency care or urgent provider triage.
