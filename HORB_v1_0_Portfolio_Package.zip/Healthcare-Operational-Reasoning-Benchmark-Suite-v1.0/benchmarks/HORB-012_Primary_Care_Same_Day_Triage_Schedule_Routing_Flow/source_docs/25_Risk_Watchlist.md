# Risk Watchlist

Primary Care Same-Day Triage Risk Watchlist  
Updated: 1:18 PM

High risk / routing pressure:
- Grace: chest pressure, pallor, cardiac history, alone in parking lot.
- Nora: severe headache plus slurred speech and right arm weakness.
- Daniel: BP 204/112 with blurry vision and prior TIA/CKD.
- Luis: fever, flank pain, vomiting, solitary kidney.
- Aisha: rash and lip tingling after amoxicillin.
- Triage RN: one call/routing decision at a time.
- MA/front desk: limited ability to safely manage parking-lot patient.

Medium risk:
- Ben: pediatric fever and fewer wet diapers, needs pediatric triage.
- Olivia: fall follow-up with possible anticoagulant, not immediate first call unless symptoms worsen.
- Martin: work note request, safe to defer.
- Same-day slots: should be preserved for office-appropriate cases after red flags are escalated.
