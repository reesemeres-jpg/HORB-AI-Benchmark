# Call Center Log

Call Center and Front Desk Log  
Updated: 1:12 PM

12:42 — Grace Miller called for chest pressure and fatigue. Scheduler offered 2:40 NP slot.  
12:56 — Grace arrived early and is waiting in parking lot because she felt "too tired to walk in."  
1:02 — Front desk noted Grace looked pale through car window and asked triage RN whether to bring her in.  
1:03 — Luis portal message routed as UTI; nurse urine dip slot created.  
1:06 — Luis added: fever, flank pain, vomiting, and one kidney.  
1:07 — Nora's husband called: headache now with slurred speech and right arm weakness.  
1:08 — Daniel left voicemail: BP 204/112 at home and blurry vision; wants refill and BP check.  
1:10 — Aisha asked whether rash and lip tingling after antibiotic can wait for callback.  
1:11 — Ben parent asked if fever and fewer wet diapers can be seen today.  
1:12 — Martin work-note request remained stable.

Call note: Call-center scheduling can lag clinical triage updates.
