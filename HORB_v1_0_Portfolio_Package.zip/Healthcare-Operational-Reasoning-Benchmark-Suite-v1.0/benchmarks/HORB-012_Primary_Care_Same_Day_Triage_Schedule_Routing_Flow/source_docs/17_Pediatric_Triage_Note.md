# Pediatric Triage Note

Pediatric Triage Note  
Patient: Ben Carter  
Updated: 1:14 PM

Parent report:
- Age 3.
- Fever since yesterday.
- Drinking less today.
- Fewer wet diapers.
- No known chronic conditions.
- Parent can bring patient if advised.
- Pediatric nurse available by phone until 2:00.
- Pediatric acute hold exists at 2:20 if triage supports office visit.

Pediatric note:
Fever with decreased urine output needs pediatric clinical triage before slot confirmation. This may be office-appropriate if hydration status is acceptable, but cannot be assumed from the board alone.
