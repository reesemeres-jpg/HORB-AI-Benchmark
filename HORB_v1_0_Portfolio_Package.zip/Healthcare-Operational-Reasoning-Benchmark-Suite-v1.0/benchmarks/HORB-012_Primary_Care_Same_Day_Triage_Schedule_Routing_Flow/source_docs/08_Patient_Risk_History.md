# Patient Risk History

Relevant Risk History Snapshot  
Updated: 1:11 PM

| Patient | Relevant history |
|---|---|
| Grace Miller | Diabetes, hypertension, coronary stent 2019, takes aspirin and atorvastatin |
| Luis Ortega | Left nephrectomy after trauma; recurrent kidney infections; no known drug allergies |
| Nora Kim | Migraine history, but no prior neurologic deficits documented |
| Daniel Reed | Hypertension, CKD stage 3, prior TIA, takes lisinopril but refill overdue |
| Aisha Rahman | Penicillin allergy not previously listed; started amoxicillin for dental infection yesterday |
| Ben Carter | Born term, no chronic illness; parent reports fewer wet diapers |
| Olivia Hart | Atrial fibrillation listed; anticoagulant use not reconciled after ED fall |
| Martin Vega | No major chronic history in chart |

History note: Past history can change the triage risk even when the complaint sounds routine.
