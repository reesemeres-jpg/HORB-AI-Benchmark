# ED Escalation Workflow

Clinic Emergency Escalation Workflow  
Updated: current clinic process

If a patient has possible emergency symptoms:
- Triage RN should determine whether the patient is safe to stay on phone, whether to call 911, or whether another responsible adult should call emergency services.
- Staff should not ask a potentially unstable patient to drive themselves.
- Parking-lot patients with concerning symptoms should not be walked into clinic without RN/provider direction.
- Front desk can stay on the phone or send staff to visually monitor only if safe and directed.
- Provider lead can be interrupted for emergency triage.
- Documentation should include symptoms, advice given, and whether emergency services were contacted.

Workflow note: Clinic appointment scheduling should pause when symptoms suggest emergency-level care.
