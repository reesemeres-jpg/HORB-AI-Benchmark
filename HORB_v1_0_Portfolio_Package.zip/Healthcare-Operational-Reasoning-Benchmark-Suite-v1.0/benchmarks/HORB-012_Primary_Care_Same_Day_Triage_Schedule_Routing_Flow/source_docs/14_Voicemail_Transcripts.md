# Voicemail Transcripts

Voicemail Transcripts  
Updated: 1:15 PM

**Daniel Reed — 1:08 PM**  
"This is Daniel Reed. My BP machine says 204 over 112. Vision is blurry. I need my blood pressure medicine refilled and can come for the nurse check."

**Grace Miller — 12:42 PM original call callback note**  
"I feel pressure in my chest and I'm exhausted. I can drive over and wait if you have anything."

**Ben Carter parent — 1:11 PM**  
"He has fever and hasn't peed much today. He's drinking a little but not like normal."

**Nora Kim husband — 1:07 PM call note**  
"She says worst headache, and now her words sound funny. Her right arm seems weak."

Voicemail note: A patient may request a routine visit even when the content of the message suggests emergency triage.
