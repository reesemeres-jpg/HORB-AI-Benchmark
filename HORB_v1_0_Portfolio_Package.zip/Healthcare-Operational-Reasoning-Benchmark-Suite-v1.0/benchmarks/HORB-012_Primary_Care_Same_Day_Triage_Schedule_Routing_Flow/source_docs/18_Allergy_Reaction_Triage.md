# Allergy Reaction Triage

Allergy / Rash Triage Note  
Patient: Aisha Rahman  
Updated: 1:14 PM

Patient report:
- Started amoxicillin yesterday after dental visit.
- Rash on chest and arms.
- Lips feel tingly.
- No shortness of breath reported in portal message.
- No known penicillin allergy previously documented.
- Patient is at home awaiting callback.

Nurse protocol reminder:
Lip/tongue/throat symptoms, wheeze, trouble breathing, rapidly spreading hives, or dizziness require urgent escalation. If stable, provider-directed medication plan may still be needed because antibiotic was prescribed outside clinic.

Allergy note: A provider callback may be appropriate only after urgent allergic-reaction symptoms are actively assessed.
