# OR Liaison Notes

OR Liaison Notes  
Updated: 1:08 PM

**OR-6 / Evan Brooks**  
OR circulator says room is nearly ready and surgeon is present. Circulator also acknowledges prior OR-5 camera count issue and asks for confirmation before opening sterile field.

**OR-2 / Devon Patel**  
Neuro team wants cart early for positioning and implant check. They understand power tray and implant matching are still being checked.

**OR-4 / Marisol Rivera**  
Ortho team says vendor rep is in hallway and believes revision trays are usable. OR liaison has not received SPD loaner tracking signoff.

**OR-9 / Ian Moore**  
Urology room ready. Cysto tray and scope appear straightforward; OR asks for cart if no hidden issue.

**OR-8 / Talia Chen**  
Robotics team can begin room setup without full sterile cart, but cannot start case until arm set 2 is sterile and complete.

Liaison note: OR teams may request early delivery for setup, but SPD release status still controls what can be opened or used.
