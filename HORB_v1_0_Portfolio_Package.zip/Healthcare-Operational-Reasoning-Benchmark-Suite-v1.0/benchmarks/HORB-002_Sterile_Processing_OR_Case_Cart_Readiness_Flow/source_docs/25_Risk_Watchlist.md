# Risk Watchlist

SPD / OR Case Readiness Risk Watchlist  
Updated: 1:10 PM

High risk / schedule pressure:
- Evan: room pressure and green board, but prior camera count discrepancy unresolved.
- Devon: neuro start pressure, but power tray BI/cooling and implant match unresolved.
- Marisol: long revision case pressure, but vendor tracking and BI unresolved.
- Ian: shortest apparent released cart; may be best candidate if no hidden issue.
- Runner: one confirmed route before 1:30.
- OR desk: asking for release sequence under pressure.

Medium risk:
- Talia: robotic arm set 2 not sterile; partial setup may confuse OR if mislabeled.
- Hannah: vascular tray missing clamp.
- OR-2/OR-4 vendors: verbal confidence without complete SPD signoff.
- Return cart queue: morning dirty carts could delay later cycles.
