# SPD Processing Status

Sterile Processing Department Processing Status  
Updated: 1:05 PM

| Tray / item | Current status |
|---|---|
| Devon spine basic tray | Sterile shelf, pulled |
| Devon spine power tray | Sterilizer 3 cycle complete; cooling; BI release pending |
| Devon implant loaner set | Vendor paperwork scanned; implant list not matched to preference card |
| Marisol revision knee base set | Sterile shelf, pulled |
| Marisol vendor revision tray A | Cycle complete; missing loaner tracking sticker |
| Marisol vendor revision tray B | Cycle complete; BI not resulted yet |
| Evan lap chole tray | Sterile shelf, pulled |
| Evan 5 mm camera | Reprocessed; leak test passed; scope count from prior case unresolved |
| Ian cysto scope set | Ready shelf; blue peel pack intact |
| Talia robotic arm set 1 | Sterile shelf, pulled |
| Talia robotic arm set 2 | Washer complete; sterilizer load not started |
| Hannah vascular tray | Being assembled; missing small vascular clamp from set |

SPD note: A staged cart is not released until required trays, cycle records, loaner documents, counts, and specialty equipment are complete.
