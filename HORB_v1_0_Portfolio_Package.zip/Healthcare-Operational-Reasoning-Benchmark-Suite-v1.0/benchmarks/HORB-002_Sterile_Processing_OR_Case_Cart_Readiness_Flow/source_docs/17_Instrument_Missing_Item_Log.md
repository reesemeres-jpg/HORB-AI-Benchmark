# Instrument Missing Item Log

Missing Instrument and Substitute Log  
Updated: 1:06 PM

| Case / set | Issue | Substitute status |
|---|---|---|
| Hannah vascular tray | Small vascular clamp missing | Substitute clamp being searched |
| Talia robotic arm set 2 | Not sterile | No substitute set available |
| Devon spine power tray | Pending release | No sterile backup power tray on shelf |
| Marisol vendor tray A | Tracking sticker missing | Vendor has duplicate sheet, not SPD sticker |
| Evan camera count | Prior case count unresolved | Backup 5 mm camera in repair queue |
| Ian cysto | No missing item | None needed |
| Grace minor set | Released | Not linked to active OR |

Missing item note: A verbal substitute suggestion still needs SPD/OR approval before the case cart is considered complete.
