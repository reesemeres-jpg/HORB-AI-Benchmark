# Biological Indicator Status

Biological Indicator and Load Review Status  
Updated: 1:08 PM

| Load/item | BI status | Comment |
|---|---|---|
| Sterilizer 3 / Devon spine power tray | BI incubating | Earliest read 1:28 if no alarm |
| Sterilizer 4 / Marisol vendor tray A | BI acceptable from previous load protocol; document sticker missing |
| Sterilizer 5 / Marisol vendor tray B | BI not resulted | Cycle estimated complete at 1:08; BI started after unload |
| Low-temp unit / Ian cysto accessories | Released | BI not required for this load type per local process |
| Sterilizer 6 / Talia arm set 2 | Not loaded | No BI started |
| Sterilizer 2 / minor sets | Released | Complete |

BI note: BI pending means the set should not be treated as released unless an approved emergency exception is documented.
