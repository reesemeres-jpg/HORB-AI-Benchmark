# SPD Flow Policy

Sterile Processing / OR Case-Cart Flow Workflow

1. Case-cart tracker color is a starting point, not final sterile release.
2. Cart release requires tray completeness, sterilizer/load review, BI status when required, count reconciliation, preference-card match, and loaner/vendor traceability when applicable.
3. A room-ready OR or waiting surgeon does not override sterile processing release criteria.
4. Vendor verbal confirmation does not replace SPD documentation and tracking.
5. Items tied to unresolved count discrepancies should not be reused until reconciled or formally excepted.
6. Partial carts should be labeled setup-only if any required item remains unreleased.
7. Runners should take one confirmed released cart route, not multiple tentative carts.

Operational reminder: Sending a cart that cannot be opened creates downstream delay and safety risk.
