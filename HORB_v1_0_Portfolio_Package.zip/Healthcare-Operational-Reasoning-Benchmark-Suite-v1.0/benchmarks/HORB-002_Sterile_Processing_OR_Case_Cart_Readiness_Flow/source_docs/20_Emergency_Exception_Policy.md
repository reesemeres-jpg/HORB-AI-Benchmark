# Emergency Exception Policy

Emergency Release / IUSS / Exception Policy

- Immediate-use steam sterilization and emergency exception release require documented clinical urgency, surgeon acknowledgment, anesthesia/OR awareness, SPD lead approval, and complete cycle records.
- Emergency exception is not for routine schedule pressure, convenience, or avoiding a minor delay.
- Vendor loaner trays still require traceability documentation unless formal leadership exception is documented.
- BI pending sets require approved exception before use.
- Count discrepancy items should not be reused until count reconciliation or leadership-approved exception is documented.
- Partial case-cart delivery should be labeled as setup-only if any required item remains unreleased.

Policy note: "Surgeon waiting" or "room ready" is not by itself an emergency exception.
