# OR Schedule Pressure

OR Schedule Pressure Snapshot  
Updated: 1:05 PM

| OR | Current operational pressure |
|---|---|
| OR-6 | Room turnover almost complete; surgeon asking to roll Evan by 1:35 |
| OR-2 | Neuro team says patient will be in room by 1:40 if implants are ready |
| OR-4 | Ortho revision expected long case; surgeon wants no delay after 2:00 |
| OR-8 | Robotics setup needs 30 minutes; room team asking for final cart status |
| OR-9 | Cysto add-on short case; urology asks to keep it moving |
| OR-11 | Vascular access revision can wait if instrument build not complete |

OR desk note: OR schedule pressure does not override sterile release, count reconciliation, or loaner/BI requirements.
