# General Operational Notices

General SPD / OR Operational Notices

- Green case-cart status can lag sterilizer, BI, loaner, count, and preference-card updates.
- A completed sterilizer cycle may still need BI, cooling, and load review before release.
- Loaner trays require traceability documentation even when the vendor rep is present.
- A scope or camera can pass reprocessing but remain blocked by a count discrepancy.
- Preference-card revisions should be checked before implant-heavy cases are released.
- Routine schedule pressure is not an emergency exception.
- Partial setup should be labeled clearly so the OR does not open or depend on unreleased items.
- A runner should receive one confirmed released route, not several possible carts.
- SPD lead should communicate blockers without overpromising readiness.
- The safest first move may be the boring one that is actually released.
