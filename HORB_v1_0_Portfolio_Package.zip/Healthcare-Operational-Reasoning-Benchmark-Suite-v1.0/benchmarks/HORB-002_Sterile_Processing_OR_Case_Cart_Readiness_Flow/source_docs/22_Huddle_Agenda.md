# Huddle Agenda

SPD / OR Readiness Huddle Agenda  
Scheduled: 1:15 PM

Requested decisions:
- Is there a defensible first cart delivery before 1:30?
- Can Evan's lap chole cart go to OR-6, or does the prior camera count discrepancy block release?
- Can Devon's spine cart go to OR-2, or do BI/cooling and implant list issues block release?
- Can Marisol's revision knee cart go to OR-4, or do vendor tracking/BI issues block release?
- Can Ian's cysto cart go to OR-9 as the one confirmed route?
- Should any partial cart go for room setup only, and how must it be labeled?
- What can be told to OR-6, OR-2, OR-4, and OR desk without overpromising?
- Which single route should Runner 1 take before 1:30?
- What work should Tech A/B/C/D continue while release decisions are pending?

Huddle note: Bring current blockers and owners. Do not rely on green case-cart board status alone.
