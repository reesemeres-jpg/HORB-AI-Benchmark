# SPD Staffing View

SPD Staffing and Assignment View  
Posted: 1:04 PM

| Role | Assignment |
|---|---|
| SPD lead | OR communication and release sequencing |
| Tech A | Neuro spine trays / Devon |
| Tech B | Ortho loaner paperwork / Marisol |
| Tech C | Scope room support / Evan and Ian |
| Tech D | Robotics instruments / Talia |
| Runner 1 | One OR delivery route before 1:30 |
| Runner 2 | On break until 1:35 |
| Sterilizer operator | Monitoring Sterilizer 3 and Sterilizer 5 |
| Scope tech | Leak tests and scope logs |
| OR liaison | Available by phone until 1:20 |
| Vendor desk | Checking loaner paperwork and implant sheets |

Staffing note: The SPD lead can complete one direct release decision or OR call at a time. Runners should receive one confirmed cart route after release, not multiple tentative pulls.
