# Count Discrepancy Log

Instrument Count and Reconciliation Log  
Updated: 1:05 PM

| Item/case | Issue |
|---|---|
| Evan 5 mm camera / prior OR-5 case | Scope room logged camera as returned; OR-5 count sheet still shows camera line unresolved |
| Evan lap chole tray | Tray count correct |
| Ian cysto set | Count correct |
| Hannah vascular tray | One small vascular clamp missing from tray build |
| Devon spine power tray | Count checked before sterilizer; final release pending BI/cooling |
| Marisol vendor tray A | Vendor count sheet complete but tracking sticker missing |
| Marisol vendor tray B | Vendor count sheet complete; BI pending |
| Talia arm set 2 | Washer count complete; not sterilized yet |

Count note: A missing or unresolved count line should be reconciled before the item is sent to an OR, even if the item is physically present.
