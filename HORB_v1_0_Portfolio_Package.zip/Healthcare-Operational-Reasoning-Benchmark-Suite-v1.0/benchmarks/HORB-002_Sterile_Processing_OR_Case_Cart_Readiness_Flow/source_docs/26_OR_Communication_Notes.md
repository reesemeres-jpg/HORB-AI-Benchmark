# OR Communication Notes

OR Team Communication Notes  
Updated: 1:09 PM

**OR-6 / Evan Brooks**  
Surgeon present. Circulator wants cart but also asked for count reconciliation before opening camera.

**OR-2 / Devon Patel**  
Neuro team wants early cart for positioning. They know implants may not match latest preference card.

**OR-4 / Marisol Rivera**  
Ortho surgeon asking whether delay is real because vendor says trays are there.

**OR-8 / Talia Chen**  
Robotics team can use nonsterile room setup time, but sterile case start waits for arm set 2.

**OR-9 / Ian Moore**  
Urology asks for cysto cart now if it is fully released.

**OR Desk**  
Asked SPD to avoid sending a cart that cannot be opened.

Communication note: Tell each OR what is released, what is setup-only, and what remains blocked. Do not imply sterile readiness before release closes.
