# OR Room Readiness

OR Room Readiness Snapshot  
Updated: 1:05 PM

| OR | Room status | Team request |
|---|---|---|
| OR-2 | Turnover complete; neuro team assembling | Wants spine cart at 1:25 if released |
| OR-4 | Turnover in progress; expected ready 1:45 | Wants revision knee cart delivered by 1:35 |
| OR-6 | Turnover nearly complete | Wants lap cart immediately |
| OR-8 | Robot docking team waiting | Wants partial robotic cart now if possible |
| OR-9 | Room ready | Wants cysto set delivered now |
| OR-11 | Not ready | Vascular case can wait |
| SPD elevator | Available | Runner can take one route before 1:30 |

OR note: Room readiness does not close sterile processing, documentation, count reconciliation, or specialty equipment gates.
