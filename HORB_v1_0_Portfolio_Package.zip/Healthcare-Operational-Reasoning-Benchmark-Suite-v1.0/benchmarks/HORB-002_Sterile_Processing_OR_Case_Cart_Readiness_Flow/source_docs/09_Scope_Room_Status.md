# Scope Room Status

Scope Room and Specialty Equipment Status  
Updated: 1:06 PM

| Item | Status |
|---|---|
| Evan 5 mm camera | Cleaned/reprocessed; leak test passed; count discrepancy from prior OR sheet unresolved |
| Ian cystoscope | Reprocessed; leak test passed; peel pack intact |
| Backup cystoscope | In repair queue |
| Light cord set | Available |
| Insufflator tubing | Available for Evan |
| Camera tower OR-6 | Functional after morning reset |
| Camera tower OR-9 | Functional |
| Scope documentation tablet | Working |

Scope room note: Leak-test pass does not by itself resolve an OR count discrepancy.
