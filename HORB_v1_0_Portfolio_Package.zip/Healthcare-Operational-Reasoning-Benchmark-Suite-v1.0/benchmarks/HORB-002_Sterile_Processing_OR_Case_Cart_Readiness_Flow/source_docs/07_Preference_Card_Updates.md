# Preference Card Updates

Preference Card Updates  
Updated: 1:04 PM

**Devon Patel — lumbar fusion / OR-2**  
Surgeon revised preference card last week to include alternate expandable cage system and specific power handle. Vendor implant list in scanned packet appears to match older card version. Neuro team asked SPD to verify before cart release.

**Marisol Rivera — total knee revision / OR-4**  
Revision knee card requires base set, vendor tray A, vendor tray B, cement restrictor set, and backup poly sizes. Cement restrictor set is on sterile shelf.

**Evan Brooks — lap chole / OR-6**  
Standard lap chole card requires lap chole tray, camera, insufflator tubing, clip applier, and cholangiogram supplies only if surgeon requests. Surgeon has not requested cholangiogram.

**Talia Chen — robotic hysterectomy / OR-8**  
Requires robotic arm set 1 and 2, uterine manipulator tray, and docking accessory set.

Preference note: A cart can look complete on the board while preference-card revisions or specialty add-ons remain unresolved.
