# OR Case Cart Board

Sterile Processing / OR Case Cart Board  
Generated: 1:02 PM  
Display source: OR case-cart tracker

| OR | Patient / case | Scheduled start | Visible cart status | Board color |
|---|---|---:|---|---|
| OR-2 | Devon Patel / lumbar fusion | 1:45 PM | Spine cart staged | Green |
| OR-4 | Marisol Rivera / total knee revision | 2:00 PM | Ortho cart ready | Green |
| OR-6 | Evan Brooks / laparoscopic cholecystectomy | 1:40 PM | Lap cart ready | Green |
| OR-8 | Talia Chen / robotic hysterectomy | 2:15 PM | Robotic cart pending | Yellow |
| OR-9 | Ian Moore / cystoscopy add-on | 1:35 PM | Scope cart ready | Green |
| OR-11 | Hannah Price / vascular access revision | 2:30 PM | Vascular cart building | Yellow |
| SPD Staging Bay A | Trauma add-on cart | Hold | Pending request | Yellow |
| SPD Staging Bay B | Empty | Available | Green |

Incoming / pressure:
| Source | Request | Note |
|---|---|---|
| OR Desk | Start OR-6 first | Room turnover nearly complete |
| Ortho Vendor | Marisol revision trays | Vendor rep says trays delivered |
| Neuro Vendor | Devon spine implants | Implant rep in OR hallway |
| Robotics Team | Talia robot instruments | One arm set still in process |

Board note: Green reflects cart-tracker display only. It may not reflect sterilizer release, biological indicator status, loaner documentation, missing instruments, count issues, or final OR acceptance.
