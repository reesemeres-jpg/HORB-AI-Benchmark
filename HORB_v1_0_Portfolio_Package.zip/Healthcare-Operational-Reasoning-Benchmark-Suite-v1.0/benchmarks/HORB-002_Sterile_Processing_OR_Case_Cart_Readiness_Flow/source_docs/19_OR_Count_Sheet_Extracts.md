# OR Count Sheet Extracts

OR Count Sheet Extracts  
Updated: 1:07 PM

**OR-5 prior case**  
- Scope room returned one 5 mm camera.
- Circulator count sheet line for 5 mm camera not signed off.
- Final room count marked "needs reconciliation."

**OR-6 Evan Brooks**  
- Lap chole tray count matches card.
- Camera requested from scope room.
- OR-6 circulator asked not to open until prior case camera line is resolved.

**OR-9 Ian Moore**  
- Cysto scope peel pack intact.
- Count sheet pre-check complete.

**OR-4 Marisol Rivera**  
- Vendor tray count sheets present for A/B.
- Tracking sticker discrepancy noted for tray A.

Count note: A count discrepancy in a prior case can block reuse of the item even if the item is physically cleaned and available.
