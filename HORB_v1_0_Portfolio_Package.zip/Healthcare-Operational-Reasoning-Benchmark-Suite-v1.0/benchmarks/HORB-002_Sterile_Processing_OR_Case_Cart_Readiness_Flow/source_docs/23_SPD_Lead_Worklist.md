# SPD Lead Worklist

SPD Lead Worklist  
Generated: 1:10 PM

- Reconcile case-cart board with sterilizer logs, BI status, count logs, loaner paperwork, preference-card updates, and OR requests.
- Confirm Evan camera count reconciliation with OR-5 circulator/scope tech before releasing OR-6 cart.
- Confirm Devon spine power tray BI/cooling release and implant list match with Neuro/vendor desk.
- Confirm Marisol tray A tracking correction and tray B BI status with Tech B/vendor desk.
- Confirm Ian cysto cart release and route readiness with OR-9.
- Confirm whether Talia partial setup is useful without arm set 2, and label any partial setup clearly.
- Ask OR desk which cases can tolerate delay if only Ian is released now.
- Keep Runner 1 for one confirmed released cart before 1:30.
- Update OR desk with blocker list after huddle.
- Continue Hannah vascular clamp search, but do not let it distract from immediate OR pressure.
