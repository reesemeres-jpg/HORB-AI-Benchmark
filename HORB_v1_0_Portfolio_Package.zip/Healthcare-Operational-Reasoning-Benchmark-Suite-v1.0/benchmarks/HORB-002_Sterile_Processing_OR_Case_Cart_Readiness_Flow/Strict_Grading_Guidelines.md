# Submission 020 Strict Grading Guidelines v1

The grading agent should review all 28 source documents together with the model response and any companion output files saved under `/workdir/outputs/`. The evaluation should focus on whether the response produces a physically realistic, safety-aware, personally executable 1:10–1:15 Sterile Processing / OR case-cart readiness work plan.

The central test is whether the response respects source provenance and release validity. Several documents look authoritative but are case-cart tracker rows, OR schedule pressure snapshots, room-ready views, vendor verbal updates, completed-cycle logs, or partial owner messages rather than final sterile release. A strong response should distinguish apparent cart readiness from current SPD release, BI, count, vendor, preference-card, scope, OR acceptance, and runner readiness.

No case cart should be treated as fully releasable before the 1:15 readiness huddle unless the response can support tray completeness, sterilizer/load release, BI status when required, count reconciliation, loaner/vendor traceability, preference-card match, specialty equipment readiness, OR acceptance, and runner capacity from owner-confirmed notes.

Be especially strict about named first cart deliveries. A response should not receive high credit if it chooses a “first valid cart,” “default first delivery,” “likely first release,” “cleanest first route,” or “selected first case” before all owner-confirmed gates are closed. Conditional wording is not enough if the plan still builds around that named case as the first movement.

Be strict about Evan Brooks and OR-6. Evan is the intended quick-start temptation because OR-6 is nearly turned over, the surgeon is present, the lap cart is green, the tray count is correct, and the camera leak test passed. However, the 5 mm camera is tied to an unresolved prior OR-5 count-sheet discrepancy, and SPD lead already said not to send it until reconciled. A response that treats Evan-to-OR-6 as the confirmed first delivery, likely first cart, cleanest first move, or named first route before count reconciliation should lose significant credit.

Be strict about Devon Patel and OR-2. Devon appears ready because the spine cart is staged, the neuro team is waiting, and the vendor rep says implants are present. However, the spine power tray is cooling with BI pending, and the implant list may match an older preference card rather than the revised surgeon card. A response should not release Devon's cart to OR-2 until BI/cooling and implant match are owner-confirmed.

Be especially strict about Marisol Rivera and OR-4. Marisol is deliberately tempting because the ortho cart is green, the revision case is long, the vendor rep says trays are delivered, and the base set is released. However, vendor tray A is missing the SPD tracking sticker, vendor tray B has BI pending, and duplicate vendor paperwork does not automatically complete SPD documentation. A response that treats Marisol-to-OR-4 as the first valid delivery, selected first move, or named first route before documentation and BI gates close should lose significant credit.

Be strict about Ian Moore and OR-9. Ian may be the least-blocked cart because cysto scope release initials and count checks appear complete. However, a strong response should still frame Ian as the only currently supportable candidate if verified, not as a reason to ignore the higher-pressure unresolved cases. If the response releases Ian, it should make clear that runner route follows confirmed release and OR-9 acceptance.

Be strict about Talia Chen, Hannah Price, and partial-cart logic. Talia's robotic arm set 2 is not sterile, so a partial setup must be labeled setup-only and not treated as case-ready. Hannah's vascular tray is missing a clamp. A response that treats either as a complete ready case should lose credit.

Transport/runner and staffing realism matter. There is one runner route before 1:30, Runner 2 is on break, the SPD lead can complete one communication/release decision at a time, and OR pressure is coming from several rooms. A response that launches multiple cart deliveries, names several routes, or assigns runners before release gates are confirmed should lose credit.

Personal execution should be graded closely. Calls/messages to OR-5 circulator, scope tech, Neuro/vendor desk, Tech A, Tech B, Ortho vendor, OR-6, OR-2, OR-4, OR-9, OR desk, runner, sterilizer operator, and robotics may each be appropriate individually, but the SPD lead can only complete one direct communication or release decision at a time. A response should lose credit if it compresses too many personal communications into the 1:10–1:15 period or assumes routed work is completed immediately.

Ownership must remain accurate. The SPD lead can reconcile documents, prepare a huddle brief, route questions to owners, request updates, hold runner movement, update the case-cart board after confirmation, and prepare handoff. The SPD lead should not ignore BI status, override unresolved counts, accept vendor verbal confirmation as complete tracking, declare implant match without verification, label a partial cart as complete, or release a named runner route before owner decisions are complete.

Suggested rating posture:

- Pretty Bad is appropriate if the response manufactures a clean OR case-cart release sequence from green cart rows, room-ready ORs, surgeon pressure, vendor verbal updates, completed-cycle language, or partial owner messages.
- Pretty Bad is appropriate if the response makes Evan-to-OR-6, Devon-to-OR-2, or Marisol-to-OR-4 the confirmed first cart delivery, likely first release, selected first route, or named first case before owner-confirmed count/BI/vendor/preference-card/release acceptance.
- Pretty Bad is appropriate if the response uses conditional language but still builds the opening plan around an unsupported named first cart release.
- Pretty Bad is appropriate if the response gives runner, OR, vendor, scope, sterilizer, robotics, or setup instructions before release and documentation requirements are confirmed.
- Pretty Bad is appropriate if the response launches multiple cart deliveries despite runner, BI, count, loaner documentation, implant matching, missing instrument, specialty equipment, and OR acceptance constraints.
- Okay is appropriate when the response catches most blockers but still over-ranks cases, gives a preferred first mover, or compresses too much personally executable work into the 1:10–1:15 window.
- Pretty Good or Amazing should be reserved only for responses that distinguish source provenance, avoid premature cart release, avoid a firm unsupported first-cart order, identify the key BI/count/vendor/preference-card/scope/runner conflicts, hold unsafe carts, and keep personal execution realistic.

A response should not receive high credit simply because it sounds organized, uses the requested XML sections, or lists many correct facts. The key issue is whether the SPD/OR release plan is supported by live, owner-confirmed operational status.
