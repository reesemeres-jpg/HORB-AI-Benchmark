# Care Coordination Calls

Office Care Coordination Call Log  
Through 12:28 PM

11:50 — Miguel spouse confirmed home access but unsure about black foam.  
11:55 — Supply vendor portal marked Miguel delivery complete.  
12:00 — Linda discharge packet arrived from hospital.  
12:05 — Linda daughter said she can be present after 2:00 and gate code missing until then.  
12:08 — DME vendor still showed oxygen driver en route.  
12:10 — Ruth daughter portal message about glucose 46.  
12:13 — Scheduler left voicemail for Ruth daughter.  
12:15 — Intake called surgeon office for Clara signed order; fax pending.  
12:16 — Supply coordinator started checking Miguel black foam.  
12:20 — PT Jamal requested Darnell gate code confirmation before route.  
12:24 — Lab coordinator flagged Naomi courier cutoff.  
12:27 — Clinical supervisor requested huddle blocker list by 12:45.
