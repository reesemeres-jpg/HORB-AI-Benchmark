# DME Oxygen Status

DME, Oxygen, and Equipment Status  
Updated: 12:25 PM

| Patient | DME/equipment issue |
|---|---|
| Linda Brooks | Oxygen concentrator delivery scheduled "before noon"; DME portal still shows driver en route; portable tank not confirmed in home |
| Miguel Santos | VAC pump in home; canister changed by spouse last night; dressing kit delivery marked complete but contents not verified |
| Ruth Allen | Glucometer in home; daughter says strips are low |
| Darnell Price | Uses walker; no new DME delivery |
| Clara Evans | Dressing supply starter kit not confirmed |
| Wayne Cho | Shower chair ordered but not delivered |
| Naomi Feld | Lab kit at agency office |
| Harold King | No DME issue known |

DME note: A visit depending on oxygen, wound supplies, or lab kit is not ready until the necessary equipment/supplies are confirmed.
