# Scheduler Messages

Scheduler / Coordinator Messages  
Thread: 12:00–12:28 PM

12:00 — Scheduler: Board still shows Linda 1:00, Miguel 1:45, Ruth 2:00. Erin cannot do all three if any visit runs long.

12:05 — Linda daughter: I can meet the nurse after 2. Mom doesn't know gate code and is winded today.

12:08 — DME portal: oxygen delivery driver en route, no delivery confirmation yet.

12:10 — Ruth daughter portal: Mom's glucose was 46 at 3 AM and she was confused. Please call before anyone changes insulin.

12:12 — On-call nurse: Ruth should not be treated as routine LPN teaching until RN/provider triage reviews the hypoglycemia.

12:14 — Miguel spouse: VAC alarmed last night. Box arrived but I don't see the black sponge.

12:16 — Supply coordinator: Ticket line for black foam did not scan. Checking warehouse.

12:18 — RN Erin: I can start one confirmed skilled route at 1:00, but don't send me to a locked gate or missing supplies.

12:20 — Intake: Clara surgeon fax not received yet.

12:22 — Scheduler: Darnell gate code missing; PT Jamal asked for confirmation before driving.

12:24 — Lab coordinator: Naomi INR must be drawn early enough for courier pickup by 4:15.

12:27 — Clinical supervisor: Bring me blocker list by 12:45, not a route that depends on guesses.
