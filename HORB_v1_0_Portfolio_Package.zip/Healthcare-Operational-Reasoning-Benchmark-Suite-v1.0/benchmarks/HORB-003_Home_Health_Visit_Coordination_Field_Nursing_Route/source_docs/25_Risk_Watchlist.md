# Risk Watchlist

Home Health Route Risk Watchlist  
Updated: 12:31 PM

High risk / route pressure:
- Linda: SOC green, but oxygen delivery, gate code, caregiver timing, shortness of breath, and discharge medication mismatch are unresolved.
- Miguel: wound VAC green, but black foam supply, VAC alarm, redness concern, and written order/frequency are unresolved.
- Ruth: LPN teaching green, but severe overnight hypoglycemia with confusion requires RN/provider triage.
- RN Erin: one confirmed skilled route can start at 1:00; route cannot absorb failed access or missing supplies.
- Scheduler/intake: limited pre-1:00 calls.
- Naomi: INR draw has a courier cutoff.

Medium risk:
- Darnell: PT eval could proceed if gate code confirmed.
- Clara: signed surgeon order pending.
- Wayne: caregiver timing/OT delay.
- Harold: unreachable after missed visit.
