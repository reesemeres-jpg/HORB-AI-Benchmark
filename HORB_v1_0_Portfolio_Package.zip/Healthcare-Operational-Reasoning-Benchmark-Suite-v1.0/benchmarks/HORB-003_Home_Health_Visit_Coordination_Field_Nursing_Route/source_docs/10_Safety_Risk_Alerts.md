# Safety Risk Alerts

Home Health Safety Risk Alerts  
Updated: 12:25 PM

| Patient | Alert |
|---|---|
| Linda Brooks | CHF readmission risk; shortness of breath on phone; oxygen delivery uncertain; med discrepancy |
| Miguel Santos | Wound VAC alarm overnight; supply contents uncertain; infection risk if dressing not addressed |
| Ruth Allen | Severe overnight hypoglycemia with confusion; lives alone much of day; old insulin scale still visible |
| Darnell Price | Fall risk; gate code missing |
| Clara Evans | Post-op dressing issue; signed order pending |
| Wayne Cho | Home safety risks; caregiver timing changed |
| Naomi Feld | Time-sensitive INR draw and specimen pickup |
| Harold King | Missed visit and unreachable |

Safety note: Green routine status should be overridden by urgent safety alerts, access barriers, and scope limitations.
