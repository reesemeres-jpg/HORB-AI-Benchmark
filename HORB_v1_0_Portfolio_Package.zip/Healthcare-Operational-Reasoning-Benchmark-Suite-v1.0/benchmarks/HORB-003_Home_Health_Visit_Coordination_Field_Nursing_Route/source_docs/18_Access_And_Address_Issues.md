# Access And Address Issues

Access, Address, and Safety Logistics  
Updated: 12:27 PM

| Patient | Access issue |
|---|---|
| Linda Brooks | Gated community; gate code missing; daughter can provide code after 2:00; patient may not know code |
| Miguel Santos | Home access confirmed; spouse present |
| Ruth Allen | Patient sometimes does not answer phone; daughter not physically present until around 5:00 |
| Darnell Price | Apartment gate code missing; voicemail left |
| Clara Evans | Access confirmed after 3:00 |
| Wayne Cho | Caregiver requested after 4:00 |
| Naomi Feld | Access confirmed; patient leaves for dialysis pickup at 4:30 |
| Harold King | No answer; prior missed visit |

Access note: Failed access attempts can consume the route and delay time-sensitive skilled visits.
