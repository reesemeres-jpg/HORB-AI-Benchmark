# Wound Care Order Notes

Wound Care Order Notes  
Patient: Miguel Santos  
Updated: 12:26 PM

Current signed order in agency chart:
- Negative pressure wound therapy dressing change Monday/Wednesday/Friday
- Black foam
- Continuous suction 125 mmHg
- Notify surgeon for fever, spreading redness, uncontrolled pain, or device malfunction

Newer phone voicemail from surgeon office:
- "Please change daily for next 3 days if drainage continues."
- Written order/fax not yet received.
- Surgeon nurse line asks agency to confirm supply availability before visit.

Spouse report:
- VAC alarmed overnight.
- Canister changed by spouse.
- Spouse sees drape and saline in box but does not see black foam.

Order note: Frequency and supply issues should be clarified before field route is finalized.
