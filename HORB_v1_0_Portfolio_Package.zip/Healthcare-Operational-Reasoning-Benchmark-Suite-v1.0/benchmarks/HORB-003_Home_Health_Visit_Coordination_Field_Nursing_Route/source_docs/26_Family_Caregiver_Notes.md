# Family Caregiver Notes

Family and Caregiver Communication Notes  
Updated: 12:28 PM

**Linda Brooks**  
Daughter is worried about shortness of breath but cannot meet nurse until after 2:00. Daughter can provide gate code once available. Patient may not answer door quickly.

**Miguel Santos**  
Spouse is present all afternoon and wants wound VAC checked. Spouse is anxious because alarm sounded overnight and does not understand supply contents.

**Ruth Allen**  
Daughter is worried old insulin instructions will be reinforced. Daughter will be at work until late afternoon and wants a nurse/provider call.

**Darnell Price**  
No family contact listed; patient confirmed yesterday but not today.

**Naomi Feld**  
Patient wants lab draw before dialysis pickup.

Communication note: Caregiver anxiety and availability matter, but they do not replace order, supply, access, or scope requirements.
