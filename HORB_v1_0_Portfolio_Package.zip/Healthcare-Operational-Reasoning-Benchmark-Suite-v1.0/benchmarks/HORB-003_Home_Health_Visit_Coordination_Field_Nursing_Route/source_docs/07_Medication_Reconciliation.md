# Medication Reconciliation

Medication Reconciliation Queue  
Updated: 12:25 PM

| Patient | Medication issue |
|---|---|
| Linda Brooks | Hospital discharge list says furosemide 80 mg AM / 40 mg PM; old home med list says 40 mg daily; new metoprolol added; potassium supplement unclear |
| Ruth Allen | Old insulin scale remains in agency chart; daughter reports overnight hypoglycemia; endocrinology after-hours note not imported |
| Miguel Santos | Antibiotics changed at hospital follow-up yesterday; spouse unsure if picked up |
| Clara Evans | Pain med refill pending; no signed dressing order |
| Naomi Feld | Warfarin dose depends on today's INR |
| Darnell Price | No urgent med rec issue in PT referral |
| Wayne Cho | No active medication task |
| Harold King | Medication status unknown due missed visit |

Medication note: A routine teaching or SOC visit can become unsafe if the field clinician is sent without the latest medication plan or triage instructions.
