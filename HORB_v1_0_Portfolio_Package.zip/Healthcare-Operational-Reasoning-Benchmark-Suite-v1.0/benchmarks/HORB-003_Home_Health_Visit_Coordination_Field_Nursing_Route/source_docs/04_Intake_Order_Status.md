# Intake Order Status

Intake and Orders Status  
Updated: 12:24 PM

| Patient | Order/document status |
|---|---|
| Linda Brooks | Home health SOC order signed; noon discharge packet has revised med list; physician face-to-face present; DME oxygen order separate |
| Miguel Santos | Wound VAC order active; frequency says M/W/F; surgeon office voicemail says "daily for next 3 days" but written order not received |
| Ruth Allen | Nursing med teaching order active; hypoglycemia protocol not updated in plan of care |
| Darnell Price | PT eval order active; fall-risk note present |
| Clara Evans | Surgeon requested dressing check; signed order not yet in chart |
| Wayne Cho | OT order active |
| Naomi Feld | Lab order active; specimen pickup cutoff 4:15 |
| Harold King | Reschedule request active; no current skilled update |

Intake note: Verbal messages, scheduling notes, and old orders should be reconciled before field staff are sent for skilled work that depends on order details.
