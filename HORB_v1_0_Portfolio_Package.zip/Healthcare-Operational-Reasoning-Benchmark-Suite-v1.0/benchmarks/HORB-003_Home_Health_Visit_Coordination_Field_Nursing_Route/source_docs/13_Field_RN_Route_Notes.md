# Field RN Route Notes

Field RN Erin Route Notes  
Updated: 12:27 PM

Planned route from morning board:
1. Linda Brooks SOC — 1:00
2. Miguel Santos wound VAC — 1:45
3. Clara Evans dressing — 3:15
4. Naomi Feld INR draw — 4:00

RN Erin note:
- I can handle one start-of-care or complex wound visit first, not both back-to-back if there are missing supplies or med issues.
- I need gate/access confirmed before leaving.
- I cannot complete a SOC med reconciliation safely if the discharge med list is still changing.
- I can pick up Naomi's lab kit if the route still allows courier cutoff.
- If Miguel has missing black foam, tell me before I leave so I can bring the right supply or not waste the visit.
