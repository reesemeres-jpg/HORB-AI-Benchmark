# General Operational Notices

General Home Health Operations Notices

- A scheduled visit can remain green even after new triage or supply information arrives.
- A patient can be authorized for care but not ready for a field route.
- DME delivery portals may lag actual home availability.
- Supply delivery complete does not prove the correct item is present in the home.
- Caregiver availability can determine whether a complex SOC is feasible.
- Severe hypoglycemia should not be handled as routine teaching from an old medication scale.
- A wound VAC alarm plus missing foam concern should be clarified before dispatch.
- Failed gate/access attempts can break the rest of the route.
- Lab courier cutoffs must be considered when rearranging nursing visits.
- The safest route may be to hold the field nurse until the first visit's gates are actually closed.
