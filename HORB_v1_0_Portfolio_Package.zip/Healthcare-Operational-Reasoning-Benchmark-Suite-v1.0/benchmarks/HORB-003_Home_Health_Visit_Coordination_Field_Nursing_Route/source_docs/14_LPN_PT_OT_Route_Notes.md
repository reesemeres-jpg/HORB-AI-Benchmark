# LPN PT OT Route Notes

LPN / PT / OT Route Notes  
Updated: 12:27 PM

**LPN Tara**  
Scheduled for Ruth insulin teaching at 2:00. Tara can reinforce an approved plan but should not independently triage severe hypoglycemia, change insulin doses, or teach from a possibly outdated scale.

**PT Jamal**  
Scheduled for Darnell at 2:30. Needs gate code confirmed before driving. If no access code, he can swap to documentation work until patient confirms.

**OT Mira**  
Wayne caregiver requested late afternoon. Mira reports car trouble; next update 1:15. Visit may need reschedule if caregiver cannot meet and Mira is delayed.

**Office scheduler**  
Can call Ruth daughter, Darnell, and Linda daughter, but not all simultaneously.

Route note: Discipline-specific scope matters when a scheduled "routine" visit changes into urgent triage.
