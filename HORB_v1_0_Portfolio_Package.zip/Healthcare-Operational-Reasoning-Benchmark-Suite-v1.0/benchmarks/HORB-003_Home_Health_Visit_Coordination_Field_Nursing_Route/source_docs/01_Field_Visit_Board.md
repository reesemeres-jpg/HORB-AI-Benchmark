# Field Visit Board

Home Health Field Visit Board  
Generated: 12:22 PM  
Display source: agency scheduling board

| Patient | Visit type | Assigned staff | Visible time | Board status |
|---|---|---|---:|---|
| Linda Brooks | Start of care after CHF admission | RN Erin | 1:00 PM | Green |
| Miguel Santos | Wound VAC dressing change | RN Erin | 1:45 PM | Green |
| Ruth Allen | Insulin teaching / med check | LPN Tara | 2:00 PM | Green |
| Darnell Price | PT evaluation | PT Jamal | 2:30 PM | Green |
| Clara Evans | Post-op dressing check | RN Erin | 3:15 PM | Yellow |
| Wayne Cho | Home safety follow-up | OT Mira | 3:30 PM | Yellow |
| Naomi Feld | Lab draw | RN Erin | 4:00 PM | Yellow |
| Harold King | Missed visit reschedule | Unassigned | Hold | Yellow |

Incoming calls / new alerts:
| Source | Patient | Note |
|---|---|---|
| Hospital discharge desk | Linda Brooks | Discharge packet updated at noon |
| Supply vendor | Miguel Santos | Delivery marked complete |
| Daughter portal | Ruth Allen | Reports low blood sugar episode overnight |
| Intake desk | Clara Evans | Surgeon office fax pending |

Board note: Green status reflects scheduling-board readiness only. It may not reflect updated discharge packets, DME delivery, supply completeness, caregiver availability, patient contact, medication reconciliation, or field-staff scope.
