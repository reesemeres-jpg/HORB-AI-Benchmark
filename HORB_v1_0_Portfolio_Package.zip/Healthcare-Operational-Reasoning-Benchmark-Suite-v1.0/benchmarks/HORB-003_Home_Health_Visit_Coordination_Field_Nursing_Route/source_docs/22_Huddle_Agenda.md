# Huddle Agenda

Home Health Route Huddle Agenda  
Scheduled: 12:45 PM

Requested decisions:
- Is there a defensible first field route at 1:00?
- Can Linda SOC proceed first, or do access, oxygen delivery, caregiver timing, and med reconciliation block the route?
- Can Miguel wound VAC proceed first, or do missing black foam and updated order/frequency questions block the route?
- Can Ruth remain an LPN teaching visit, or does overnight hypoglycemia require RN/provider triage first?
- How should Erin's single RN route be protected?
- Can Darnell PT eval proceed if gate code is still missing?
- Should Naomi lab draw be moved earlier to protect courier cutoff?
- Which patient/caregiver calls should scheduler make before 1:00?
- What can be safely deferred or rescheduled with documentation?
- What should be told to Linda's daughter, Miguel's spouse, and Ruth's daughter without overpromising?

Huddle note: Bring current blockers and owners. Do not rely on green route-board status alone.
