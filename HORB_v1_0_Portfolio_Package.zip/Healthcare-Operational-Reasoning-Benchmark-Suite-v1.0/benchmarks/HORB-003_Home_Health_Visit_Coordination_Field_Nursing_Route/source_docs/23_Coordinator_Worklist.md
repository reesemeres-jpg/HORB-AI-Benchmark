# Coordinator Worklist

Home Health Coordinator Worklist  
Generated: 12:30 PM

- Reconcile field board with newer discharge packet, DME status, supply ticket, contact log, and triage messages.
- Call DME vendor for Linda oxygen delivery confirmation.
- Call Linda daughter for gate code and earliest caregiver availability.
- Ask RN supervisor whether Linda SOC can be delayed until after 2 if DME/access not resolved.
- Ask supply coordinator to verify Miguel black foam and whether replacement can be sent with RN.
- Ask surgeon office for Miguel written order/frequency confirmation.
- Escalate Ruth hypoglycemia message to RN supervisor/provider before LPN visit.
- Ask scheduler to reach Ruth daughter for current glucose/status and safety plan.
- Confirm Darnell gate code before PT leaves.
- Confirm Naomi lab kit/courier timing and whether RN route can still preserve pickup.
- Hold Clara until signed order arrives.
- Prepare huddle brief with one possible route or clear no-route explanation.
- Update field board only after access/supply/order/scope gates close.
