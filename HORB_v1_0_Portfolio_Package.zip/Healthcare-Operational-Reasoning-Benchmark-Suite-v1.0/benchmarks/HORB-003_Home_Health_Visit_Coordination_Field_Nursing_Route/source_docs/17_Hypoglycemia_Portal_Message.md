# Hypoglycemia Portal Message

Patient Portal Message  
Patient: Ruth Allen  
Timestamp: 12:10 PM  
Sender: Daughter

Message:
"Mom's sugar was 46 around 3 AM. She was confused and sweaty. I gave juice and crackers and it came up to 92 after a while. The nurse visit says insulin teaching today, but I don't want anyone telling her to keep the same dose until someone checks. She lives alone during the day and she doesn't always answer the phone."

Chart note:
- Agency medication list still shows old sliding-scale insulin.
- Last endocrinology note is not imported.
- Daughter is available by phone intermittently and will be at the home around 5 PM.

Portal note: This message arrived after the routine LPN visit was scheduled.
