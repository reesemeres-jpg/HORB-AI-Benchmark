# Patient Readiness Summary

Patient Readiness Summary  
Updated: 12:26 PM

| Patient | Current operational/clinical status |
|---|---|
| Linda Brooks | Discharged yesterday after CHF exacerbation; SOC scheduled; updated discharge packet received at noon; oxygen delivery and medication list mismatch unresolved; daughter available after 2:00 |
| Miguel Santos | Wound VAC change due today; supply vendor marked delivery complete; spouse reports box arrived but black foam not seen; VAC alarmed overnight |
| Ruth Allen | Insulin teaching visit scheduled with LPN; daughter reports glucose 46 at 3 AM with confusion; current med list still shows old insulin scale |
| Darnell Price | PT eval after fall; patient confirmed yesterday; apartment gate code missing from route note |
| Clara Evans | Post-op dressing check requested by surgeon; agency order fax pending |
| Wayne Cho | OT safety follow-up; caregiver cancelled morning slot and asked for late afternoon |
| Naomi Feld | Lab draw for INR; patient has dialysis pickup at 4:30 |
| Harold King | Missed visit yesterday; no answer today |

Status note: Earlier scheduled status may not reflect newer triage calls, caregiver timing, supply issues, access problems, or order requirements.
