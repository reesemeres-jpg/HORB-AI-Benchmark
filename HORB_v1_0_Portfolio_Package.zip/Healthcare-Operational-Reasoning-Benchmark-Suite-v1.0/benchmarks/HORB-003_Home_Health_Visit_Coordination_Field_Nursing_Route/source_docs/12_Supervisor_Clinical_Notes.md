# Supervisor Clinical Notes

Clinical Supervisor Notes  
Updated: 12:28 PM

**Linda Brooks**  
SOC is appropriate today if access, oxygen delivery, and discharge medication reconciliation can be clarified. Do not send RN into a first visit without a workable med list and oxygen status, because the visit may require urgent escalation.

**Miguel Santos**  
VAC issue is important, but RN needs correct dressing supplies and current written order/frequency. If black foam is missing, determine whether a replacement can be delivered or whether provider wants alternate plan.

**Ruth Allen**  
Overnight glucose 46 with confusion is not routine teaching. RN triage/provider notification should occur before LPN visit. Do not let old insulin scale drive the teaching.

**Naomi Feld**  
INR draw is time sensitive, but lower acuity if staffing can support it later and courier cutoff is preserved.

Supervisor note: Prioritize safety and route feasibility. Do not convert a green scheduled visit into a field route until access/supplies/orders/scope are confirmed.
