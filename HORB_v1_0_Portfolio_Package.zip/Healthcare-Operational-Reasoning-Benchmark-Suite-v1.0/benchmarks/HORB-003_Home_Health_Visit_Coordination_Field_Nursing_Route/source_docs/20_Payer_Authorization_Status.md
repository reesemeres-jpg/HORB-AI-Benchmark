# Payer Authorization Status

Payer / Authorization Status  
Updated: 12:20 PM

| Patient | Authorization note |
|---|---|
| Linda Brooks | SOC authorized; must occur within ordered window unless rescheduled with reason |
| Miguel Santos | Skilled wound care authorized; supply billing tied to documented dressing kit use |
| Ruth Allen | Skilled nursing teaching authorized; urgent RN triage not separately pre-authorized but clinically allowed |
| Darnell Price | PT evaluation authorized |
| Clara Evans | Pending signed surgeon order; payer authorization not complete |
| Wayne Cho | OT authorized |
| Naomi Feld | Lab draw covered under active plan |
| Harold King | Missed visit reschedule covered if patient reached |

Authorization note: A visit can be authorized yet still not operationally ready due access, supply, order, or safety issues.
