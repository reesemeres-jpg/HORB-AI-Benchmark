# Supply Ticket Status

Home Health Supply Ticket Status  
Updated: 12:26 PM

| Patient | Supply status |
|---|---|
| Miguel Santos | Delivery ticket says "VAC dressing kit delivered"; itemized list shows drape, canister, saline, gauze; black foam line not scanned |
| Clara Evans | Starter dressing kit requested; supply room says not pulled |
| Naomi Feld | INR lab kit ready at office |
| Linda Brooks | Scale not delivered; oxygen handled by DME vendor |
| Ruth Allen | Glucose strips not provided by agency supply; family pharmacy issue |
| Wayne Cho | OT safety checklist in route packet |
| Darnell Price | PT eval packet ready |
| Harold King | No supply packet prepared |

Supply note: A delivery-complete status may not mean the correct procedure-specific item is present in the home.
