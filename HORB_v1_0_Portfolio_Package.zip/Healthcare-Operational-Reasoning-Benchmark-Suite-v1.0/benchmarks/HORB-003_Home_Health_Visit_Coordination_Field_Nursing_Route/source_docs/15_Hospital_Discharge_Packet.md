# Hospital Discharge Packet

Hospital Discharge Packet Update  
Patient: Linda Brooks  
Received: 12:00 PM

Discharge diagnosis:
- CHF exacerbation
- Hypoxia requiring home oxygen evaluation
- Medication adjustment after diuresis

Discharge medication list:
- Furosemide 80 mg every morning and 40 mg every evening
- Metoprolol succinate 25 mg daily
- Lisinopril 10 mg daily
- Potassium chloride: "continue if instructed by PCP" noted without dose
- Old home medication list still shows furosemide 40 mg daily

Home instructions:
- Daily weight
- Low-salt diet
- Use oxygen as directed
- Follow up with cardiology within 7 days

Discharge desk note:
DME oxygen order was sent to vendor separately. Delivery confirmation not included in this packet.
