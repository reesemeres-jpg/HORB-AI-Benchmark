# Route Map Constraints

Route Geography and Timing  
Updated: 12:25 PM

| Route | Typical drive time | Current note |
|---|---:|---|
| Agency office to Linda | 22 min | Gate code missing; daughter not available until after 2:00 |
| Linda to Miguel | 18 min | Possible if Linda visit starts on time |
| Agency office to Miguel | 25 min | Home access confirmed |
| Miguel to Ruth | 30 min | Rural route; poor cell reception |
| Agency office to Ruth | 35 min | Patient lives alone; phone unanswered |
| Agency office to Darnell | 20 min | Gate code missing |
| Agency office to Clara | 28 min | After 3:00 only; order pending |
| Agency office to Naomi | 18 min | Lab specimen pickup cutoff 4:15 |
| Agency office to Harold | 32 min | No answer |

Route note: The afternoon route cannot absorb repeated failed access attempts without displacing time-sensitive visits.
