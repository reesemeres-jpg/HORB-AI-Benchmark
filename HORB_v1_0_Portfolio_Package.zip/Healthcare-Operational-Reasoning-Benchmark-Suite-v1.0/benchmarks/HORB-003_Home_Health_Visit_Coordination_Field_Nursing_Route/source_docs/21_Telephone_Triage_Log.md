# Telephone Triage Log

Telephone Triage Log  
Updated: 12:28 PM

**Linda Brooks**  
Patient sounded winded during 10:30 call. No current home pulse ox reading. Daughter says patient is resting and does not want ED unless necessary. Oxygen delivery uncertain.

**Miguel Santos**  
Spouse reports VAC alarm overnight and canister change. No current fever measured. Wound area "more red than yesterday" per spouse, but spouse is unsure.

**Ruth Allen**  
Portal message indicates severe hypoglycemia with confusion. No successful phone contact yet after message.

**Naomi Feld**  
No symptoms reported. INR draw needed today.

**Clara Evans**  
Reports mild drainage at dressing but no fever. Signed order pending.

Triage note: Calls with safety changes should be reviewed before being treated as routine scheduled visits.
