# Home Health Flow Policy

Home Health Visit Coordination Workflow

1. Scheduling-board green status is a starting point, not final field-route release.
2. Start-of-care visits require patient access, current discharge documents, medication reconciliation readiness, DME status, and appropriate skilled RN assignment.
3. Wound VAC visits require correct supplies, current order/frequency, home access, and field clinician scope.
4. Routine teaching visits should be re-triaged when a new urgent safety message arrives.
5. LPN visits must stay within scope and should not substitute for RN/provider triage when unstable symptoms or unsafe medication changes are reported.
6. Time-sensitive labs require route timing that preserves specimen pickup.
7. Field staff should not be sent into known failed-access or missing-supply visits without a documented plan.
8. Route changes should be communicated to patients/caregivers without promising times before gates close.

Operational reminder: A wasted field visit can delay urgent care for another homebound patient.
