# Field Staffing Status

Field Staffing and Capacity View  
Updated: 12:25 PM

| Staff member | Role | Current status |
|---|---|---|
| RN Erin | Field RN | Available for one confirmed skilled RN route starting at 1:00; must return for 3:45 agency meeting |
| LPN Tara | Field LPN | Can do routine med checks and teaching; cannot open start-of-care or resolve unstable triage alone |
| PT Jamal | Physical therapist | Available for Darnell at 2:30 if patient confirms |
| OT Mira | Occupational therapist | Afternoon route delayed by car trouble; next update 1:15 |
| Weekend RN pool | Backup | No coverage confirmed before 3:00 |
| Clinical supervisor | RN supervisor | Available by phone until 12:55, then in IDT meeting |
| Intake coordinator | Office | Can make two document/DME calls before 1:00 |
| Scheduler | Office | Can call one patient/caregiver at a time |
| Supply coordinator | Office | Checking wound supply ticket |
| On-call nurse | Phone triage | Covers urgent calls until 1:00 only |

Staffing note: The coordinator can complete one direct call or routing decision at a time. A scheduled field visit is not actionable without patient access, correct supplies/orders, staff scope, and a safe route plan.
