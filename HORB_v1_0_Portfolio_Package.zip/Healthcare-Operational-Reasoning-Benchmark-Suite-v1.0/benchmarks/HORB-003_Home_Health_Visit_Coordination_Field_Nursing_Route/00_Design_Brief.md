# HORB-003: Home Health Visit Coordination / Field Nursing Route

**Suite:** Healthcare Operational Reasoning Benchmark Suite  
**Version:** 1.0  
**Author:** Meredith Reese, RN  
**Original File Mapping:** Submission 021

> Evaluating operational reasoning under uncertainty in home health operations.

## Clinical Domain

Home Health Operations

## Operational Setting

Home health agency field-visit routing and coordination window

## Operational Window

12:30 PM to 12:45 PM before the Home health route huddle.

## Primary Capability Evaluated

Field-route operational reasoning under uncertainty.

## Purpose

Evaluates whether an AI system can coordinate home health visit routing while balancing start-of-care readiness, wound VAC supply and order issues, urgent medication-safety messages, field nurse and LPN scope, access problems, caregiver availability, DME delivery, time-sensitive labs, route geography, and limited office-call capacity.

## Primary Evaluation Question

> **Can the model distinguish apparent readiness from executable readiness while producing an operationally realistic plan for this workflow?**

## Capability Profile

| Capability | Evaluated |
|---|:---:|
| Multi-document reasoning | ✓ |
| Operational prioritization | ✓ |
| Temporal reasoning | ✓ |
| Workflow coordination | ✓ |
| Resource allocation | ✓ |
| Ownership boundaries | ✓ |
| Source provenance | ✓ |
| Uncertainty management | ✓ |


## Operational Actors

- Clinical coordinator
- Field RN
- LPN
- Scheduler
- Supervisor
- Patient / caregiver
- DME provider
- Hospital discharge team
- Supply team


## Reasoning Challenges

- Start-of-care readiness
- Wound VAC supply and order status
- Medication safety concerns
- Clinician scope limits
- Patient access and caregiver availability
- DME/oxygen delivery
- Route geography
- Limited office-call capacity


## Typical Failure Modes

- Dispatching a nurse before access or orders are confirmed
- Assigning work outside clinician scope
- Treating scheduled visit as visit-ready
- Ignoring DME or supply dependencies
- Prioritizing geography over clinical/operational risk
- Assuming caregiver availability from old notes


## Expected High-Quality Response

A strong response should:

- Integrate information across multiple documents.
- Distinguish confirmed information from apparent readiness.
- Respect ownership boundaries and role authority.
- Recognize unresolved dependencies.
- Prioritize realistically under time and resource constraints.
- Recommend only operationally executable actions.
- Carry unresolved issues forward to the appropriate huddle or owner.

## Included Materials

- `UseCase_System_Prompt.md`
- `Strict_Grading_Guidelines.md`
- `source_docs/` (28 fictional operational documents)
- `SourceDocs.zip`
- `original_batches/`

## Estimated Difficulty

**Expert**

## Estimated Human Evaluation Time

Approximately **30–45 minutes**.

## Design Notes

This benchmark was designed to evaluate operational judgment rather than factual recall. It presents multiple operationally plausible actions and requires prioritization based on safety, workflow constraints, source provenance, and confirmed operational readiness. The benchmark fits the suite's core design principle: operational readiness cannot be inferred from apparent readiness.

## Keywords

Home health • field nursing • route coordination • start of care • visit readiness • AI evaluation • benchmark design • healthcare operations
