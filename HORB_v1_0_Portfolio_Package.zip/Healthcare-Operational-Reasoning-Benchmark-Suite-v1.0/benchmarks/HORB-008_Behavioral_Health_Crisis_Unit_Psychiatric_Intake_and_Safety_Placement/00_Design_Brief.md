# HORB-008: Behavioral Health Crisis Unit / Psychiatric Intake & Safety Placement

**Suite:** Healthcare Operational Reasoning Benchmark Suite  
**Version:** 1.0  
**Author:** Meredith Reese, RN  
**Original File Mapping:** Submission 026

> Evaluating operational reasoning under uncertainty in behavioral health operations.

## Clinical Domain

Behavioral Health Operations

## Operational Setting

Behavioral health crisis unit intake and placement window

## Operational Window

7:14 PM to 7:30 PM before the Behavioral health placement huddle.

## Primary Capability Evaluated

Psychiatric intake placement reasoning with safety, legal, and staffing constraints.

## Purpose

Evaluates whether an AI system can coordinate behavioral health intake and placement while balancing legal status, medical clearance, contraband/security search, observation level, sitter coverage, room safety, unit acceptance, transportation, and evolving patient behavior.

## Primary Evaluation Question

> **Can the model distinguish apparent readiness from executable readiness while producing an operationally realistic plan for this workflow?**

## Capability Profile

| Capability | Evaluated |
|---|:---:|
| Multi-document reasoning | ✓ |
| Operational prioritization | ✓ |
| Temporal reasoning | ✓ |
| Workflow coordination | ✓ |
| Resource allocation | ✓ |
| Ownership boundaries | ✓ |
| Source provenance | ✓ |
| Uncertainty management | ✓ |


## Operational Actors

- Behavioral health charge nurse
- Intake clinician
- Psychiatrist / provider
- Security
- ED or referring unit
- Sitter / observer
- Nursing staff
- Transport
- Registration or legal status owner


## Reasoning Challenges

- Legal and voluntary/involuntary status
- Medical clearance
- Security and contraband search
- Observation level requirements
- Room safety and staffing
- Evolving behavior and risk
- Unit acceptance
- Transport timing


## Typical Failure Modes

- Treating calm behavior as placement-ready
- Assuming clean room equals safe placement
- Ignoring legal status or medical clearance
- Underestimating observation staffing
- Premature placement before security search
- Overconfidence from green intake board status


## Expected High-Quality Response

A strong response should:

- Integrate information across multiple documents.
- Distinguish confirmed information from apparent readiness.
- Respect ownership boundaries and role authority.
- Recognize unresolved dependencies.
- Prioritize realistically under time and resource constraints.
- Recommend only operationally executable actions.
- Carry unresolved issues forward to the appropriate huddle or owner.

## Included Materials

- `UseCase_System_Prompt.md`
- `Strict_Grading_Guidelines.md`
- `source_docs/` (28 fictional operational documents)
- `SourceDocs.zip`
- `original_batches/`

## Estimated Difficulty

**Expert**

## Estimated Human Evaluation Time

Approximately **30–45 minutes**.

## Design Notes

This benchmark was designed to evaluate operational judgment rather than factual recall. It presents multiple operationally plausible actions and requires prioritization based on safety, workflow constraints, source provenance, and confirmed operational readiness. The benchmark fits the suite's core design principle: operational readiness cannot be inferred from apparent readiness.

## Keywords

Behavioral health • psychiatric intake • safety placement • crisis unit • operational reasoning • AI evaluation • benchmark design • healthcare operations
