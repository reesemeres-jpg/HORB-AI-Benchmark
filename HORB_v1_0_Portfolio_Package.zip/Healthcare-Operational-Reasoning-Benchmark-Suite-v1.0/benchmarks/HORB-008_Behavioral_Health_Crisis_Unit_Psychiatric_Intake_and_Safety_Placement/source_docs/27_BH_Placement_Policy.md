# BH Placement Policy

Behavioral Health Placement and Safety Workflow

1. Placement-board color is a starting point, not final placement release.
2. Psychiatric placement requires medical clearance when ED has an active hold or pending ingestion/tox concern.
3. Transfer to inpatient behavioral health requires legal status, search checklist, observation handoff, receiving RN acceptance, and unit acuity fit.
4. Crisis-room placement requires safety sweep, belongings/body-search process, observation level, and security/sitter plan when relevant.
5. Detox placement requires current withdrawal score/vitals, nurse acceptance, medication readiness, and seizure precaution setup.
6. Adolescent placements require guardian/consent pathway and age-appropriate observation resources.
7. Observation resources should not be pulled from high-risk patients without replacement.
8. Charge RN should prepare a placement-gate brief rather than launching several tentative moves.

Operational reminder: Moving a patient into an unready behavioral health space can increase elopement, contraband, withdrawal, or safety risk.
