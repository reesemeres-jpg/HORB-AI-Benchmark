# ED BH Messages

ED / Behavioral Health Messages  
Thread: 7:00–7:12 PM

7:00 — ED Provider: Tara cannot leave ED side until acetaminophen level is resulted and reviewed.

7:02 — Crisis RN A: Tara calm and wants admission, but body search checklist is not complete.

7:03 — BHU Charge: BHU-12 clean. We still need receiving RN assignment and search paperwork before arrival.

7:04 — Security: Malik is calmer, but I am staying nearby. His backpack had lighter; inventory not signed.

7:05 — Crisis Clinician: Malik hold packet started, physician signature pending.

7:06 — ED RN: Renee CIWA now 13, tremors worse. Need detox nurse acceptance and vitals recheck.

7:07 — Detox RN: I am in med pass until 7:30. Detox Room 4 needs seizure pad setup.

7:08 — Crisis RN B: Amara still high observation after restraint; cannot pull her tech.

7:09 — Police entrance: Agitated adult incoming around 7:25.

7:10 — Charge RN: Bring me placement blockers, not just clean-room list, for 7:30 huddle.

7:11 — Crisis Clinician: Greg may be ready for eval soon; I am still finishing his note.

7:12 — Intake: Lila voluntary mobile crisis arrival estimated 7:35.
