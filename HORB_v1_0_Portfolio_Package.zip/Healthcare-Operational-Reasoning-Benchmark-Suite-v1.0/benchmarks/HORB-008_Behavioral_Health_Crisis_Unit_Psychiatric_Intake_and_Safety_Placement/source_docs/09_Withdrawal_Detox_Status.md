# Withdrawal Detox Status

Withdrawal / Detox Readiness  
Updated: 7:10 PM

| Patient | Withdrawal/detox issue |
|---|---|
| Renee Silva | Last drink this morning; tremor/nausea; CIWA rose from 8 to 13; recheck due; detox nurse not available until 7:30 |
| Malik Johnson | Possible stimulant use; tox pending; no alcohol withdrawal signs |
| Tara Blake | No withdrawal issue; ingestion/lab hold |
| Greg Hall | No withdrawal issue |
| Amara Reed | No withdrawal issue |
| Detox Room 4 | Clean but seizure pads and detox medication cart check not complete |
| Detox RN | Medication pass until 7:30 |
| Provider | Wants current vitals before detox acceptance |

Detox note: A clean detox room is not ready if withdrawal monitoring, seizure precautions, medication setup, and nurse assignment are incomplete.
