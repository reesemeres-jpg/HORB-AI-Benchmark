# Incoming Pressure Log

Incoming Patient / Census Pressure Log  
Updated: 7:12 PM

7:00 — Unit supervisor asks for one ED-to-BHU move before 7:45 if safe.  
7:05 — ED asks whether crisis can take Malik to free Hall B.  
7:09 — Police reports agitated adult incoming around 7:25.  
7:10 — Mobile crisis confirms Lila voluntary arrival around 7:35.  
7:11 — ED provider says Greg may be medically cleared soon.  
7:12 — Adolescent consult need for Bethany still waiting.  
7:12 — Detox nurse unavailable until 7:30.  
7:12 — BHU receiving RN not available until 7:25.

Pressure note: Census pressure should not bypass clearance, safety, or staffing gates.
