# Risk Watchlist

Behavioral Health Placement Risk Watchlist  
Updated: 7:14 PM

High risk / placement pressure:
- Tara: green BHU move but medical ingestion hold, body search, receiving RN assignment, and observation handoff unresolved.
- Malik: green crisis-room move but hold signature, contraband/search, room sweep, and security escort unresolved.
- Renee: green detox move but rising CIWA, vitals recheck, detox nurse, seizure setup, and capacity status unresolved.
- Amara: post-restraint high observation limits BH tech availability.
- Police incoming adult: may need security and safe space quickly.
- Bethany: adolescent self-harm, peds-trained sitter unavailable.
- BHU receiving RN and detox RN: both unavailable until around 7:25–7:30.

Medium risk:
- Jonah: likely discharge but provider safety-plan review pending.
- Greg: medical clearance note pending, clinician tied up.
- Lila: voluntary incoming assessment.
- Crisis Room 5: dirty and unavailable.
