# Staffing Sitter Security

Behavioral Health Staffing, Sitter, and Security View  
Posted: 7:08 PM

| Role | Assignment |
|---|---|
| Crisis charge RN | Placement flow, safety assignments, 7:30 huddle |
| Crisis RN A | Tara and Jonah |
| Crisis RN B | Amara high observation |
| Crisis RN C | Renee if detox room opens |
| BHU receiving RN | On break until 7:25; can accept one admission after report if assignment confirmed |
| Detox RN | Covering medication pass; available after 7:30 |
| Behavioral health tech 1 | Constant observation for Tara |
| Behavioral health tech 2 | With Amara post-restraint |
| Security officer 1 | ED Hall B with Malik |
| Security officer 2 | Ambulance/police entrance until 7:25 |
| Peds-trained sitter | Not available until 8:00 |
| Crisis clinician | Finishing Greg eval, then Bethany or Lila |

Staffing note: The charge RN can complete one direct call or placement decision at a time. A clean space is not enough without sitter/security/staffing fit.
