# BH Placement Board

Behavioral Health Crisis / Placement Board  
Generated: 7:07 PM  
Display source: crisis placement board

| Location / queue | Patient | Presenting concern | Visible next step | Board color |
|---|---|---|---|---|
| ED Safe Room 2 | Tara Blake | Suicidal ideation / overdose concern | Admit BHU-12 | Green |
| ED Hall B | Malik Johnson | Agitation / threats | Crisis Room 3 | Green |
| Medical ED 18 | Renee Silva | Alcohol withdrawal / depression | Detox Room 4 | Green |
| Crisis Chair 1 | Jonah Pierce | Anxiety / panic | Discharge plan | Yellow |
| Crisis Room 1 | Amara Reed | Post-restraint observation | Continue crisis unit | Red |
| Waiting Area | Bethany Cruz | Adolescent self-harm | Peds BH consult | Yellow |
| BHU-12 | Empty | Clean adult bed | Available | Green |
| Detox Room 4 | Empty | Clean | Available | Green |

Incoming / pressure:
| Source | Patient | Note | ETA |
|---|---|---|---|
| Police | Unknown adult | Agitated, possible stimulant use | 7:25 |
| ED provider | Greg Hall | Medically cleared psych eval pending | Ready soon |
| Mobile crisis | Lila Tran | Voluntary depression assessment | 7:35 |
| Unit supervisor | BHU census pressure | Wants one ED patient moved before 7:45 |

Board note: Green reflects visible placement-board status only. It may not reflect medical clearance, toxicology/lab holds, legal status, sitter/security coverage, contraband search, withdrawal risk, room gender/acuity fit, or receiving-unit acceptance.
