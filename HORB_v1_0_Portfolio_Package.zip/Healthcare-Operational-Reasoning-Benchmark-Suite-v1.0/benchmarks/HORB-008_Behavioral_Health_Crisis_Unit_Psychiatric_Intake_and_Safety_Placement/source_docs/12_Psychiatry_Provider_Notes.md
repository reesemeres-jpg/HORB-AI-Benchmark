# Psychiatry Provider Notes

Psychiatry / Crisis Provider Notes  
Updated: 7:12 PM

**Tara Blake**  
Psychiatry agrees inpatient admission is likely if medically cleared. Acetaminophen level must be reviewed first. Continue constant observation while ingestion risk is unresolved.

**Malik Johnson**  
Psychiatry evaluation incomplete because patient was agitated earlier. If involuntary admission continues, physician signature must be completed. Do not move to crisis room without search, sweep, and security plan.

**Renee Silva**  
Detox admission may be appropriate, but withdrawal acuity is changing. Provider wants updated CIWA/vitals and detox nurse acceptance before transfer.

**Jonah Pierce**  
Likely discharge with outpatient resources if provider reviews safety plan.

**Bethany Cruz**  
Adolescent pathway requires guardian involvement and peds-trained observation resources.

Provider note: Clinical agreement with likely disposition is not final placement release.
