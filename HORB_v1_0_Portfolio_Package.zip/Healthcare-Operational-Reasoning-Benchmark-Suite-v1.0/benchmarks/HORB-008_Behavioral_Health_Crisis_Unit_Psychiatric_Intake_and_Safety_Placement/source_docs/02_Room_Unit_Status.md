# Room Unit Status

Behavioral Health Room and Unit Status  
Updated: 7:09 PM

| Space | Status | Comment |
|---|---|---|
| BHU-12 | Clean | Adult bed; receiving RN assignment not finalized |
| BHU-14 | Occupied | High-observation patient, not expected to transfer |
| Detox Room 4 | Clean | Requires withdrawal nurse assignment and seizure precautions setup |
| Crisis Room 3 | Clean | Ligature sweep not documented after prior use |
| Crisis Room 5 | Dirty | EVS requested after medical spill |
| ED Safe Room 2 | Occupied by Tara | Constant observation |
| ED Hall B | Malik on security watch | Not ligature-safe |
| Crisis Chair 1 | Jonah | Low-acuity chair |
| Adolescent consult room | Clean | Requires peds-trained sitter if occupied |
| Seclusion Room | Available | Post-use check incomplete; not a routine placement bed |

Room note: A clean room or bed still needs safety sweep, observation level, receiving staff, legal/medical clearance, and acuity fit.
