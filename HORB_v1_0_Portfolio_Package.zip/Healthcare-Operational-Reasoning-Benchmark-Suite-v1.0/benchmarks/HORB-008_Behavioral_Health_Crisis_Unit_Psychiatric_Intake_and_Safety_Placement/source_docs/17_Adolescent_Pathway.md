# Adolescent Pathway

Adolescent Behavioral Health Pathway  
Updated: 7:11 PM

**Bethany Cruz**  
- Age 15.
- Parent present and cooperative.
- Superficial self-harm cleaned.
- No peds-trained sitter until 8:00.
- Crisis clinician has not started adolescent assessment.
- Adolescent consult room is clean.
- Guardian consent required for any voluntary admission or discharge safety plan.
- Adult crisis rooms should not be used unless leadership approves emergency overflow.

Pathway note: A clean room does not make an adolescent placement ready if required staffing and consent pathway are not in place.
