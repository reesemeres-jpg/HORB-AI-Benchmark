# Observation Level Status

Observation Level and Safety Monitoring  
Updated: 7:10 PM

| Patient | Current observation level |
|---|---|
| Tara Blake | Constant observation in ED Safe Room 2 due suicidal ideation and ingestion concern |
| Malik Johnson | Security watch due threats and agitation; no sitter assigned |
| Renee Silva | Medical ED nursing observation; withdrawal monitoring needed |
| Jonah Pierce | Routine observation |
| Amara Reed | High observation after restraint; BH tech assigned |
| Bethany Cruz | Parent supervision, but no formal sitter |
| Greg Hall | Routine ED observation |
| Lila Tran | Not arrived |

Observation note: Observation level must follow the patient to any new space unless a qualified owner changes it.
