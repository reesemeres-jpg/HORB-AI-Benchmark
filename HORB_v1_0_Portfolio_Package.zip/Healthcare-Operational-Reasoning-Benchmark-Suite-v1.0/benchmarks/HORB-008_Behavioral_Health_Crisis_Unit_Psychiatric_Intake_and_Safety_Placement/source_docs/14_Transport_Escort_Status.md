# Transport Escort Status

Transport / Escort Status  
Updated: 7:12 PM

| Route | Typical time | Current gate |
|---|---:|---|
| ED Safe Room 2 to BHU-12 / Tara | 6–8 min | Acetaminophen level, body search, receiving RN |
| ED Hall B to Crisis Room 3 / Malik | 4–6 min | Hold signature, sweep, search, security escort |
| Medical ED 18 to Detox Room 4 / Renee | 5–7 min | CIWA/vitals, detox nurse, seizure setup |
| Crisis Chair 1 to discharge / Jonah | 5–10 min | Provider safety-plan review |
| Waiting Area to Adolescent consult room / Bethany | 4–6 min | Peds sitter, guardian consent, clinician availability |
| ED to Crisis eval room / Greg | 4–6 min | Clearance note and clinician availability |
| Police entrance to Crisis area | 4–6 min | Security and safe placement needed |

Available:
- One BH tech transport assist if not pulling from constant observation.
- Security escort limited until 7:25.
- ED transport aide busy with medical admission until 7:35.

Escort note: Patient movement should follow safety/clearance decisions, not create them.
