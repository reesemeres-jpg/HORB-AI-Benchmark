# Legal Status Consent

Legal Status, Consent, and Hold Status  
Updated: 7:09 PM

| Patient | Legal/consent status |
|---|---|
| Tara Blake | Voluntary admission form signed, but medical clearance pending |
| Malik Johnson | Involuntary hold paperwork started by crisis clinician; physician signature missing |
| Renee Silva | Voluntary detox admission requested; capacity not yet documented because withdrawal symptoms increasing |
| Jonah Pierce | Voluntary outpatient discharge plan under review |
| Amara Reed | Emergency detention active; high observation |
| Bethany Cruz | Minor; parent present; guardian consent needed for any admission |
| Greg Hall | Voluntary evaluation |
| Lila Tran | Voluntary mobile crisis referral |

Legal note: A bed assignment or patient agreement does not close legal status, guardian consent, capacity, or physician-signature requirements.
