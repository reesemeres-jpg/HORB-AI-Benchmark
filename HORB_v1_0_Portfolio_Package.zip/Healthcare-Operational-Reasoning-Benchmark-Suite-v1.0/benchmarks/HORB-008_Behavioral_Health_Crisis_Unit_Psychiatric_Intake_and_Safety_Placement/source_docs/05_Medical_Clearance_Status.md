# Medical Clearance Status

Medical Clearance and ED Status  
Updated: 7:10 PM

| Patient | Medical clearance issue |
|---|---|
| Tara Blake | Reported acetaminophen ingestion around 3:30 PM; four-hour acetaminophen level drawn at 7:30 per ED plan, not resulted; ED provider says do not transfer until level reviewed |
| Malik Johnson | Vitals improved after food/fluids; urine tox pending; small forehead abrasion not yet assessed by provider |
| Renee Silva | Withdrawal symptoms increasing; BP 168/94, HR 112; CIWA recheck pending; detox protocols need nurse acceptance |
| Jonah Pierce | Medically cleared earlier; provider discharge review pending |
| Bethany Cruz | Superficial cuts cleaned; no medical hold, but adolescent psych process pending |
| Greg Hall | Labs complete; ED provider drafting clearance note |
| Lila Tran | Not arrived |
| Amara Reed | Medically stable but behavioral observation active |

Medical note: Psychiatric acceptance should not proceed when ED provider has placed a medical/lab hold.
