# Charge RN Worklist

Behavioral Health Charge RN Worklist  
Generated: 7:14 PM

- Reconcile placement board with medical clearance, legal hold, safety search, observation, detox, staffing, and incoming pressure notes.
- Confirm Tara acetaminophen level timing and ED provider review status.
- Ask crisis RN/tech to complete Tara body search checklist only if ED says transfer could become possible.
- Confirm BHU-12 receiving RN assignment and constant-observation handoff requirements.
- Confirm Malik hold physician signature and whether crisis clinician can complete it before placement.
- Hold Malik movement until Crisis Room 3 sweep, clothing search, inventory signature, and security escort are ready.
- Ask detox RN/provider for Renee current CIWA/vitals, seizure setup, and acceptance timing.
- Preserve BH tech coverage for Tara and Amara; do not pull constant-observation resources without replacement.
- Ask security about police incoming adult and escort availability.
- Prepare adolescent plan for Bethany without using adult crisis rooms prematurely.
- Prepare huddle brief with one possible move or clear no-move explanation.
- Update placement board only after owner decisions close.
