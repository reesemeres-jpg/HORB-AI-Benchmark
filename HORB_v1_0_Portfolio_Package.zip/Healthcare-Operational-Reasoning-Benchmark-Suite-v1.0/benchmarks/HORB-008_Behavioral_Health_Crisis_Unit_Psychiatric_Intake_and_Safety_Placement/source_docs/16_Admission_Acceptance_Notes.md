# Admission Acceptance Notes

Receiving Unit / Admission Acceptance Notes  
Updated: 7:12 PM

**BHU-12 / Tara**  
BHU can accept after ED medical clearance, body search checklist, constant-observation handoff, and receiving RN assignment.

**Crisis Room 3 / Malik**  
Crisis unit can use room after ligature sweep, clothing/belongings search, signed hold status, and security handoff.

**Detox Room 4 / Renee**  
Detox unit can accept after current CIWA/vitals, seizure precautions, medication cart check, and detox RN acceptance.

**Adolescent consult room / Bethany**  
Can use after peds-trained sitter coverage and clinician availability.

**Greg Hall**  
Needs clinician handoff after ED clearance note.

Acceptance note: Clean bed or open room does not equal receiving acceptance.
