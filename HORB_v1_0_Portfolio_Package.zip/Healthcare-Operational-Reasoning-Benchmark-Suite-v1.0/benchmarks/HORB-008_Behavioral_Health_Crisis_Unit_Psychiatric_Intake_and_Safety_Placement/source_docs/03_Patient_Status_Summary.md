# Patient Status Summary

Behavioral Health Patient Status Summary  
Updated: 7:10 PM

| Patient | Current status |
|---|---|
| Tara Blake | 29F suicidal ideation after reported acetaminophen ingestion; calm; BHU-12 linked; four-hour acetaminophen level pending; belongings bagged but body search not documented |
| Malik Johnson | 34M agitated after threats at shelter; calmer after verbal de-escalation; urine tox pending; security still nearby; Crisis Room 3 linked |
| Renee Silva | 46F depression and heavy alcohol use; tremor and nausea; last drink this morning; Detox Room 4 linked; CIWA rising; vitals need recheck |
| Jonah Pierce | Panic symptoms improved; discharge resources pending provider review |
| Amara Reed | Post-restraint observation; still on high observation; not a transfer candidate |
| Bethany Cruz | 15F superficial self-harm; parent present; adolescent consult needed; no peds BH evaluator yet |
| Greg Hall | ED provider says medical clearance may be ready soon; no crisis room assigned |
| Lila Tran | Mobile crisis voluntary assessment incoming |

Status note: Earlier placement status may not reflect newer lab, observation, legal, withdrawal, security, or pediatric updates.
