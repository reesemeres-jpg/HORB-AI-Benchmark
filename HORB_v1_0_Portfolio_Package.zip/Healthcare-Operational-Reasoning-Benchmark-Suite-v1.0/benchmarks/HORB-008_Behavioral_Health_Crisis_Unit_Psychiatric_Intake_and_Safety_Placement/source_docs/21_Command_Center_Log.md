# Command Center Log

Behavioral Health Operations Log  
6:55–7:14 PM

6:55 — Crisis placement board showed Tara, Malik, and Renee as green.  
7:00 — ED provider placed Tara transfer hold pending acetaminophen level.  
7:03 — BHU-12 marked clean but receiving RN not assigned.  
7:04 — Malik backpack search found lighter; inventory unsigned.  
7:05 — Malik involuntary hold packet lacks physician signature.  
7:06 — Renee CIWA rose to 13; detox RN unavailable until 7:30.  
7:08 — Crisis Room 3 clean but sweep not documented.  
7:09 — Police notified incoming agitated adult.  
7:10 — Charge requested placement blockers for huddle.  
7:11 — Greg may be medically cleared soon.  
7:12 — Peds-trained sitter unavailable until 8:00 for Bethany.  
7:14 — Board still shows clean-room placements because status fields have not updated.
