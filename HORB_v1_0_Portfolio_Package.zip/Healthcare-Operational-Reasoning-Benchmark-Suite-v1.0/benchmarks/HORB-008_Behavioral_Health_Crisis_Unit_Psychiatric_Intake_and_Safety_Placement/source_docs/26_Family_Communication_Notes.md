# Family Communication Notes

Family and Support Communication Notes  
Updated: 7:14 PM

**Tara Blake**  
Partner wants to know why she has not moved upstairs. Explain that the ingestion lab, search process, and receiving handoff must close first.

**Malik Johnson**  
Shelter staff should be told disposition is not final until legal paperwork and safety placement are complete.

**Renee Silva**  
Sister reports prior withdrawal seizures and wants admission quickly. Explain that detox nurse/provider acceptance and seizure setup are being clarified.

**Bethany Cruz**  
Parent should be told the adolescent process is being held for appropriate staffing, not ignored.

**Jonah Pierce**  
Friend pickup availability should be preserved if provider approves discharge.

Communication note: Families and referring parties need honest status updates without promises of placement timing.
