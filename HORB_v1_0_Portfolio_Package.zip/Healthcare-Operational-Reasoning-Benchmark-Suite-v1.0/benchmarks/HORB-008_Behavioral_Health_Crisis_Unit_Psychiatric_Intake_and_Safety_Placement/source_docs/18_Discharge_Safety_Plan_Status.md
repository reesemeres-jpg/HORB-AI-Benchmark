# Discharge Safety Plan Status

Discharge and Safety Plan Status  
Updated: 7:11 PM

| Patient | Current discharge/safety plan issue |
|---|---|
| Jonah Pierce | Panic improved; friend can pick up; provider has not reviewed written safety plan |
| Greg Hall | No discharge plan yet; crisis evaluation pending |
| Bethany Cruz | Guardian involved; adolescent safety plan not started |
| Malik Johnson | Not a discharge candidate at this time |
| Tara Blake | Not discharge; likely admission after medical clearance |
| Renee Silva | Detox evaluation pending |
| Lila Tran | Not arrived |
| Amara Reed | Not discharge; high observation |

Discharge note: Improved symptoms still require provider review and safe handoff before discharge.
