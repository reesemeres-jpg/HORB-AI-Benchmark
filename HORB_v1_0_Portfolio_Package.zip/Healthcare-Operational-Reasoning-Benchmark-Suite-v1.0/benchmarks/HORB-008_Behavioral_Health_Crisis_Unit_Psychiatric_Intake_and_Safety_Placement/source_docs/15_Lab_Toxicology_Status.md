# Lab Toxicology Status

Lab, Toxicology, and Medical Follow-up  
Updated: 7:12 PM

| Patient | Lab/tox issue |
|---|---|
| Tara Blake | Four-hour acetaminophen level scheduled/drawn per ED plan; result pending; liver panel normal so far |
| Malik Johnson | Urine tox pending; alcohol level negative; abrasion assessment pending |
| Renee Silva | CMP acceptable; magnesium low-normal; CIWA/vitals recheck due |
| Greg Hall | Labs resulted; ED provider clearance note pending |
| Bethany Cruz | No ingestion reported; pregnancy test negative |
| Jonah Pierce | No lab hold |
| Amara Reed | No lab hold; behavioral observation active |
| Lila Tran | No labs yet |

Lab note: Pending tox or ingestion labs can block psychiatric transfer even when the patient is calm.
