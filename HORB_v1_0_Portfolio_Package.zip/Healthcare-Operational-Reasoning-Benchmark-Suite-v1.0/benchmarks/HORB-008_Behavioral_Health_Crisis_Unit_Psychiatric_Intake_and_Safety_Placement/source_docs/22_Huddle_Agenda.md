# Huddle Agenda

Behavioral Health Placement Huddle  
Scheduled: 7:30 PM

Requested decisions:
- Is there a defensible first placement move before 7:45?
- Can Tara transfer to BHU-12, or do acetaminophen level, body search, and receiving RN assignment block movement?
- Can Malik move to Crisis Room 3, or do hold signature, room sweep, search, and security escort block placement?
- Can Renee move to Detox Room 4, or do CIWA/vitals, detox nurse, seizure setup, and capacity documentation block movement?
- Should police incoming adult change use of Crisis Room 3 or security coverage?
- Can Greg be evaluated if medically cleared soon?
- What is the safest adolescent plan for Bethany while peds sitter is unavailable?
- Which observation resources cannot be pulled because of Tara or Amara?
- What can be safely deferred to discharge planning or later clinician review?
- What should be communicated to ED and families without overpromising?

Huddle note: Bring current blockers and owners. Do not rely on green placement-board status alone.
