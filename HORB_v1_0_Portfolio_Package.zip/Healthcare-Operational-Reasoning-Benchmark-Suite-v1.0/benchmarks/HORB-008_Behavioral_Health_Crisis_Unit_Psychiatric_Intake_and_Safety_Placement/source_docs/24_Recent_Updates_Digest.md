# Recent Updates Digest

Recent Updates Digest  
Compiled 7:14 PM

- Tara looks like a clean BHU admission because she is voluntary, calm, and BHU-12 is open, but her acetaminophen level is pending and body search/receiving RN are not complete.
- Malik looks like a crisis-room move because he is calmer and Crisis Room 3 is clean, but the hold signature, room sweep, belongings search, and security escort are not complete.
- Renee looks ready for detox because Detox Room 4 is clean, but CIWA is rising, vitals need recheck, detox nurse is unavailable, and seizure setup is pending.
- Amara still consumes a high-observation tech after restraint.
- Bethany needs adolescent pathway resources and peds-trained sitter coverage.
- Police incoming case may consume security and crisis-room capacity.
- Greg may become ready soon, but clinician availability is limited.
