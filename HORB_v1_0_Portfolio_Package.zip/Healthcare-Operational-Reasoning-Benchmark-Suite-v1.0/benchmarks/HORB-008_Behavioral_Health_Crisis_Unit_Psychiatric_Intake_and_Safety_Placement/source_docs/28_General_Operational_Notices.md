# General Operational Notices

General Behavioral Health Operations Notices

- A clean behavioral health bed does not mean the patient can transfer.
- A calm patient may still have medical clearance, legal, search, or observation holds.
- A green detox room does not override rising withdrawal scores or missing seizure setup.
- A crisis room must be swept and staffed before use.
- Legal hold paperwork needs required signatures before placement decisions rely on it.
- Adolescent patients should not be placed through adult crisis pathways without appropriate resources.
- Incoming police transports can consume security and safe-room capacity quickly.
- Family or ED pressure should not bypass safety gates.
- The safest plan may be to hold placement and bring a blocker list to huddle.
- Update the placement board after live owner decisions close.
