# Family Communication Notes

Family and Support Communication Notes  
Updated: 7:12 PM

**Tara Blake**  
Partner called asking when she will move upstairs. Staff should explain medical clearance and safety search still need to finish.

**Malik Johnson**  
Shelter staff called asking whether he is being admitted. Crisis clinician has not finalized hold status.

**Renee Silva**  
Sister says Renee "gets seizures when she stops drinking" and asks for detox admission quickly.

**Bethany Cruz**  
Parent wants assessment soon and does not want Bethany in adult crisis area.

**Jonah Pierce**  
Friend available for pickup until 8:30.

Communication note: Support-person requests matter, but they do not replace clearance, legal status, safety process, or receiving acceptance.
