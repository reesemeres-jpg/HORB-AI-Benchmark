# Safety Search Belongings

Safety Search, Belongings, and Contraband Status  
Updated: 7:09 PM

| Patient / area | Status |
|---|---|
| Tara Blake | Belongings bagged; body search not documented; shoelaces removed; phone still with tech for inventory |
| Malik Johnson | Backpack secured by security; clothing search incomplete; metal lighter found but inventory not signed |
| Renee Silva | Belongings in medical ED; search not yet done for detox transfer |
| Jonah Pierce | Belongings returned pending discharge |
| Bethany Cruz | Parent has backpack; no search done because no rooming decision yet |
| Crisis Room 3 | Clean but ligature/contraband sweep not documented after prior use |
| BHU-12 | Clean; receiving unit requires search checklist before arrival |
| Detox Room 4 | Clean; seizure precaution setup pending |

Safety note: Belongings bagged or room clean does not mean the safety search process is complete.
