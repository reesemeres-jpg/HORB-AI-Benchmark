# Unit Acuity Milieu

Behavioral Health Unit Acuity / Milieu Status  
Updated: 7:09 PM

| Unit / space | Current acuity issue |
|---|---|
| Adult BHU | One high-observation patient, one patient pacing, staffing tight |
| BHU-12 | Clean bed; receiving RN assignment pending after break |
| Crisis Unit | Amara post-restraint uses one BH tech |
| ED Safe Room area | Tara constant observation occupying tech |
| ED Hall B | Malik requires security presence |
| Detox wing | Medication pass in progress; detox RN unavailable until 7:30 |
| Adolescent pathway | Peds-trained sitter unavailable until 8:00 |
| Police entrance | Security tied up until 7:25 |

Milieu note: Unit acuity and staffing may block a technically clean bed.
