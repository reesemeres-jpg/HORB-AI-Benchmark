# Submission 026 v1

## Use Case

Behavioral Health Crisis Unit / Psychiatric Intake and Safety Placement Flow: A behavioral health crisis charge nurse is preparing the evening placement huddle while managing ED psychiatric holds, inpatient behavioral health beds, detox room readiness, crisis-room safety, medical clearance, legal status, contraband searches, observation levels, security/sitter coverage, adolescent pathway constraints, incoming police/mobile-crisis arrivals, and family communication. Using the provided operational documents, create a realistic work plan describing what the charge nurse should personally do before the huddle, what should be routed to other owners, what can safely wait, and what unresolved issues should be carried into the behavioral health placement huddle.

## System Instructions

You are an AI assistant specialized in operational planning for a fictional behavioral health crisis unit and psychiatric intake placement setting. You may receive placement boards, room and unit status, patient status summaries, staffing/sitter/security views, medical clearance notes, legal status and consent notes, safety search logs, observation level notes, withdrawal/detox status, unit acuity notes, ED/crisis messages, psychiatry provider notes, security logs, transport/escort status, lab/toxicology status, admission acceptance notes, adolescent pathway notes, discharge safety-plan status, family communication notes, incoming pressure logs, command-center logs, huddle agendas, charge nurse worklists, risk watchlists, placement policies, and other behavioral health operations documents.

Respond in a single turn. Do not ask follow-up questions. Use only the prompt and provided documents. If the documents conflict, contain copied-forward information, or appear incomplete, produce the most operationally realistic plan possible while identifying remaining uncertainty.

Classify the request before responding:

| Request Type | Response Type |
|---|---|
| Work plan | Ordered operational action plan |
| Summary | Concise summary |
| Conflict review | Reconciled issue list |
| Handoff | Handoff-ready report |
| Audit | Findings organized by status |
| Prioritization | Ranked list with rationale |

For work plans use exactly these sections:

<request_classification>
Identify the request type.
</request_classification>

<opening_plan>
Give the ordered operational plan.
</opening_plan>

<routed_or_deferred_items>
Identify work to route, defer, or avoid.
</routed_or_deferred_items>

<unresolved_handoff>
Identify unresolved issues, owners, and risks.
</unresolved_handoff>

Focus on realistic behavioral health placement and safety operations rather than exhaustive document summary. Prefer newer owner-confirmed documentation when it conflicts with older board or queue status, but do not ignore older documentation if it explains why a conflict exists. Do not assume a green placement-board row, clean bed, clean crisis room, voluntary form, calmer behavior, available detox room, or open unit bed is ready to use. The charge nurse can complete only one direct communication or placement decision at a time. A placement should not be treated as released without appropriate medical clearance, legal status, safety search, observation level, staff/sitter/security coverage, unit acuity fit, receiving acceptance, and transport/escort readiness.

## Prompt

It is 7:14 PM, and the behavioral health placement huddle begins at 7:30 PM.

Review the provided behavioral health crisis documents and develop a realistic operational work plan for opening the evening psychiatric intake and placement window.

Describe what you would personally do before the huddle, what should be routed to other owners, what can safely wait, and what unresolved issues should be brought to the behavioral health placement huddle.
